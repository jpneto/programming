package Geometry;

import org.junit.*;

import static org.junit.Assert.*;

/**
 * Created by jpn on 23-10-2016.
 * CTRL+Shift+T to add a new JUnit test
 */
public class CircleTest {
    @org.junit.Test
    public void intersect1pt() throws Exception {
        Circle c1 = new Circle(new Point(0,0), 1);
        Circle c2 = new Circle(new Point(2,0), 1);

        Point[] expected = new Point[] { new Point(1,0) };
        Point[] actual = c1.intersect(c2);

        for(int i=0; i<expected.length; i++) {
            assertTrue(expected[i].equals(actual[i]));
        }
    }

    @org.junit.Test
    public void intersect2pt() throws Exception {
        Circle c1 = new Circle(new Point(0,0), 1);
        Circle c2 = new Circle(new Point(1,0), 1);

        Point[] expected = new Point[] { new Point(0.5,-Math.sqrt(3)/2.0),  new Point(0.5,Math.sqrt(3)/2.0)};
        Point[] actual = c1.intersect(c2);

        for(int i=0; i<expected.length; i++) {
            assertTrue(expected[i].equals(actual[i]));
        }
    }
}