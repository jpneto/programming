package Geometry;

import org.junit.*;

import java.util.Arrays;

import static org.junit.Assert.*;

/**
 * Created by jpn on 23-10-2016.
 */
public class ClosestPointTest {
    @org.junit.Test
    public void closestPoints() throws Exception {
        Point[] ps = {new Point(0,0), new Point(10,0), new Point(1,1), new Point(5,5)};

        Point[] expected = {new Point(0,0), new Point(1,1)};
        Point[] actual = Point.closestPoints(ps);

        System.out.println(Arrays.toString(actual));

        for(int i=0; i<expected.length; i++)
            assertTrue(expected[i].equals(actual[i]));
    }

}