package ITMO_MOOC;

import java.io.*;
import java.util.*;

/**
 * Uses two stacks to implement Queue
 * ref: https://stackoverflow.com/questions/69192/how-to-implement-a-queue-using-two-stacks
 *
 * Besides that, each element keeps the minimum of the stack so far
 */
class QueueStack {

    private class Pair {
        public int value, min;
        public Pair(int value, int min) {
            this.value = value;
            this.min = min;
        }
    }

    private Stack<Pair> inbox  = new Stack<>(),
                        outbox = new Stack<>();

    public void enqueue(int value) {
        if (inbox.isEmpty())
            inbox.push(new Pair(value, value));
        else {
            int min = inbox.peek().min;
            inbox.push(new Pair(value, value<min ? value : min));
        }
    }

    // pre: output.isEmpty() && !inbox.isEmpty()
    private void inbox2outbox() {
        int value = inbox.pop().value;       // first time
        outbox.push(new Pair(value, value));

        while (!inbox.isEmpty()) {
            value = inbox.pop().value;
            int min = outbox.peek().min;
            outbox.push(new Pair(value, value<min ? value : min));
        }

    }

    public int dequeue() {
        if (outbox.isEmpty())
            inbox2outbox();
        return outbox.pop().value;
    }

    public int min() {
        int min1 = Integer.MAX_VALUE;
        int min2 = Integer.MAX_VALUE;
        if (!inbox.isEmpty())
            min1 = inbox.peek().min;
        if (!outbox.isEmpty())
            min2 = outbox.peek().min;
        return min1 < min2 ? min1 : min2;
    }

}

//////////////////

public class Week0203 {

    public static void main(String[] args) throws IOException {

        // lots of input
        Reader3.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        QueueStack q = new QueueStack();

        int nCommands = Reader3.nextInt();

        StringBuffer output = new StringBuffer();

        while(nCommands-- > 0) {
            char op = Reader3.next().charAt(0);
            int item;

            if (op == '+') {
                item = Reader3.nextInt();
                q.enqueue(item);
            } else if (op == '-') {
                q.dequeue();
            } else {
                output.append(q.min()+"\n");
            }
        }
        out.write(output.toString());
        out.close();
    }
}
////////////////

/** Class for buffered reading int and double values
 *  Ref: https://www.cpe.ku.ac.th/~jim/java-io.html
 */
class Reader3 {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer( reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
}



/* Solution is correct but too slow

   public static void main(String[] args) throws IOException {

        // lots of input
        Reader3.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int[] q= new int[1000001];
        int head=0;
        int tail=0;
        int min=Integer.MAX_VALUE;
        int item=0;

        int nCommands = Reader3.nextInt();

        StringBuffer output = new StringBuffer();

        while(nCommands-- > 0) {
            char op = Reader3.next().charAt(0);

            if (op == '+') {
                item = Reader3.nextInt();
                q[tail++] = item;
                if (item<min)
                    min = item;
            } else if (op == '-') {
                item = q[head++];
                if(item==min) {
                    int j = Integer.MAX_VALUE;
                    for(int i=head; i!=tail; i++)
                        if (q[i]<j)
                            j=q[i];
                    min = j;
                }
            } else {
                output.append(min+"\n");
            }
        }
        out.write(output.toString());
        out.close();
    }
 */