package ITMO_MOOC;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class Week0108 {

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int K = in.nextInt();

         // initially assume all integers are prime
        boolean[] isPrime = new boolean[K+1];
        int[] divs = new int[K+1];

        for (int i = 2; i <= K; i++) {
            isPrime[i] = true;
            divs[i] = 2;
        }

        // mark non-primes <= n using Sieve of Eratosthenes
        // and also keep the number of divisors
        for (int factor = 2; factor <= K/2; factor++) {
            // original sieve has "factor*factor <= K" at the cycle's end condition
            // but here we need to consider also the composites
            if (isPrime[factor]) {
                for (int j = 2; factor*j <= K; j++) {
                    isPrime[factor*j] = false;
                    divs[factor*j]++;
                }
            } else  // composite number
                for (int j = 2; factor*j <= K; j++)
                    divs[factor*j]++;
        }
        // System.out.println(Arrays.toString(divs));

        // find where's the first number with max number of divisors
        int maxDiv = 0;
        int maxIndex = -1;

        for(int i = K/2; i <= K; i++)
            if (divs[i] > maxDiv) {
                maxDiv = divs[i];
                maxIndex = i;
            }

        int result = K-maxIndex+1;
        out.write(""+result);

        in.close();
        out.close();
    }
}
