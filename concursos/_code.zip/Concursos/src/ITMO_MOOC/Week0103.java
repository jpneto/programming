package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0103 {

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        long A0 = in.nextLong(),
             A1 = in.nextLong(),
             A2 = in.nextLong(),
              n = in.nextLong();

        //System.out.println(A0+":"+A1+":"+A2+":"+n);

        long result=0;

        for(int i=0; i<=n; i++) {
            long aux = A0;
            result = A0;
            A0 = A1;
            A1 = A2;
            A2 = A1+A0-aux;
        }

        out.write(""+result);

        in.close();
        out.close();
    }
}
