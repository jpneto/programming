package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0105 {

    private static final int SIZE = 3;

    private static int[][] roles;
    private static int[] assignments;  // i-th position = assignment of i-th student

    private static int result;

    public static boolean isFeasible(int k) { // for k-th student

        for (int i=0; i<k; i++)
            if (assignments[i] == assignments[k])
                return false;

        return true;
    }

    public static void backtrack(int k) {

        if (k == SIZE) {
            // got a complete solution
            // now compute team efficiency for these assignments
            int sum=0;
            for(int i=0; i<SIZE; i++)
                sum += roles[i][assignments[i]] * roles[i][assignments[i]];
            // and keep if greater
            if (sum>result)
                result=sum;
            return;
        }

        for (int i=0; i<SIZE; i++) {
            assignments[k] = i;
            if (isFeasible(k))
                backtrack(k+1);
        }
    }

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        roles = new int[SIZE][SIZE];
        assignments = new int[SIZE];

        for(int i=0; i<SIZE; i++)
            for(int j=0; j<SIZE; j++)
                roles[i][j] = in.nextInt();

        //System.out.println(Arrays.toString(maxs));

        result=0;

        backtrack(0);

        out.write(""+Math.sqrt(result));

        in.close();
        out.close();
    }
}
