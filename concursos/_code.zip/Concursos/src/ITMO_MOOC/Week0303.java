package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0303 {

    static class Pair {int lifesPerUnit, ammount; Pair(int A, int B) {this.lifesPerUnit =A; this.ammount =B;}
        public String toString() {return "("+ lifesPerUnit +","+ ammount +")";}
    }

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int n = Reader.nextInt();

        Pair[] medicines = new Pair[n];

        for(int i=0; i<n; i++)
            medicines[i] = new Pair(Reader.nextInt(), Reader.nextInt());

        Arrays.sort(medicines, (Pair a, Pair b) -> {
            return Integer.signum(b.lifesPerUnit - a.lifesPerUnit);
        });

        //System.out.println(Arrays.toString(medicines));

        int budget = Reader.nextInt();
        long result=0;

        for(int i=0; budget>0 && i<medicines.length; i++) {
            while (medicines[i].ammount-- > 0) {
                result += medicines[i].lifesPerUnit;
                budget--;
                if (budget==0)
                    break;
            }
        }

        out.write(""+result);

        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}
