package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0106 {

    public static double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
    }

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int A = in.nextInt(); // triangle's length sides
        int B = in.nextInt();
        int C = in.nextInt();

        double delta = (double)(C*C - B*B + A*A) / (2*A);
        double h = Math.sqrt(B*B - (A-delta)*(A-delta)); // triangle's height

        double p1x = 0.0,    // triangle's vertices
               p1y = 0.0,
               p2x = A,
               p2y = 0.0,
               p3x = A-delta,
               p3y = h;

        double m1x = (p1x+p2x)/2.0,  // triangle's middle points
               m1y = (p1y+p2y)/2.0,
               m2x = (p2x+p3x)/2.0,
               m2y = (p2y+p3y)/2.0,
               m3x = (p3x+p1x)/2.0,
               m3y = (p3y+p1y)/2.0;

        double result = (distance(m1x,m1y,m2x,m2y) +
                         distance(m2x,m2y,m3x,m3y) +
                         distance(m3x,m3y,m1x,m1y)) / 3.0;

        out.write(""+result);

        in.close();
        out.close();
    }
}
