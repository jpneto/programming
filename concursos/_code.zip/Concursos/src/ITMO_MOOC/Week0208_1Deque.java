package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0208_1Deque {

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nChanges = Reader.nextInt();
        Deque<Integer> q = new ArrayDeque<>();

        while(nChanges-- > 0) {
            switch (Reader.next()) {
                case "add":
                    q.offerLast(Reader.nextInt());
                    break;
                case "take":
                    q.pollLast();
                    break;
                default:  // mum!
                    int nTakes = q.size()/2;
                    for(int i=0; i<nTakes; i++)
                        q.offerLast(q.pollFirst());
                    break;
            }
        }

        out.write(q.size()+"\n");
        while(!q.isEmpty())
            out.write(q.pollFirst() + " ");
        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}