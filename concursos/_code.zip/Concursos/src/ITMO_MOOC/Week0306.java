package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0306 {

    private static void swap(int[] ns, int i, int j) {
        int aux = ns[i];
        ns[i] = ns[j];
        ns[j] = aux;
    }

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int n = Reader.nextInt();
        int k = Reader.nextInt();

        int[] numbers = new int[n];

        for(int i=0; i<n; i++)
            numbers[i] = Reader.nextInt();

        //System.out.println(Arrays.toString(numbers));

        boolean ordered = true;

        int[][] partitions = new int[k][];

        for(int i=0; i<k; i++)
            partitions[i] = new int[n/k + (n%k > i ? 1 : 0)];

        for(int i=0; i<n; i++)
            partitions[i%k][i/k] = numbers[i];

        for(int i=0; i<k; i++)
            Arrays.sort(partitions[i]);
/*
        for(int i=0; i<k; i++)
            System.out.println(Arrays.toString(partitions[i]));
*/
        for(int i=0; i<n-1; i++)
            if (partitions[i%k][i/k] > partitions[(i+1)%k][(i+1)/k])
                ordered = false;

        out.write(ordered ? "YES" : "NO");

        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}
