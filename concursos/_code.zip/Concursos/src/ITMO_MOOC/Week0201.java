package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0201 {

    static int[] stack = new int[1_000_000];
    static int top = -1;

    public static void main(String[] args) throws IOException {

        // lots of input
        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nCommands = Reader.nextInt();

        while(nCommands-- > 0) {
            char op = Reader.next().charAt(0);

            if (op == '+') {
                stack[++top] = Reader.nextInt();
            } else {
                out.write(stack[top--]+"\n");
            }
        }

        out.close();
    }
}
////////////////

/** Class for buffered reading int and double values
 *  Ref: https://www.cpe.ku.ac.th/~jim/java-io.html
 */
class Reader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer( reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
}
