package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0204 {

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int N = in.nextInt(); in.nextLine();  // each newline

        Stack<Character> stack = new Stack<>();

        while(N-- > 0) {
            String line = in.nextLine();
            boolean ok = true;
            stack.clear();

            for(char c : line.toCharArray()) {
                char c1;
                switch (c) {
                    case '(': stack.push(')');
                              break;
                    case '[': stack.push(']');
                              break;
                    case ')':
                    case ']': if (stack.isEmpty())
                                 ok = false;
                              else {
                                 c1 = stack.pop();
                                 if (c!=c1)
                                   ok = false;
                              }
                              break;
                }
                if (!ok)
                    break;
            }
            out.write(ok && stack.isEmpty() ? "YES\n" : "NO\n");
        }

        in.close();
        out.close();
    }

}
