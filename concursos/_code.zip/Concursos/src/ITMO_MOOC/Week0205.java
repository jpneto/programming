package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0205 {

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nTokens = in.nextInt(); in.nextLine();  // eat newline
        StringTokenizer st = new StringTokenizer(in.nextLine(), " ");

        Stack<Integer> stack = new Stack<>();

        while(nTokens-- > 0) {
            String token = st.nextToken();

            try {
                stack.push(Integer.parseInt(token));
            } catch (NumberFormatException e) {  // it's an operator
                switch(token) {
                    case "+":
                        stack.push(stack.pop() + stack.pop());
                        break;
                    case "-":
                        stack.push(- stack.pop() + stack.pop());
                        break;
                    case "*":
                        stack.push(stack.pop() * stack.pop());
                        break;
                }
            }

        }
        out.write(""+stack.pop());

        in.close();
        out.close();
    }

}
