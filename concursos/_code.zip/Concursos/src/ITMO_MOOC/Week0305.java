package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0305 {

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int n = Reader.nextInt();
        int k1 = Reader.nextInt();
        int k2 = Reader.nextInt();

        int A = Reader.nextInt();
        int B = Reader.nextInt();
        int C = Reader.nextInt();

        int[] as = new int[n];

        as[0] = Reader.nextInt();
        as[1] = Reader.nextInt();

        if(n==2) { // special case
            if (k1==1)
                out.write(Math.min(as[0], as[1])+" ");
            if (k2==2)
                out.write(Math.max(as[0], as[1])+"");
            out.close();
            return;
        }

        for(int i=2; i<as.length; i++)
            as[i] = A*as[i-2] + B*as[i-1] + C;

        System.out.println(Arrays.toString(as));

        for(int k=k1; k<=k2; k++) {
            nth_element(as, 0, as.length, k);
            out.write(as[k-1]+" ");
        }

        System.out.println(Arrays.toString(as));

        out.close();
    }

    // See: http://www.cplusplus.com/reference/algorithm/nth_element
    public static void nth_element(int[] a, int low, int high, int n) {
        while (true) {
            int k = randomizedPartition(a, low, high);
            if (n < k)
                high = k;
            else if (n > k)
                low = k + 1;
            else
                return;
        }
    }

    static Random rnd = new Random();

    static int randomizedPartition(int[] a, int low, int high) {
        swap(a, low + rnd.nextInt(high - low), high - 1);
        int separator = a[high - 1];
        int i = low - 1;
        for (int j = low; j < high; j++)
            if (a[j] <= separator)
                swap(a, ++i, j);
        return i;
    }

    static void swap(int[] a, int i, int j) {
        int t = a[i];
        a[i] = a[j];
        a[j] = t;
    }


    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}
