package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0107 {

    static class Pair {int x, y;  Pair(int a, int b) {x=a; y=b;}}

    static String[] keyboard;
    static int W, H;

    static Pair getPair(char c) {
        for(int h=0; h<H; h++)
            for(int w=0; w<keyboard[h].length(); w++)
                if (keyboard[h].charAt(w)==c)
                    return new Pair(h,w);
        return null;
    }

    static double distance(Pair p1, Pair p2) {
        return Math.max(Math.abs(p1.x-p2.x), Math.abs(p1.y-p2.y));
    }

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int bestScore = Integer.MAX_VALUE; // value to minimize
        String bestLanguage = "";

        W = in.nextInt();
        H = in.nextInt();
        in.nextLine();

        // read keyboard
        keyboard = new String[H];
        for(int h=0; h<H; h++)
            keyboard[h] = in.nextLine();

        String language;
        while (in.hasNext()) {  // for each language
            language = in.nextLine();
            StringBuilder program =  new StringBuilder();

            in.nextLine();  // consume %TEMPLATE-START%

            // get program
            do {
                String line = in.nextLine();
                if (line.compareTo("%TEMPLATE-END%")==0)
                    break;
                program.append(line);
            } while (true);

            // remove begin and end spaces
            program = new StringBuilder(program.toString().trim());

            // compute score
            int score = 0;

            if (program.length()>1) {
                Pair previousPair = getPair(program.charAt(0));
                Pair currentPair;
                for(int i=1; i<program.length();i++) {
                    char currentChar = program.charAt(i);
                    if (currentChar == ' ' || currentChar == '\t')
                        continue;
                    currentPair = getPair(program.charAt(i));
                    score += distance(previousPair, currentPair);
                    previousPair = currentPair;
                }
            }

            if (score < bestScore) {
                bestScore = score;
                bestLanguage = language;
            }
        }

        out.write(bestLanguage);
        out.write("\n"+bestScore);

        in.close();
        out.close();
    }
}
