package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0202 {

    public static void main(String[] args) throws IOException {

        // lots of input
        Reader3.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        ArrayQueue q = new ArrayQueue();

        int nCommands = Reader3.nextInt();

        while(nCommands-- > 0) {
            char op = Reader3.next().charAt(0);

            if (op == '+') {
                q.enqueue(Reader3.nextInt());
            } else {
                out.write(q.front()+"\n");
                q.dequeue();
            }
        }

        out.close();
    }
}
////////////////

/** Class for buffered reading int and double values
 *  Ref: https://www.cpe.ku.ac.th/~jim/java-io.html
 */
class Reader2 {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer( reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
}

////////////////

class ArrayQueue {

    private static final int DEFAULT_CAPACITY = 1000001;

    private int[] q;

    private int head;
    private int tail;
    private int size;

    public ArrayQueue() {
        q = (int[]) new int[DEFAULT_CAPACITY];
        head = 0;
        tail = 0;
        size = 0;
    }

    public void enqueue(int item) {
        if (size == q.length)
            reallocate();
        q[tail] = item;
        tail = inc(tail);
        size++;
    }


    public int front() {
        return q[head];
    }

    public void dequeue() {
        head = inc(head);
        size--;
    }

    private int inc(int i) {
        return (i + 1) % q.length;
    }

    private void reallocate() {
        int[] newQ = new int[q.length * 2];
        System.arraycopy(q, head, newQ, 0, size-head);
        //copy size-head elements from position head  of array q
        //to positions 0 to 0+size-head of array newQ
        System.arraycopy(q, 0, newQ, size-head, head);
        head = 0;
        tail = size;
        q = newQ;
    }

}