package ITMO_MOOC;

import java.io.*;
import java.util.Scanner;

public class Week0109 {

    static final int UNKNOWN = -1;
    static int[] tasks;  // keep the time each tasks takes
    static int[][] sols; // matrix solution (Knapsack dynamic programminc style)

    static int compute_sols(int i, int n, int capacity) {

        if (i==n || capacity==0)
            return 0;

        if (sols[i][capacity] != UNKNOWN)
            return sols[i][capacity];

        if (tasks[i] > capacity)
            return sols[i][capacity] = compute_sols(i+1, n, capacity);

        return sols[i][capacity] =
                Math.max(     compute_sols(i+1, n, capacity),
                          1 + compute_sols(i+1, n, capacity - tasks[i]) );
    }

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int n = in.nextInt();
        tasks = new int[n];
        for(int i=0; i<n; i++)
            tasks[i] = in.nextInt();

        final int budget = 300 * 60;  // the team has a total of 300 minutes

        sols = new int[n][budget+1];
        for(int i=0; i<n; i++)
            for(int j=0; j<=budget; j++)
                sols[i][j] = UNKNOWN;

        int result = compute_sols(0, n, budget);
        out.write(""+result);

        in.close();
        out.close();
    }
}
