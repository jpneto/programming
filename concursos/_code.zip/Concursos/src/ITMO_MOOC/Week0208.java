package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0208 {

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nChanges = Reader.nextInt();
        // left and right should have the same elements
        // if odd number, right has the extra one
        Deque<Integer> left  = new ArrayDeque<>();
        Deque<Integer> right = new ArrayDeque<>();

        while(nChanges-- > 0) {
            switch (Reader.next()) {
                case "add":
                    right.offerLast(Reader.nextInt());
                    // check if balance is needed
                    if (right.size() > left.size()+1)
                        left.offerLast(right.pollFirst());
                    break;
                case "take":
                    right.pollLast();
                    if (right.size() < left.size())
                        right.offerFirst(left.pollLast());
                    break;
                default:  // mum!
                    Deque<Integer> aux = right;
                    right = left;
                    left = aux;
                    if (right.size() < left.size())
                        right.offerFirst(left.pollLast());
                    break;
            }
        }

        out.write((right.size()+left.size())+"\n");
        while(!left.isEmpty())
            out.write(left.pollFirst() + " ");
        while(!right.isEmpty())
            out.write(right.pollFirst() + " ");
        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}