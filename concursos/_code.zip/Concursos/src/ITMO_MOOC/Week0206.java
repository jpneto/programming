package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0206 {

    public static void main(String[] args) throws IOException {

        Reader4.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nActions = Reader4.nextInt(); // eat newline
        long sum=0;

        int[] mass   = new int[nActions+1];
        int[] parent = new int[nActions+1];

        for(int i=1; i<=nActions; i++) {
            int snowmanIdx = Reader4.nextInt();
            int command    = Reader4.nextInt();

            if (command > 0) {
                mass[i] = mass[snowmanIdx] + command;
                parent[i] = snowmanIdx;
            } else {
                mass[i] = mass[parent[snowmanIdx]];
                parent[i] = parent[parent[snowmanIdx]];
            }
            sum += mass[i];
        }

        //System.out.println(Arrays.toString(mass));
        //System.out.println(Arrays.toString(parent));

        out.write(""+sum);
        out.close();
    }

}

class Reader4 {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer( reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
}


/* Correct solution but gives Memory Limit Exceed after 19 tests

    static int mass(Stack<Integer> stack) {
        int result = 0;
        while (!stack.isEmpty())
            result += stack.pop();
        return result;
    }

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nActions = in.nextInt(); in.nextLine();  // eat newline

        Stack<Integer>[] snowmen = new Stack[nActions+1];
        snowmen[0] = new Stack<>();  // empty snowman in first position

        for(int i=1; i<=nActions; i++) {

            int snowmanIdx = in.nextInt();
            int command = in.nextInt();

            snowmen[i] = (Stack<Integer>)snowmen[snowmanIdx].clone();
            if (command>0)
                snowmen[i].push(command);
            else
                snowmen[i].pop();
        }

        long sum=0;
        for(Stack snowman : snowmen)
            sum += mass(snowman);
        out.write(""+sum);

        in.close();
        out.close();
    }

 */