package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0302 {

    private static int[] numbers;
    private static int[] helper;

    private static BufferedWriter out;

    private static long mergesort(int low, int high) throws IOException {
        long inv_count = 0;
        // check if low is smaller than high, if not then the array is sorted
        if (low < high) {
            // Get the index of the element which is in the middle
            int middle = low + (high - low) / 2;
            // Sort the left side of the array
            inv_count =  mergesort(low, middle);
            // Sort the right side of the array
            inv_count += mergesort(middle + 1, high);
            // Combine them both
            inv_count += merge(low, middle+1, high);
        }
        return inv_count;
    }

    private static long merge(int low, int middle, int high) {
        long inv_count = 0;

        // Copy both parts into the helper array
        for (int i = low; i <= high; i++) {
            helper[i] = numbers[i];
        }

        int i = low;
        int j = middle;
        int k = low;
        // Copy the smallest values from either the left or the right side back
        // to the original array
        while (i <= middle-1 && j <= high) {
            if (helper[i] <= helper[j]) {
                numbers[k] = helper[i];
                i++;
            } else {
                numbers[k] = helper[j];
                j++;
                inv_count = inv_count + (middle - i);
            }
            k++;
        }
        // Copy the rest of the left side of the array into the target array
        while (i <= middle-1) {
            numbers[k] = helper[i];
            k++;
            i++;
        }
        // Since we are sorting in-place any leftover elements from the right side
        // are already at the right position.
        return inv_count;
    }

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        out = new BufferedWriter(new FileWriter("output.txt"));

        int n = Reader.nextInt();

        numbers = new int[n];
        helper = new int[n];

        for(int i=0; i<n; i++)
            numbers[i] = Reader.nextInt();

        out.write(""+mergesort(0, numbers.length - 1));

        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}
