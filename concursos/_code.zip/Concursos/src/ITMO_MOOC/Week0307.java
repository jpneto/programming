package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0307 {

    private static long[][] actions;
    //private static int[] lefts;  // for binary search

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int B = Reader.nextInt();  // number of flower beds
        int N = Reader.nextInt();  // number of gardeners

        actions = new long[N][];
        for(int i=0; i<N; i++)   // seeds/flower bed,   first bed,        last bed
            actions[i] = new long[] {Reader.nextInt(), Reader.nextInt(), Reader.nextInt()};

        Arrays.sort(actions, (long[] a, long[] b) -> {    // sort by first bed
            return Long.signum(a[1] - b[1]);
        });

/*
        lefts = new int[N];
        for(int i=0; i<N; i++)
            lefts[i] = actions[i][1];
*/
//        for(int i=0; i<N; i++)
//            System.out.println(Arrays.toString(actions[i]));

        int M = Reader.nextInt();  // number of inspectors

        for(int i=0; i<M; i++)
            out.write(count(Reader.nextInt(), Reader.nextInt())+"\n");

        out.close();
    }

    private static long count(int left, int right) {

        int i=0;
        long result = 0;
//        int firstKey = Arrays.binarySearch(lefts, 0, lefts.length-1, )

        for(i=0; i<actions.length; i++)
            if (actions[i][2] >= left)
                break;

        while (i<actions.length && actions[i][1] <= right) {
            result += actions[i][0] * (Math.min(actions[i][2], right)-Math.max(actions[i][1], left)+1);
            i++;
        }

        return result;
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}
