package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0304 {


    private static void antiQuick(int[] permutation, int begin, int end, int delta) {

        if (begin>end)
            return;

        if (begin==end) {
            permutation[begin] = 1+delta;
            return;
        }

        int max = end-begin+1;
        int middle = (begin+end)/2;

        permutation[middle] = max + delta;

        antiQuick(permutation, begin, middle-1, delta);
        antiQuick(permutation, middle+1, end, delta+max/2-(max%2==0?1:0));
    }


    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int n = Reader.nextInt();

        int[] permutation = new int[n];

        antiQuick(permutation, 0, permutation.length-1, 0);

        for(int i=0; i<permutation.length; i++)
            out.write(permutation[i]+" ");

        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}


/*
    private static void antiQuick(int[] permutation, int begin, int end, int current, int delta) {

        if (begin>end)
            return;

        if (begin==end) {
            permutation[begin] = current+delta;
            return;
        }

        boolean isEven = (current+delta) % 2 == 0;

        int middle = (begin+1+end)/2 - (isEven?1:0);
        permutation[middle] = current + delta;

        if (isEven) {
            antiQuick(permutation, begin, middle-1, current/2 - 1, delta);
            antiQuick(permutation, middle+1, end,   current/2    , delta+current/2);
        } else {
            antiQuick(permutation, begin, middle-1, current/2    , delta);
            antiQuick(permutation, middle+1, end,   current/2    , delta+current/2);
        }
    }

 */