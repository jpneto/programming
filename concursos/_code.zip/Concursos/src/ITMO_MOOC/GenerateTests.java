package ITMO_MOOC;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class GenerateTests {

	public static void main(String[] args) throws IOException {
		Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
		BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

		int k = in.nextInt();
		int[] divs = new int[k + 1];

		for (int i = 1; i <= Math.sqrt(k); i++)
			for (int j = i * i; j <= k; j += i)
				divs[j]++;
		
		for (int i = 1; i <= k; i++)
			divs[i] *= 2;
		
		for (int i = 1; i * i <= k; i++)
			divs[i * i]--; 
		
		int maxDiv = 0;
		int maxIndex = -1;

		for (int i = k / 2; i <= k; i++)
			if (divs[i] > maxDiv) {
				maxDiv = divs[i];
				maxIndex = i;
			}

		int result = k - maxIndex + 1;
		out.write("" + result);

		in.close();
		out.close();
	}
}
