package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0104 {

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int n = in.nextInt();

        int[] theory   = new int[n];
        int[] practice = new int[n];

        for(int i=0; i<n; i++)
            theory[i] = in.nextInt();

        for(int i=0; i<n; i++)
            practice[i] = in.nextInt();

        int[] maxs = new int[n];
        for(int i=0; i<n; i++)
            maxs[i] = Math.max(theory[i],practice[i]);  // compute maximums

        int sum=0;
        for(int i=0; i<n; i++)
            sum += maxs[i];     // compute total sum of maximums
        //System.out.println(Arrays.toString(maxs));

        // check if all are of the same sign
        boolean sameSign  = true;
        boolean firstDiff = theory[0] > practice[0];
        for(int i=1; i<n && sameSign; i++)
            if (theory[i] > practice[i] != firstDiff)
                sameSign = false;

        if (sameSign) {         // but if all are of same sign we must select one of the other

            // we want to sacrifice the smallest difference between tasks to maximize sum
            int smallestDiff = Integer.MAX_VALUE;
            for(int i=0; i<n; i++)
                if (Math.abs(theory[i]-practice[i]) < smallestDiff)
                    smallestDiff = Math.abs(theory[i]-practice[i]);
            sum = sum - smallestDiff;
        }

        out.write(""+sum);

        in.close();
        out.close();
    }
}
