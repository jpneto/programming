package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0207_Arrays {

    static int[] stackSizes;

    static void swap(int i, int j) {
        int aux = stackSizes[i];
        stackSizes[i] = stackSizes[j];
        stackSizes[j] = aux;
    }

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nPassengers = Reader.nextInt();

        int nStacks = 0;
        stackSizes = new int[nPassengers];  // keep the maximum possible number of stacks

        while(nPassengers-- > 0) {
            int cup = Reader.nextInt();

            if (cup==0) {
                if (nStacks==0) {  // first number was a zero
                    stackSizes[nStacks++] = 1;
                } else {
                    stackSizes[nStacks-1]++;                         // add to the smallest cup
                    int  i=nStacks-2;
                    while (i>0 && stackSizes[i-1]==stackSizes[i])    // slide thru equal values
                        i--;
                    if (i>=0 && stackSizes[nStacks-1]>stackSizes[i]) // adjust vector if necessary
                        swap(nStacks-1, i);
                }
            } else {
                stackSizes[nStacks++] = 1;                           // insert new stack of size 1
            }
        }

        //System.out.println(Arrays.toString(stackSizes));

        // count diff sizes of stacks
        int size = stackSizes[0];
        int countStacks=1;
        for(int i=1; i<nStacks; i++)
            if(stackSizes[i]!=size) {
                countStacks++;
                size = stackSizes[i];
            }
        out.write(countStacks+"\n");

        // output pairs (Hi,Ci)
        for(int i=0; i<nStacks; i++) {
            int count=1;
            for(int j=i+1; j<nStacks && stackSizes[i]==stackSizes[j]; j++) {
                count++;
                i++;
            }
            out.write(stackSizes[i] + " " + count + "\n");
        }
        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}