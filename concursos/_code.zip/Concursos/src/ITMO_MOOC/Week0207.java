package ITMO_MOOC;

import java.io.*;
import java.util.*;

public class Week0207 {

    static int[] stackSizes;

    static void swap(int i, int j) {
        int aux = stackSizes[i];
        stackSizes[i] = stackSizes[j];
        stackSizes[j] = aux;
    }

    public static void main(String[] args) throws IOException {

        Reader.init( new FileInputStream(new File("input.txt")) );
        BufferedWriter out = new BufferedWriter(new FileWriter("output.txt"));

        int nPassengers = Reader.nextInt();

        int nStacks = 0;
        stackSizes = new int[nPassengers];  // keep the maximum possible number of stacks

        // sizes[i] has the number of stacks of size i
        int[] sizes = new int[nPassengers+1];

        int maxSizeStacks = 0;                // what is the maximum stack size?
        int minSizeStack = Integer.MAX_VALUE; // what is the minimum stack size?
        boolean firstTime = true;
        while(nPassengers-- > 0) {
            int cup = Reader.nextInt();

            if (cup==0) {
                if (firstTime) {  // first number was a zero
                    sizes[1]++;
                    minSizeStack = 1;
                } else {
                    // add to current stack
                    sizes[minSizeStack]--;
                    sizes[minSizeStack+1]++;
                    while (sizes[minSizeStack]==0)  // update, if necessary, which is the minimum stack
                        minSizeStack++;
                    if (minSizeStack+1>maxSizeStacks)
                        maxSizeStacks = minSizeStack+1;
                }
            } else {
                sizes[1]++;                           // insert new stack of size 1
                minSizeStack = 1;
                if (minSizeStack>maxSizeStacks)
                    maxSizeStacks=minSizeStack+1;
            }
            firstTime = false;
        }

        //System.out.println(Arrays.toString(stackSizes));

        // count diff sizes of stacks
        int countStacks = 0;
        for(int i=0; i<sizes.length; i++)
            if (sizes[i] != 0)
                countStacks++;

        out.write(countStacks+"\n");

        // output pairs (Hi,Ci)
        for(int i=sizes.length-1; i>0; i--) {
            if (sizes[i] != 0)
                out.write(i + " " + sizes[i]+ "\n");
        }
        out.close();
    }

    ////////////////////7

    static class Reader {
        static BufferedReader reader;
        static StringTokenizer tokenizer;

        /** call this method to initialize reader for InputStream */
        static void init(InputStream input) {
            reader = new BufferedReader( new InputStreamReader(input) );
            tokenizer = new StringTokenizer("");
        }

        /** get next word */
        static String next() throws IOException {
            while ( ! tokenizer.hasMoreTokens() ) {
                //TODO add check for eof if necessary
                tokenizer = new StringTokenizer( reader.readLine() );
            }
            return tokenizer.nextToken();
        }

        static int nextInt() throws IOException {
            return Integer.parseInt( next() );
        }

        static double nextDouble() throws IOException {
            return Double.parseDouble( next() );
        }
    }
}