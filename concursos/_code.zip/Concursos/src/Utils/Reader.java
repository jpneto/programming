package Utils;

import java.io.*;
import java.util.*;

/** Class for buffered reading int and double values
 *  Ref: https://www.cpe.ku.ac.th/~jim/java-io.html 
 */
public
class Reader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;
    static String next;
    static boolean eof;

    /** call this method to initialize reader for InputStream 
     * @throws IOException 
     */
    static void init(InputStream input) throws IOException {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
        next = reader.readLine();
    }
    
    static boolean hasNext() {
    	return tokenizer.hasMoreTokens() || next!=null;
    }

    /** get next word
     * @throws IOException 
     */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
        	if (next == null) return null;
        	tokenizer = new StringTokenizer( next );
            next = reader.readLine();
        }
       	return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
	
    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
    
    public static void main(String[] args) throws IOException {
    	
    	Reader.init( System.in );

    	int n = Reader.nextInt();
        double x = Reader.nextDouble();
        
        System.out.printf("%d, %4.2f\n", n, x);
    }
}