package Utils;

import java.util.*;

import static java.lang.Math.*;

/**
 * Created by jpn on 23-10-2016.
 */
public class MathUtils {

    // greatest common divisor (Euclid's algorithm)
    public static long gcd(long a, long b) {
        while (b != 0) { long t = b; b = a % b; a = t; }
        return abs(a);
    }

    // less common multiplier
    public static long lcm(long a, long b) {
        return Math.abs(a / gcd(a, b) * b);
    }

    public static long[] factors(long n) {
        long inc = n%2==0 ? 1 : 2; // odd numbers only have odd factors
        List<Long> fs = new ArrayList<Long>();
        for(long i=1; i<=n/2; i+=inc)
            if (n%i==0)
                fs.add(i);
        fs.add(n);
        return fs.stream().mapToLong(i -> i).toArray();
    }

    public static long[] primeFactors(long n) {
        List<Long> fs = new ArrayList<Long>();
        for (long i=2; i<=n/i; i++)
            while (n % i == 0) {
                fs.add(i);
                n /= i;
            }
        if (n > 1) fs.add(n);
        return fs.stream().mapToLong(i -> i).toArray();
    }

    public static void main(String[] args) {
        System.out.println(Arrays.toString(factors(60)));
        System.out.println(Arrays.toString(primeFactors(60)));
    }

}
