package Utils;

import java.util.*;

public class CollectionUtils {

	private static void sop(Object s) {
		System.out.println(s.toString());
	}
	
	public static void main(String[] args) {
		
		// load array into ArrayList
		int[] array = {1,5,3,8,2,5,6,2};
		List<Integer> li = new ArrayList<Integer>();
		for (int e:array) 
			li.add(e);
		sop("Original " + li);

		// just another array
		int[] array2 = {7,9,4,6,2};
		List<Integer> li2 = new ArrayList<Integer>();
		for (int e:array2) 
			li2.add(e);
		
		// convert ArrayList<Integer> to int[]
		// filter only needed if nulls are possible
		int[] array3 = li2.stream().filter(Objects::nonNull).mapToInt(i -> i).toArray();
		sop(Arrays.toString(array3));
		
		// sort (uses class method compareTo)
		Collections.sort(li);
		sop("Sorted " + li);
		
		// Binary Search (if sorted):
		int index = Collections.binarySearch(li, 1);
		sop("Element 1 is at index " + index);
		
		// reverse sort 
		Collections.sort(li, Collections.reverseOrder());
		sop("Reverse sorted" + li);
		
		// swap two elements
		Collections.swap(li, 1, 4);
		sop("Swap two elements" + li);
		
		// how many elements 5 are in li?
		sop(""+Collections.frequency(li, 5));
		
		// remove duplicates
		Set<Integer> si = new HashSet<Integer>(li);
		List<Integer> li_rep = new ArrayList<Integer>(si);
		sop("Remove duplicates " + li_rep);
		
		// make intersection of ArrayLists li and li2 (avoid duplicates)
		Set<Integer> si2 = new HashSet<Integer>();
		for(int e:li)
			if (li2.contains(e))
				si2.add(e);
		sop("Original " + si2);
		
		// TreeSet is a binary search tree
		TreeSet<Integer> ti = new TreeSet<Integer>(li);
		sop(ti);
		
		sop(ti.headSet(5)); // A TreeSet with all element < 5
		sop(ti.tailSet(5)); // A TreeSet with all element >= 5

		sop(ti.subSet(2, 6));
		
		List<Integer> copy = new ArrayList<Integer>(ti);
		sop(""+copy);
	}
}
