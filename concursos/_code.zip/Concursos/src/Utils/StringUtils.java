package Utils;

import java.util.*;

public class StringUtils {
	
	private static void sop(Object s) {
		System.out.println(s.toString());
	}
	
	public static void main(String[] args) {
		
		// Java has printf
		
		System.out.printf("number %d, float %4.2f and string %s\n", 1, 2.345, "hi");
		
		// for a mutable string use StringBuilder (good for multiple appends)
		StringBuilder sb = new StringBuilder("Niup");
		sb.append(" ");
		sb.append("Contest");

		int i = sb.indexOf("N");
		sb.setCharAt(i, 'M');
		sop(sb.toString());
		
		// convert to numbers and vice-versa:
		sop(100);
		sop(Integer.parseInt("100"));

		sop(Integer.parseInt("FF", 16));
		sop(Integer.toString(255,16));
		
		sop(Integer.parseInt("1100", 2));
		sop(Integer.toString(12,2));
		
		// replace chars
		String s = "aabcdefghijkl";
		sop(s.replace('a', '*'));
		
		// use regex for complex replaces
		// cf. www.vogella.com/tutorials/JavaRegularExpressions/article.html#regex_grouping
		
		sop(s.replaceAll("[aeiou]", "*"));    // replace all vogals
		sop(s.replaceAll("([d-i])", "$1$1")); // duplicate all letters from d to i
		sop("a   b  c d   e".replaceAll(" {2,}", " ")); // remove extra spaces
		
		// split string into tokens
		
		s = "one word; after another";
		String[] tokens = s.split("[ ;]");
		sop(Arrays.toString(tokens));
		
		tokens = s.replaceAll("[ ;]+", " ").split(" "); // remove empty tokens
		sop(Arrays.toString(tokens));
		
		// convert String[] to an Arrays.ArrayList (fixed size, ie, very limited)
		
		List<String> ls = Arrays.asList(tokens); // only works for String[]
		sop(ls.toString());
		
		Collections.sort(ls);  // sorts lexicographically
		sop(ls.toString());		
		
		// regexs are also be useful for string matches
		
		String data1 = "12/2/2015";
		String data2 = "11/12:2015";
		
		String goodData = "\\d{1,2}/\\d{1,2}/\\d{4}"; // \\d is [0-9]
		
		sop(data1 + ": " + data1.matches(goodData));
		sop(data2 + ": " + data2.matches(goodData));
		
	}
}
