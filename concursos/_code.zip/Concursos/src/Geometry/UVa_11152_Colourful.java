package Geometry;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

/**
 * Created by jpn on 24-10-2016.
 */
public class UVa_11152_Colourful {

    public static void main(String[] args) throws IOException {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva11152.in.txt" ));
                System.setOut(new PrintStream("data/uva11152.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        while (sc.hasNextInt()) {

            double a = sc.nextInt(),
                   b = sc.nextInt(),
                   c = sc.nextInt();

            Triangle t = new Triangle(a, b, c);

            double radiusincircle  = t.radiusInCircle(),
                   radiusoutcircle = t.radiusOutCircle();

            double roses      = radiusincircle * radiusincircle * Math.PI,
                   violets    = t.area() - roses,
                   sunflowers = radiusoutcircle * radiusoutcircle * Math.PI - t.area();

            System.out.println(String.format("%1.4f %1.4f %1.4f", sunflowers, violets, roses));
        }

        sc.close();
    }
}
