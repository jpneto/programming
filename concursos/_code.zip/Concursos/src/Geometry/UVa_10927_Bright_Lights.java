package Geometry;

import java.io.*;
import java.util.*;

// Gives Wrong Answer but don't know why. It would seem that floating points operations are ok, but...
public class UVa_10927_Bright_Lights {


	static {
		try{
			System.out.print("Enter: ");
			System.in.read();
		} catch (Exception e) {}
	}



	private static class Tuple implements Comparable<Tuple> {
		int x,y,z;
		double angle;

		@Override
		public int compareTo(Tuple t2) {
			if (Math.abs(angle-t2.angle)<1e-15)  // if same angle, place the farthest to the end
				return x*x+y*y > t2.x*t2.x+t2.y*t2.y ? 1 : -1;  
			if (angle > t2.angle) return  1;
			if (angle < t2.angle) return -1;		
			
			return 0; // this should never be, given the problem restrictions
		}
		
		public String toString() {
			return String.format("x: %d, y:%d, z:%d, angle:%1.10f", x, y, z, angle);
		}
	}

	public static void main(String[] args)  throws IOException {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva10927.in.txt" ));
				System.setOut(new     PrintStream("data/uva10927.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		Reader1.init( System.in );

		int dataset = 1;
		while (true) {
			int nPoles = Reader1.nextInt();
			if (nPoles==0) break;
			
			List<Tuple> ps = new ArrayList<Tuple>(nPoles);
			
			for(int i=0; i<nPoles; i++) {  // read poles from file
				Tuple t = new Tuple();
			    t.x = Reader1.nextInt();
			    t.y = Reader1.nextInt();
			    t.z = Reader1.nextInt();
				t.angle = Math.atan2(t.y, t.x);   // atan2(y,x)
				ps.add(t);
			}
			ps.sort((t1, t2)->t1.compareTo(t2)); // sort'em by angle, and then by distance to origin
			
			// code coordinate into a single long (for easier sort)
			List<Long> nonVisible = new ArrayList<Long>(nPoles); 
			
			int max_height = ps.get(0).z;
			for(int i=1; i<nPoles; i++) 
				if (Math.abs(ps.get(i).angle - ps.get(i-1).angle)>=1e-15) { // if different angles, no problem
					max_height = ps.get(i).z;
				} else {                               // if same angles
					if (ps.get(i).z <= max_height)     // it's hidden if it's lower than some previous
						nonVisible.add(((long)ps.get(i).x+100_000L)*100_000L + (long)ps.get(i).y+10_000L);
					else                                   
						max_height = ps.get(i).z;       
				}
	
			System.out.println(String.format("Data set %d:", dataset++));
			
			if (nonVisible.isEmpty())
				System.out.println("All the lights are visible.");
			else {
				System.out.println("Some lights are not visible:");
				nonVisible.sort(Long::compareTo);
				for(int i=0; i<nonVisible.size()-1; i++) {
					long lg = nonVisible.get(i);
					System.out.println(String.format("x = %d, y = %d;", 
							           lg/100_000 - 100_000,
							           lg%100_000 - 10_000));							
				}
				System.out.println(String.format("x = %d, y = %d.", 
						nonVisible.get(nonVisible.size()-1)/100_000 - 100_000,
						nonVisible.get(nonVisible.size()-1)%100_000 - 10_000));							
			}
		}
		
	}

}

//////////////////////

class Reader1 {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(
                     new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer(
                   reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
}