package Geometry;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;
import java.util.stream.Collectors;

public class UVa_587_Treasures_Everywhere {

	public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva587.in.txt" ));
				System.setOut(new     PrintStream("data/uva587.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
	    
		Scanner sc = new Scanner(System.in);

		Point p      = new Point(0,0), 
			  origin = new Point(0,0);
		
		int map=0;
		while (true) {
			String line = sc.next();
			if (line.equals("END")) break;
		
			// get list of commands
			List<String> c = new ArrayList<String>(Arrays.asList(line.split("[,.]")));
			
			List<Integer> steps = c.stream()   // get list of steps
					               .map(d -> d.split("[NESW]+")[0])
					               .map(Integer::parseInt)
					               .collect(Collectors.toList());
			
			List<String> dirs = c.stream()    // get list of directions
					             .map(d -> d.split("[0-9]+")[1])
					             .collect(Collectors.toList());
			
			p.x = p.y = 0; map++;
			for(int i=0; i<steps.size(); i++) {
				double step     = steps.get(i),
					   stepDiag = step/Math.sqrt(2);
				switch (dirs.get(i)) {
					case "N":                   p.y += step;     break;
					case "E":  p.x += step;                      break;
					case "S":                   p.y -= step;     break;
					case "W":  p.x -= step;                      break;
					case "NW": p.x -= stepDiag; p.y += stepDiag; break;
					case "NE": p.x += stepDiag; p.y += stepDiag; break;
					case "SW": p.x -= stepDiag; p.y -= stepDiag; break;
					case "SE": p.x += stepDiag; p.y -= stepDiag; break;				
				}
			}
			System.out.println("Map #"+map);
			System.out.println(
				String.format("The treasure is located at (%1.3f,%1.3f).", p.x, p.y));
			System.out.println(
				String.format("The distance to the treasure is %1.3f.\n", origin.distance(p)));
		}
		
		sc.close();
	 }
}