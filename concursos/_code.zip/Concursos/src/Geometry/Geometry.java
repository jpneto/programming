package Geometry;

import java.util.*;

import static java.lang.Math.*;

public class Geometry {} // dummy class

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

class Point {
	public static final double EPSILON = 1e-7;
	public double x,y;
	
	public Point(double x, double y)        { this.x=x; this.y=y; }
	public String toString()                { return "(" + x + "," + y + ")"; }	

	public static double hypot(double x, double y) { return sqrt(x*x+y*y);      }	
	public static boolean eq(double a, double b)   { return abs(a-b) < EPSILON; }
	
	public static double deg2rad(double degree)    { return degree * PI/180.0;  }
	public static double rad2deg(double rad)       { return rad * 180.0/PI;     }
	
	public boolean equals(Point p)          { return eq(x,p.x) && eq(y,p.y);  }
	public double distance(Point p)         { return hypot(x-p.x,y-p.y);      }
	
	public Point rotate(double rad) {  	// rotate wrt origin (in radians)
		return new Point(x*cos(rad)-y*sin(rad), x*sin(rad)+y*cos(rad));
	}

    public static boolean collinear(Point p, Point q, Point r) {
        return Math.abs(new Vector(p,q).cross(new Vector(p, r))) < EPSILON;
    }

	// angle between the three points, o is the middle point
	public static double angle(Point a, Point o, Point b) {
		Vector oa = new Vector(o,a),
			   ob = new Vector(o,b);
		return acos(oa.dot(ob) / sqrt(oa.norm_sq()*ob.norm_sq()));
	}
	
	// counterclockwise: if a -> b -> c makes a left turn 
	// if == 0 they are colinear, if negative they make a right turn (clockwise)
	public static boolean ccw(Point a, Point b, Point c) {
		Vector ab = new Vector(a,b),
			   ac = new Vector(a,c);
		return ab.cross(ac) > 0;
	}
	
	// closest point from segment made by points a,b
	public Point closestToSegment(Point a, Point b) {
		Vector ap = new Vector(a,this),
			   ab = new Vector(a,b);
		double u = ap.dot(ab) / ab.norm_sq();
		
		if (u<0.0) return a;
		if (u>1.0) return b;
		return new Line(a,b).projection(this); // return the projection
	}

	//////////////////////////////////////////////////////////
	// ref: http://algs4.cs.princeton.edu/99hull/ClosestPair.java.html
	// computes a closest pair of points in a set of n points in the plane in O(n log n)
	static double bestDistance;
	static Point best1, best2;

	public static Point[] closestPoints(Point[] ps) {
		int n = ps.length;
		if (n <= 1) return null;

		Point[] pointsByX = new Point[n];
		for (int i=0; i<n; i++)
			pointsByX[i] = ps[i];
		Arrays.sort(pointsByX, (Point p1, Point p2) -> {
			if (p1.x > p2.x) return (int)1;  // sort by x-coordinate (breaking ties by y-coordinate)
			if (p1.x < p2.x) return (int)-1;
			return (int)round(p1.y-p2.y);
		});

		// check for coincident points (bestDistance == 0)
		for(int i=0; i<n-1; i++)
			if (pointsByX[i].equals(pointsByX[i+1]))
				return new Point[] {pointsByX[i], pointsByX[i+1]};

		Point[] pointsByY = new Point[n];  // sort by y-coordinate (but not yet sorted)
		for(int i=0; i<n; i++)
			pointsByY[i] = pointsByX[i];

		bestDistance = Double.POSITIVE_INFINITY;
		Point[] aux = new Point[n];
		closest(pointsByX, pointsByY, aux, 0, n-1);
		return new Point[] {best1, best2};
	}

	// find closest pair of points in pointsByX[lo..hi]
	// precondition:  pointsByX[lo..hi] and pointsByY[lo..hi] are the same sequence of points
	// precondition:  pointsByX[lo..hi] sorted by x-coordinate
	// postcondition: pointsByY[lo..hi] sorted by y-coordinate
	private static double closest(Point[] pointsByX, Point[] pointsByY, Point[] aux, int lo, int hi) {
		if (hi <= lo) return Double.POSITIVE_INFINITY;

		int mid = lo + (hi - lo) / 2;
		Point median = pointsByX[mid];

		// compute closest pair with both endpoints in left subarray or both in right subarray
		double delta1 = closest(pointsByX, pointsByY, aux, lo,    mid);
		double delta2 = closest(pointsByX, pointsByY, aux, mid+1, hi);
		double delta = min(delta1, delta2);

		// merge back so that pointsByY[lo..hi] are sorted by y-coordinate
		merge(pointsByY, aux, lo, mid, hi);

		// aux[0..m-1] = sequence of points closer than delta, sorted by y-coordinate
		int m = 0;
		for (int i = lo; i <= hi; i++)
			if (abs(pointsByY[i].x - median.x) < delta)
				aux[m++] = pointsByY[i];

		// compare each point to its neighbors with y-coordinate closer than delta
		for (int i = 0; i < m; i++) {
			// a geometric packing argument shows that this loop iterates at most 7 times
			for (int j = i+1; (j < m) && (aux[j].y - aux[i].y < delta); j++) {
				double distance = aux[i].distance(aux[j]);
				if (distance < delta) {
					delta = distance;
					if (distance < bestDistance) {
						bestDistance = delta;
						best1 = aux[i];
						best2 = aux[j];
					}
				}
			}
		}
		return delta;
	}

	// stably merge a[lo .. mid] with a[mid+1 ..hi] using aux[lo .. hi]
	// precondition: a[lo .. mid] and a[mid+1 .. hi] are sorted subarrays
	private static void merge(Point[] a, Point[] aux, int lo, int mid, int hi) {
		for (int k = lo; k <= hi; k++)
			aux[k] = a[k];
		// merge back to a[]
		int i = lo, j = mid+1;
		for (int k = lo; k <= hi; k++) {
			if      (i > mid)                    a[k] = aux[j++];
			else if (j > hi)                     a[k] = aux[i++];
			else if (compareTo(aux[j],aux[i])<0) a[k] = aux[j++];
			else                                 a[k] = aux[i++];
		}
	}

	private static int compareTo(Point p1, Point p2) {
		if (p1.y < p2.y) return -1;
		if (p1.y > p2.y) return +1;
		if (p1.x < p2.x) return -1;
		if (p1.x > p2.x) return +1;
		return 0;
	}
	//////////////////////////////////// ends closestPoint()
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

class Vector {
	public double x,y;
	
	public Vector(double x, double y) { this.x = x;         this.y = y;         }
	public Vector(Point a, Point b)   { this.x = b.x - a.x; this.y = b.y - a.y; }
	
	public Vector scale(double s)     { return new Vector(x*s,y*s);    }
	public Point  translate(Point p)  { return new Point(x+p.x,y+p.y); }
	
	public double dot(Vector v)       { return x*v.x + y*v.y; }  // dot product
	public double norm_sq()           { return x*x   + y*y;   }  // square of vector's norm
	public double cross(Vector v)     { return x*v.y - y*v.x; }  // cross product
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
//A line is the set of points whose coordinates satisfy a given linear equation ax + by + c = 0.
//By default, non-vertical lines have b=1; vertical lines have b=0.
//ref: Halim, Competitive Programming 3
class Line {

	public static final double EPSILON = 1e-7;
	public double a,b,c;
	
	public static boolean eq(double a, double b) { return abs(a-b) < EPSILON; }
		
	public Line(double a, double b, double c) { this.a = a; this.b = b; this.c = c; }

	// create line defined by two points
	public Line(Point p, Point q) {  
		if (eq(p.x,q.x)) {   // vertical line
			a = 1.0; 
			b = 0.0; 
			c = -p.x;        // default values
		} else {
			a = -(p.y - q.y) / (p.x - q.x);
			b = 1.0;         // we fix the value of b to 1.0
			c = -a*p.x - p.y;
		} 
	}

	public double  distanceTo(Point p) { return abs(a*p.x + b*p.y + c)/sqrt(a*a+b*b); }
	public boolean isColinear(Point p) { return distanceTo(p) < EPSILON;              }
	public boolean isParallel(Line m)  { return eq(a,m.a)     && eq(b,m.b);           }
	public boolean equals(Line m)      { return isParallel(m) && eq(c,m.c);           }
	
	// the projection of p onto line
	public Point projection(Point p) {
		double d = -c - a*p.x - b*p.y;
		double z = 1/(a*a+b*b);
		return new Point(p.x + z*a*d,p.y + z*b*d);
	}
	
	// the line perpendicular to 'this', passing thru p
	public Line perpendicular(Point p) {
		return new Line(p, projection(p));
	}
	
	// the point that intersects two lines (or null if parallel)
	public Point intersect(Line m) {
		if (isParallel(m)) return null;
		
		double px = (m.b * c - b * m.c) / (m.a * b - a * m.b);
		double py = b > EPSILON ? -(a * px + c) : -(m.a * px + m.c);
		return new Point(px,py);
	}
	
	// does two segments intersect?
	public static boolean doSegmentsIntersect(Point a1, Point b1, Point a2, Point b2) {
		Point intersection = new Line(a1,b1).intersect(new Line(a2,b2));
		if (intersection==null) return false; // they are parallel
		Point closest1 = intersection.closestToSegment(a1,b1),
			  closest2 = intersection.closestToSegment(a2,b2);
		return closest1.equals(closest2);
	}
	
	// the line perpendicular to the middle point of segment PQ
	public static Line bisector(Point p, Point q) {
		Line m = new Line(p,q);
		double midx = (p.x+q.x)/2,
			   midy = (p.y+q.y)/2;
		if (m.a==0) return new Line(1.0,0.0,-midx);   // horizontal line
		return new Line(-m.b/m.a, 1.0, -(m.a*midy - m.b*midx)/m.a);
	}	
	
	// the line that bisects the angle made by points p2p1p3 (p1 is in the middle)
	public static Line angleBisector(Point p1, Point p2, Point p3) {
		double ratio = p1.distance(p2) / p1.distance(p3);
		Point p4 = new Vector(p2,p3).scale(ratio/(1+ratio)).translate(p2);
		
		return new Line(p1,p4);
	}

    // line segment p-q intersect with line A-B.
    public static Point lineIntersectSegment(Point p, Point q, Point A, Point B) {
        double a = B.y - A.y,
               b = A.x - B.x,
               c = B.x * A.y - A.x * B.y,
               u = abs(a * p.x + b * p.y + c),
               v = abs(a * q.x + b * q.y + c);
        return new Point((p.x * v + q.x * u) / (u+v), (p.y * v + q.y * u) / (u+v));
    }
	
	public String toString() {
		return String.format("%1$.3f x + %2$.3f y + %3$.3f == 0", a, b, c);
	}
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

class Circle {

	public Point c;   // center
	public double r;  // radius
	
	public Circle(Point center, double radius) { c = center; r = radius; }
	
	// intersect the two bisectors of lines p1p2 and p2p3: that's the circle's center
	public Circle(Point p1, Point p2, Point p3) {
		Line b1 = Line.bisector(p1, p2),
			 b2 = Line.bisector(p2, p3);
		c = b1.intersect(b2);
		r = c.distance(p1);
	}
	
	public double diameter()  { return 2*r; }
	public double perimeter() { return 2*PI*r; }
	public double area()	  { return PI*r*r; }
	
	public double lengthArc (double rad) { return perimeter() * rad/(2*PI); }
	public double lengthCord(double rad) { return 2*r*sin(rad/2.0); }
	
	// Segment of a circle is defined as a region of the circle enclosed by a chord 
	// and an arc lying between the chord�s endpoints
	public double areaSegment(double rad) {
         return r*r/2 * (rad - sin(rad)); 
	}

	// this returns one of two possible centers, given a radius and two points 
	// on the circle (to get the other option, reverse the order of the points)
	public static Point centerGiven(Point p1, Point p2, double radius) {
		double d2 = (p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y);
		double det = radius * radius / d2 - 0.25;
		if (det < 0.0) return null;
		double h = sqrt(det);
		return new Point((p1.x + p2.x) * 0.5 + (p1.y - p2.y) * h,
 				         (p1.y + p2.y) * 0.5 + (p2.x - p1.x) * h);
	}
	
	// the array of points (1 or 2) that are the intersection of the circle with line m
	// if no intersect, it returns null
	public Point[] intersect(Line m) {
		double d = sqrt(m.a*m.a + m.b*m.b);
		Line n = new Line(m.a/d, m.b/d, m.c/d);
		double e = -n.c - n.a*c.x - n.b*c.y,
			   h = sqrt(r*r - e*e);
		if (r<e)  return null;
		if (h==0) return new Point[] {new Point(c.x + n.a*e, c.y + n.b*e)};
		return new Point[] {new Point(c.x + n.a*e - h*n.b, c.y + n.b*e + h*n.a),
				            new Point(c.x + n.a*e + h*n.b, c.y + n.b*e - h*n.a)};		
	}

	// the array of points (1 or 2) that are the intersection of the circle with circle c2
	// if equal or no intersect, it returns null
	// ref: https://sites.google.com/site/indy256/algo/geometry_circle
	public Point[] intersect(Circle c2) {
		if (Point.hypot(c.x - c2.c.x, c.y - c2.c.y) < Point.EPSILON)  // if same center
			return null;

		double dx = c2.c.x - c.x;
		double dy = c2.c.y - c.y;
		double A = -2 * dx;
		double B = -2 * dy;
		double C = dx * dx + dy * dy + r * r - c2.r * c2.r;
		Point[] res = new Circle(new Point(0,0), r).intersect(new Line(A, B, C));
		for (Point p : res) {
			p.x += c.x;
			p.y += c.y;
		}
		return res;
	}

    // ref: https://sites.google.com/site/indy256/algo/geometry_circle
	public double circleIntersectionArea(Circle c2) {
		double r = min(this.r, c2.r);
		double R = max(this.r, c2.r);
		double d = Point.hypot(c.x - c2.c.x, c.y - c2.c.y);
		if (d < R - r + Point.EPSILON) return PI * r * r;  // same circle
		if (d > R + r - Point.EPSILON) return 0;           // no intersection
		return  r * r * acos((d * d + r * r - R * R) / 2 / d / r) + R * R
				* acos((d * d + R * R - r * r) / 2 / d / R) - 0.5
				* sqrt((-d + r + R) * (d + r - R) * (d - r + R) * (d + r + R));
	}

	// returns the two points both on the circumference and in the tangent line from p
	// null if p is inside circle, or just one point if p is in the circumference
	public Point[] tangents(Point p) {
		if (c.distance(p) - r <  Point.EPSILON) return new Point[] { p };
		if (c.distance(p) < r) return null;

		double dx = c.x - p.x,
			   dy = c.y - p.y,
		       dd = sqrt(dx*dx + dy*dy),
		       a  = asin(r/dd),
		       b  = atan2(dy,dx);

		return new Point[] { new Point(r *  sin(b-a), r * -cos(b-a)),
				             new Point(r * -sin(b+a), r *  cos(b+a)) };
	}
	
	public String toString() {
		return "<center: " + c + ", radius: " + r + ">";
	}
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

class Triangle {
	
	Point  A, B, C;   // defined by points
	double a, b, c;   // defined by sizes (no fixed reference) 
	boolean byPoints; // informs which representation we are using
	
	public Triangle(double a, double b, double c) {
		this.a=a; this.b=b; this.c=c; byPoints=false;
	}

	public Triangle(Point a, Point b, Point c) {
		this.A=a; this.B=b; this.C=c; byPoints=true;
	}
	
	public static double area(double a, double b, double c) { // Heron's formula
		double s = (a+b+c)/2.0;             // semi-perimeter
		return sqrt(s*(s-a)*(s-b)*(s-c));
	}

    // another method: https://www.futilitycloset.com/2018/09/07/neat-3/
	public static double area(Point p1, Point p2, Point p3) {
		return area(p1.distance(p2), p2.distance(p3), p3.distance(p1));
	}

	public double area() { return byPoints ? area(A,B,C) : area(a,b,c);	}

	public static double perimeter(Point p1, Point p2, Point p3) {
		return p1.distance(p2) + p2.distance(p3) + p3.distance(p1);
	}

    public double perimeter() {
        return byPoints ? perimeter(A,B,C) : a+b+c;
    }

	// returns the triangle's incircle
	public Circle inCircle() {
		if (!byPoints) return null;
		
		Line angleBisector1 = Line.angleBisector(A, B, C),
		     angleBisector2 = Line.angleBisector(B, A, C);
		
		Point center  = angleBisector1.intersect(angleBisector2);
		double radius = Triangle.area(A, B, C) / (0.5*Triangle.perimeter(A, B, C));
		return new Circle(center, radius);
	}

	// returns the triangle's incircle radius (if we just know the sizes)
	// @pre: !byPoints
	public double radiusInCircle() {
		return Triangle.area(a, b, c) / (0.5*(a+b+c));
	}

	// returns the triangle's outcircle
	public Circle outCircle() {
		if (!byPoints) return null;
		
		Line b1 = Line.bisector(A, B),
		     b2 = Line.bisector(B, C);
		
		Point center  = b1.intersect(b2); 
		double radius = A.distance(B)*B.distance(C)*C.distance(A) / (4*Triangle.area(A, B, C));
		return new Circle(center, radius);
	}
	
	// returns the triangle's outcircle radius (if we just know the sizes)
	// @pre: !byPoints
	public double radiusOutCircle() {
		return a*b*c / (4*Triangle.area(a, b, c));
	}
	
	// return array of the triangle angles in radian
	// to translate to degree use: 
	//   Arrays.stream(t.angles()).map(rad -> rad*180.0/PI).toArray();
	public double[] angles() {
		if (byPoints)
			return new double[] {Point.angle(C,A,B), Point.angle(A,B,C),Point.angle(B,C,A)};
		else {
			double a2=a*a, b2=b*b, c2=c*c; 
			return new double[] {acos((b2+c2-a2)/(2*b*c)),
		                         acos((c2+a2-b2)/(2*a*c)),
		                         acos((a2+b2-c2)/(2*a*b))};
		}
	}
	
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

class Polygon {

	public Point[] vs;

    //@pre: first and last points must be the same
	public Polygon(Point[] vs) {
        this.vs = vs;
    }

    public double perimeter() {
        double result = 0.0;
        for (int i=0; i<vs.length-1; i++)
            result += vs[i].distance(vs[i+1]);
        return result;
    }

    public double area() {
        double result = 0.0, x1, y1, x2, y2;
        for (int i = 0; i<vs.length-1; i++)
            result += (vs[i].x * vs[i+1].y) - (vs[i+1].x * vs[i].y);
        return abs(result) / 2.0;
    }

    // returns true if all three consecutive vertices form the same turns
    public boolean isConvex() {
        int sz = (int)vs.length;
        if (sz <= 3) return false; // it's a point or a segment

        boolean isLeft = Point.ccw(vs[0], vs[1], vs[2]);
        for (int i = 1; i < sz-1; i++)
            if (Point.ccw(vs[i], vs[i+1], vs[(i+2) == sz ? 1 : i+2]) != isLeft)
                return false;
        return true;
    }

    public boolean inPolygon(Point p) {
        if ((int)vs.length == 0) return false;
        double sum = 0;
        for (int i = 0; i < vs.length-1; i++)
            if (Point.ccw(p, vs[i], vs[i + 1]))
                sum += Point.angle(vs[i], p, vs[i + 1]);    // left turn/ccw
            else
                sum -= Point.angle(vs[i], p, vs[i + 1]);    // right turn/cw
        return abs(abs(sum) - 2*PI) < Point.EPSILON;
    }

    // cuts polygon along the line formed by points a b
    public Polygon cutPolygon(Point a, Point b) {
        ArrayList<Point> P = new ArrayList<Point>();

        for (int i = 0; i < this.vs.length; i++) {
            double left1 = new Vector(a, b).cross(new Vector(a, vs[i])),
                   left2 = 0.0;
            if (i != vs.length-1)
                left2 =  new Vector(a,b).cross(new Vector(a, vs[i+1]));
            if (left1 > -Point.EPSILON)
                P.add(vs[i]);                         // vs[i] is on the left of ab
            if (left1 * left2 < -Point.EPSILON)       // edge (vs[i], vs[i+1]) crosses line ab
                P.add(Line.lineIntersectSegment(vs[i], vs[i+1], a, b));
        }
        if (!P.isEmpty() && !(P.get(0).equals(P.get(P.size()-1))))
            P.add(P.get(0));                          // make Polygon's first point = last point
        return new Polygon(P.toArray(new Point[0]));  // toArray() needs to know what type of array
    }

    ///////////////////////////////////////////////////////////////
    // used in convex hull
    private static int comparePoints(Point p, Point q) {
        if (abs(p.x - q.x) > Point.EPSILON)       // useful to sort...
            return (int)ceil(p.x - q.x);          // ...first by x-coordinate
        else if (abs(p.y - q.y) > Point.EPSILON)
            return (int)ceil(p.y - q.y);          // ... and second by y-coordinate
        return 0;
    }

    Point pivot = new Point(0,0);  // used in convex hull

    Polygon convexHull(List<Point> P) {
        int i, j, n = (int)P.size();

        if (n <= 3) {
            if (comparePoints(P.get(0), P.get(n-1)) != 0)
                P.add(P.get(0));                        // safeguard from corner case
            return new Polygon((Point[])P.toArray());   // special case, the convex hull is P itself
        }

        // first, find P0 = point with lowest Y and if tie: rightmost X
        int P0 = 0;
        for (i = 1; i < n; i++)
            if (P.get(i).y  < P.get(P0).y ||
                    (P.get(i).y == P.get(P0).y && P.get(i).x > P.get(P0).x))
                P0 = i;

        Point temp = P.get(0); P.set(0, P.get(P0)); P.set(P0 ,temp);   // swap P[P0] with P[0]

        // second, sort points by angle w.r.t. P0
        pivot = P.get(0);                               // use this attribute variable as reference
        Collections.sort(P, new Comparator<Point>(){
            public int compare(Point a, Point b) {      // angle-sorting function
                if (Point.collinear(pivot, a, b))
                    return pivot.distance(a) < pivot.distance(b) ? -1 : 1;   // which one is closer?
                double d1x = a.x - pivot.x, d1y = a.y - pivot.y;
                double d2x = b.x - pivot.x, d2y = b.y - pivot.y;
                return (atan2(d1y, d1x) - atan2(d2y, d2x)) < 0 ? -1 : 1;
            }
        });

        // third, the ccw tests
        List<Point> S = new ArrayList<Point>();
        S.add(P.get(n-1));
        S.add(P.get(0));
        S.add(P.get(1));  // initial S

        i = 2;            // then, we check the rest
        while (i < n) {   // note: n must be >= 3 for this method to work
            j = S.size() - 1;
            if (Point.ccw(S.get(j-1), S.get(j), P.get(i)))
                S.add(P.get(i++));       // left turn, accept
            else
                S.remove(S.size() - 1);  // or pop the top of S until we have a left turn
        }
        return new Polygon(S.toArray(new Point[0]));
    }
}