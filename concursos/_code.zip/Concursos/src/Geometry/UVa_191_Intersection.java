package Geometry;

import java.io.*;
import java.util.*;

public class UVa_191_Intersection {

	 public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva191.in.txt" ));
				System.setOut(new     PrintStream("data/uva191.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
	    
		Scanner sc = new Scanner(System.in);

		int nCases = sc.nextInt();

		while (nCases-- > 0) {
			
			Point P1 = new Point(sc.nextInt(), sc.nextInt()),  // segment coordinates
				  P2 = new Point(sc.nextInt(), sc.nextInt());
				  
			int xleft   = sc.nextInt(),                        // rectangle coordinates
			    ytop    = sc.nextInt(),
			    xright  = sc.nextInt(),
			    ybottom = sc.nextInt();
			
			// they might be out of order
			if (xleft>xright) {	int temp=xleft; xleft=xright; xright=temp; }
			if (ybottom>ytop) {	int temp=ybottom; ybottom=ytop; ytop=temp; }
			
			if (P1.equals(P2)) { // not segment but one point
				if (P1.x >= xleft && P1.x <= xright && P1.y >= ybottom && P1.y <= ytop)
					System.out.println("T");
				else  
					System.out.println("F");
			} else {
				Point top_left     = new Point(xleft,ytop),
					  top_right    = new Point(xright,ytop),
					  bottom_left  = new Point(xleft,ybottom),
					  bottom_right = new Point(xright,ybottom);
				
				if (P1.x >= xleft && P1.x <= xright && P1.y >= ybottom && P1.y <= ytop &&
					P2.x >= xleft && P2.x <= xright && P2.y >= ybottom && P2.y <= ytop)
					System.out.println("T");  // segment is all inside
				else if (Line.doSegmentsIntersect(P1, P2, top_left, bottom_left))
					System.out.println("T");
				else if (Line.doSegmentsIntersect(P1, P2, top_right, bottom_right))
					System.out.println("T");
				else if (Line.doSegmentsIntersect(P1, P2, top_left, top_right))
					System.out.println("T");
				else if (Line.doSegmentsIntersect(P1, P2, bottom_left, bottom_right))
					System.out.println("T");
				else
					System.out.println("F");				
			}
		}
		
		sc.close();
	 }
}
