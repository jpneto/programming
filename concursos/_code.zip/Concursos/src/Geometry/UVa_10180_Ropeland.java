package Geometry;

import java.io.*;
import java.util.*;

public class UVa_10180_Ropeland {

    public static void main(String[] args)  throws IOException {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva10180.in.txt" ));
                System.setOut(new PrintStream("data/uva10180.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Reader2.init( System.in );

        int nCases = Reader2.nextInt();

        while (nCases-- > 0) {
            Point group1 = new Point(Reader2.nextDouble(), Reader2.nextDouble());
            Point group2 = new Point(Reader2.nextDouble(), Reader2.nextDouble());
            double segmentLength = group1.distance(group2);

            Circle pillar = new Circle(new Point(0,0), Reader2.nextDouble());

            // the pillar's center can be projected onto the line defined by group1 and group2
            // let's call this projection P
            Point P = new Line(group1, group2).projection(pillar.c);

            // if this P is larger than the radius, the line does not intersect the circle
            // otherwise, we need to check if P is outside the segment
            //   if outside, there is also no intersection
            if (pillar.r < Point.EPSILON           ||  // radius==0, eg from uDebug (problem says radius>0)
                P.distance(pillar.c) > pillar.r    ||
                P.distance(group1) > segmentLength ||
                P.distance(group2) > segmentLength) {
                System.out.printf("%1.3f\n", segmentLength);
                continue;  // problem instance solved, go fetch next one
            }

            // if it does intersect... get points at the tangents for each group
            Point[] tangents_group1 = pillar.tangents(group1);
            Point[] tangents_group2 = pillar.tangents(group2);

            // ... there are four possibilities to check (two tangents for each group)
            double best_distance = Double.MAX_VALUE;
            for(int i1=0; i1<tangents_group1.length; i1++)
              for(int i2=0; i2<tangents_group2.length; i2++) {
                  double angle    = Point.angle(tangents_group1[i1], pillar.c, tangents_group2[i2]);
                  double distance = group1.distance(tangents_group1[i1]) +
                                    pillar.lengthArc(angle) +
                                    group2.distance(tangents_group2[i2]);
                  best_distance   = Math.min(distance, best_distance);
              }
            System.out.printf("%1.3f\n", best_distance);
        }
    }
}

class Reader2 {
    static BufferedReader reader;
    static StringTokenizer tokenizer;
    static String next;
    static boolean eof;

    /** call this method to initialize reader for InputStream
     * @throws IOException
     */
    static void init(InputStream input) throws IOException {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
        next = reader.readLine();
    }

    static boolean hasNext() {
        return tokenizer.hasMoreTokens() || next!=null;
    }

    /** get next word
     * @throws IOException
     */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            if (next == null) return null;
            tokenizer = new StringTokenizer( next );
            next = reader.readLine();
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }

}