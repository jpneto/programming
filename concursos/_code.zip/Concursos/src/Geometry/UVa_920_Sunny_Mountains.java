package Geometry;

import java.io.*;
import java.util.*;

public class UVa_920_Sunny_Mountains {

	public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva920.in.txt" ));
				System.setOut(new     PrintStream("data/uva920.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
	    
		Scanner sc = new Scanner(System.in);

		int nCases = sc.nextInt();

		while (nCases-- > 0) {
			
			int i = 0, nPairs = sc.nextInt();
			long[] coords = new long[nPairs];
			
			while (nPairs-- > 0) {
				// place both coordinates in a single number
				coords[i++] = 10_000 * sc.nextInt() + sc.nextInt();
			}
			Arrays.sort(coords);
			
			// now create the array of Points
			Point[] ps = new Point[coords.length];
			
			for(i=0; i<coords.length; i++)  
				ps[i] = new Point(coords[i]/10_000, coords[i]%10_000); 
			
			// include  final slope
			double total=ps[coords.length-2].distance(ps[coords.length-1]);
			
			Point last_max_peak = ps[coords.length-2];
			for(i=coords.length-3; i>=0; i--) {  // sum the bold lines, start from end
				if (ps[i].y > last_max_peak.y) {
					Line actualSlope = new Line(ps[i],ps[i+1]);
					// get a horizontal line from last peak
					Point h = new Point(last_max_peak.x+1, last_max_peak.y);
					Line horizontalPeak = new Line(last_max_peak, h);
					// find intersection where shade starts
					Point intercept = actualSlope.intersect(horizontalPeak); 
					total += ps[i].distance(intercept);
				    last_max_peak = ps[i];
				}
			}
			
			System.out.println(String.format("%1.2f", total));			
		}
		
		sc.close();
	 }

}