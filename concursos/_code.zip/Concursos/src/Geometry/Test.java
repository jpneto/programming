package Geometry;

import java.util.ArrayList;
import java.util.Arrays;

import static java.lang.Math.*;

public class Test {

	public static void main(String[] args) {


        Point A = new Point(1,1),
              B = new Point(1,2),
              C = new Point(2,1);
        System.out.println( "Bisector " + Line.angleBisector(A,B,C) );

        //Line

        ////////////////////////////////////

        Triangle t1 = new Triangle(1,1,1);
        Triangle t2 = new Triangle(3,4,5);
        Triangle t3 = new Triangle(3,4,6);

        double[] r1 = Arrays.stream(t1.angles()).map(rad -> rad*180.0/PI).toArray();
        double[] r2 = Arrays.stream(t2.angles()).map(rad -> rad*180.0/PI).toArray();
        double[] r3 = Arrays.stream(t3.angles()).map(rad -> rad*180.0/PI).toArray();

        System.out.println(Arrays.toString(r1));
        System.out.println(Arrays.toString(r2));
        System.out.println(Arrays.toString(r3));

        //////////////

        t1 = new Triangle(new Point(0,0), new Point(2,0), new Point(1,sqrt(3)));
        t2 = new Triangle(new Point(0,0), new Point(3,0), new Point(3,4));
        t3 = new Triangle(new Point(0,0), new Point(2,0), new Point(4,4));

        r1 = Arrays.stream(t1.angles()).map(rad -> rad*180.0/PI).toArray();
        r2 = Arrays.stream(t2.angles()).map(rad -> rad*180.0/PI).toArray();
        r3 = Arrays.stream(t3.angles()).map(rad -> rad*180.0/PI).toArray();

        System.out.println(Arrays.toString(r1));
        System.out.println(Arrays.toString(r2));
        System.out.println(Arrays.toString(r3));

        ////////////////////////////////////

        // 6 points, entered in counter clockwise order, 0-based indexing
        Point[] pts = new Point[] {
                new Point(1, 1),
                new Point(3, 3),
                new Point(9, 1),
                new Point(12, 4),
                new Point(9, 7),
                new Point(1, 7),
                new Point(1, 1) }; // loop back

        Polygon plg = new Polygon(pts);

        System.out.printf("Perimeter of polygon = %.2f\n", plg.perimeter()); // 31.64
        System.out.printf("Area of polygon = %.2f\n",      plg.area()); // 49.00
        System.out.printf("Is convex = %b\n",              plg.isConvex()); // false (P1 is the culprit)

        //// the positions of P6 and P7 w.r.t the polygon
        //7 P5--------------P4
        //6 |                  \
        //5 |                    \
        //4 |   P7                P3
        //3 |   P1___            /
        //2 | / P6    \ ___    /
        //1 P0              P2
        //0 1 2 3 4 5 6 7 8 9 101112

        Point P6 = new Point(3, 2); // outside this (concave) polygon
        System.out.printf("Point P6 is inside this polygon = %b\n", plg.inPolygon(P6)); // false
        Point P7 = new Point(3, 4); // inside this (concave) polygon
        System.out.printf("Point P7 is inside this polygon = %b\n", plg.inPolygon(P7)); // true

        // cutting the original polygon based on line P[2] -> P[4] (get the left side)
        //7 P5--------------P4
        //6 |               |  \
        //5 |               |    \
        //4 |               |     P3
        //3 |   P1___       |    /
        //2 | /       \ ___ |  /
        //1 P0              P2
        //0 1 2 3 4 5 6 7 8 9 101112
        // new polygon (notice the index are different now):
        //7 P4--------------P3
        //6 |               |
        //5 |               |
        //4 |               |
        //3 |   P1___       |
        //2 | /       \ ___ |
        //1 P0              P2
        //0 1 2 3 4 5 6 7 8 9

        Polygon plg2 = plg.cutPolygon(pts[2], pts[4]);
        System.out.printf("Perimeter of polygon = %.2f\n", plg2.perimeter()); // smaller now 29.15
        System.out.printf("Area of polygon = %.2f\n",      plg2.area()); // 40.00

        // running convex hull of the resulting polygon (index changes again)
        //7 P3--------------P2
        //6 |               |
        //5 |               |
        //4 |   P7          |
        //3 |               |
        //2 |               |
        //1 P0--------------P1
        //0 1 2 3 4 5 6 7 8 9

        Polygon plg3 = plg2.convexHull(Arrays.asList(plg2.vs)); // now this is a rectangle
        System.out.printf("Perimeter of polygon = %.2f\n", plg3.perimeter()); // precisely 28.00
        System.out.printf("Area of polygon = %.2f\n", plg3.area()); // precisely 48.00
        System.out.printf("Is convex = %b\n", plg3.isConvex()); // true
        System.out.printf("Point P6 is inside this polygon = %b\n", plg3.inPolygon(P6)); // true
        System.out.printf("Point P7 is inside this polygon = %b\n", plg3.inPolygon(P7)); // true
	}

}
