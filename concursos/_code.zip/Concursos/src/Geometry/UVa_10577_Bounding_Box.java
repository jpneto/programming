package Geometry;

import static java.lang.Math.*;
import java.io.*;
import java.util.*;

public class UVa_10577_Bounding_Box {

    public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva10577.in.txt" ));
                System.setOut(new PrintStream("data/uva10577.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);
        int instance = 1;

        do {
            int vertices = sc.nextInt();

            if (vertices==0) break;

            Point p1 = new Point(sc.nextDouble(), sc.nextDouble()),
                  p2 = new Point(sc.nextDouble(), sc.nextDouble()),
                  p3 = new Point(sc.nextDouble(), sc.nextDouble());

            // find the circle defined by these three points
            Circle c = new Circle(p1, p2, p3);

            // translate p1 so that the circle's center would be at origin
            Point p = new Point(p1.x-c.c.x, p1.y-c.c.y);

            // compute the vertices of the polygon
            double angle_delta = 2*PI / (double)vertices;

            Point[] polygon = new Point[vertices];
            for(int i=0; i<vertices; i++)
                polygon[i] = p.rotate(i*angle_delta);

            // we have the polygon, find min/max coordinates of its points
            double min_x = Double.MAX_VALUE,
                   min_y = Double.MAX_VALUE,
                   max_x = Double.MIN_NORMAL,
                   max_y = Double.MIN_NORMAL;

            for(int i=0; i<vertices; i++) {
                p = polygon[i];
                if (p.x > max_x) max_x = p.x;
                if (p.y > max_y) max_y = p.y;
                if (p.x < min_x) min_x = p.x;
                if (p.y < min_y) min_y = p.y;
            }

            double area = (max_x - min_x) * (max_y - min_y);
            System.out.println(String.format("Polygon %d: %1.3f", instance++, area));

        } while(true);
    }
}
