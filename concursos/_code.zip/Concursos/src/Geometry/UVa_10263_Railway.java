package Geometry;

import java.io.*;
import java.util.*;

public class UVa_10263_Railway {

	public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva10263.in.txt" ));
				System.setOut(new     PrintStream("data/uva10263.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
	    
		Scanner sc = new Scanner(System.in);

		while (sc.hasNextDouble()) {
			
			Point M = new Point(sc.nextDouble(), sc.nextDouble());
			int N = sc.nextInt();

			Point[] railway = new Point[N+1];
			for(int i=0; i<=N; i++)
				railway[i] = new Point(sc.nextDouble(), sc.nextDouble());
			
			// for each segment, check the closest point to M and keep the minimum:
			double minDistance = Double.MAX_VALUE; 
			Point station = null;
			for(int i=0; i<N; i++) {
				Point proposal = M.closestToSegment(railway[i], railway[i+1]); 
				double d = proposal.distance(M);
				if (d<minDistance) {
					minDistance = d;
					station = proposal;
				}
			}
			
			System.out.println(String.format("%1.4f\n%1.4f", station.x, station.y));
		}
		
		sc.close();
	 }

}
