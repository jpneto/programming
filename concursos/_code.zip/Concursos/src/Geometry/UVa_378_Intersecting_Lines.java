package Geometry;

import java.io.*;
import java.util.Scanner;

public class UVa_378_Intersecting_Lines {
	
	public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva378.in.txt" ));
				System.setOut(new     PrintStream("data/uva378.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
	    
		Scanner sc = new Scanner(System.in);

		int nCases = sc.nextInt();

		System.out.println("INTERSECTING LINES OUTPUT");
		
		while (nCases-- > 0) {
			
			Point P1 = new Point(sc.nextInt(), sc.nextInt()),  
				  P2 = new Point(sc.nextInt(), sc.nextInt()),
				  P3 = new Point(sc.nextInt(), sc.nextInt()),
				  P4 = new Point(sc.nextInt(), sc.nextInt());
				  
			Line m1 = new Line(P1,P2),
				 m2 = new Line(P3,P4);
			
			if (m1.equals(m2))
				System.out.println("LINE");
			else if (m1.isParallel(m2))
				System.out.println("NONE");
			else {
				Point p = m1.intersect(m2);
				System.out.println(String.format("POINT %1.2f %1.2f", p.x, p.y));
			}
		}
		
		System.out.println("END OF OUTPUT");
		
		sc.close();
	 }
}
