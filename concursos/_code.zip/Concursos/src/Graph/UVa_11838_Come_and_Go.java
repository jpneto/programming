package Graph;

import java.io.*;
import java.util.*;

// UVa 11838 Come and Go (Strong Connected Components)
// Problem: https://uva.onlinejudge.org/external/118/11838.pdf

public class UVa_11838_Come_and_Go {

	public static void main(String[] args)  throws IOException {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva11838.in.txt" ));
				System.setOut(new     PrintStream("data/uva11838.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		
		Reader1.init( System.in );

		while (true) {
			int nNodes = Reader1.nextInt();
			int nEdges = Reader1.nextInt();

			if (nNodes==0 && nEdges==0)
				break;
			
			GraphMatrix g = new GraphMatrix(nNodes, GraphMatrix.DIRECT);
			
			while (nEdges-- > 0) {
				int V = Reader1.nextInt()-1;
				int W = Reader1.nextInt()-1;
				g.add(V, W);
				int P = Reader1.nextInt();
                if (P==2)
    				g.add(W, V);
			}
			
			int[][] nComponents = g.strongComponents();
			System.out.println(nComponents.length==1 ? 1 : 0);
		}
		
	}
}

class Reader1 {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(
                     new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer(
                   reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
}
