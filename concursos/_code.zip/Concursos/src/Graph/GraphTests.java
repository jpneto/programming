package Graph;

import java.util.Arrays;

public class GraphTests {

	////////////////////////////////////////
    
    public static void main(String[] args) throws Exception {
    	
    	//GraphMatrix g = new GraphMatrix(6, GraphMatrix.DIRECT); // directed graph
    	Graph g = new Graph(6, GraphMatrix.DIRECT, Graph.SPARSE);
    	
    	g.add(0, 3); g.add(0, 2);
    	g.add(4, 2); g.add(2, 1);
    	g.add(1, 3); g.add(3, 5); g.add(0, 5, 4);
    	
    	System.out.println(g);
    	System.out.println("succs of 0: " + Arrays.toString(g.sucessors(0)));
    	System.out.println("preds of 5: " + Arrays.toString(g.predecessors(5)));
    	System.out.println("dfs: "+ Arrays.toString(g.dfs(0)));
    	System.out.println("bfs: "+ Arrays.toString(g.bfs(0)));
    	System.out.println("topSort: "+ Arrays.toString(g.topSort()));
    	int[] path = g.shortestPath(0,5);
    	System.out.println("shortPath: "+ Arrays.toString(path) 
    	                   + " with cost " + g.cost(path) );
    	
    	/////////////
    	
    	Graph gu = new Graph(9, Graph.UNDIRECT, Graph.SPARSE);  // undirected graph
    	gu.add(0, 7);  
    	gu.add(2, 7);  
    	gu.add(0, 2);  
    	gu.add(3, 1);  
    	gu.add(4, 5);  
    	gu.add(4, 6);  
    	gu.add(1, 8);  
    	
    	int[][] result = gu.components();
    	System.out.println(gu);
    	for(int[] component : result)
    		System.out.println("comp: "+ Arrays.toString(component));
    	
    	/////////////
    	
    	Graph bip = new Graph(8, GraphMatrix.UNDIRECT, Graph.SPARSE);
       	bip.add(0,2);
    	bip.add(1,2);
    	bip.add(1,4);
    	bip.add(1,6);
    	bip.add(3,2);
    	bip.add(3,4);
    	bip.add(5,2);
    	bip.add(5,4);
    	bip.add(7,6);

    	System.out.println(bip);
    	result = bip.components();
    	for(int[] component : result)
    		System.out.println("comp: "+ Arrays.toString(component));
    	System.out.println("bipartide? " + bip.isBipartide());

    	path = bip.shortestPath(7,0);
    	System.out.println("shortPath: "+ Arrays.toString(path) 
    	                   + " with cost " + bip.cost(path) );

    
    	/////////////
    	
    	Graph ssc = new Graph(10, GraphMatrix.DIRECT, Graph.SPARSE);
    	ssc.add(0,7);
    	ssc.add(7,3);
    	ssc.add(3,2);
    	ssc.add(2,7);
    	ssc.add(3,4);
    	ssc.add(4,5);
    	ssc.add(5,1);
    	ssc.add(1,6);
    	ssc.add(6,4);
    	ssc.add(8,9);
    	
    	result = ssc.strongComponents();
    	System.out.println(gu);
    	for(int[] component : result)
    		System.out.println("strong comp: "+ Arrays.toString(component));
    
    	//////////
    	
    	Graph mst = new Graph(5, GraphMatrix.UNDIRECT, Graph.SPARSE);
    	
    	mst.add(0, 1, 4);
    	mst.add(0, 2, 4);
    	mst.add(0, 3, 6);
    	mst.add(0, 4, 6);
    	mst.add(2, 3, 8);
    	mst.add(3, 4, 9);
    	mst.add(1, 2, 2);
    	System.out.println(mst);
    	
    	int[] mstEdges = mst.minimumSpanningTree();
    	System.out.println("MST: "+ Arrays.toString(mstEdges) + 
    			           " with cost " + mst.costMST(mstEdges));
    	
    	///////////
    	
    	Graph maxflow = new Graph(4, Graph.DIRECT);
    	
    	maxflow.add(0, 1, 100);
    	maxflow.add(0, 2, 100);
    	maxflow.add(1, 2,   1);
    	maxflow.add(1, 3,  99);
    	maxflow.add(2, 3, 101);
    	
    	// detailed information about the flow can be seen at int[][] maxflow.residual
    	System.out.println("Max Flow: "+ maxflow.maxFlow(0, 3));
    }

}
