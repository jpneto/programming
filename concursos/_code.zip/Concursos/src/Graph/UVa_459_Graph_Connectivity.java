package Graph;

import java.io.*;
import java.util.*;

public class UVa_459_Graph_Connectivity {

	public static void main(String[] args)  throws IOException {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva459.in.txt" ));
				System.setOut(new     PrintStream("data/uva459.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);

		int nCases = sc.nextInt();
		
		while (nCases-- > 0) {
			
			int size = char2digit(sc.next().charAt(0));
			sc.nextLine();
			
			GraphMatrix g = new GraphMatrix(size, GraphMatrix.UNDIRECT);

			while(sc.hasNextLine()) {
				String edge = sc.nextLine();
				if (edge.length()==0)
					break;
				g.add(char2digit(edge.charAt(0))-1, char2digit(edge.charAt(1))-1);
			}
			
			if (nCases>0) //  not sure why this is needed?!?
				System.out.printf("%d\n\n", g.components().length);
			else          // last case
				System.out.printf("%d\n",   g.components().length);
		}
		
		sc.close();
		
	}
	
	static int char2digit(char c) {
		return (int)c - 64; // 'A' has ASCII value 65
	}
}
