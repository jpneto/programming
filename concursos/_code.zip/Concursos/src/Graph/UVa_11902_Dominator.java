package Graph;

import java.io.*;
import java.util.*;

public class UVa_11902_Dominator {

	public static void main(String[] args)  throws IOException {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva11902.in.txt" ));
				System.setOut(new     PrintStream("data/uva11902.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		Reader.init( System.in );
		
		int nCases = Reader.nextInt();

		for(int i=1; i<=nCases; i++) {
			int size = Reader.nextInt();
			
			GraphMatrix g = new GraphMatrix(size, GraphMatrix.DIRECT);    // create and read graph
			for(int row=0; row<size; row++)
				for(int col=0; col<size; col++)
					g.add(row, col, Reader.nextInt());

			StringBuffer[] output = initOutput(size);

			int[] nodesReached = g.dfs(0);
			for(int n: nodesReached)               // make first row (0 is the special node)
				output[1].setCharAt(2*n+1, 'Y');
			
			for(int node=1; node<size; node++) {          // for each remaining nodes...
				GraphMatrix cp = g.copy();
				cp.isolate(node);        // remove node, and dfs again to see what's missing
				int[] nodesNowReached = cp.dfs(0);
				for(int n : nodesReached)
					if (!contains(nodesNowReached, n))     // if n is gone, node dominates n
						output[2*node+1].setCharAt(2*n+1, 'Y');
			}

			System.out.printf("Case %d:\n", i);  	    // print output
			for(int line=0; line<output.length; line++)
				System.out.println(output[line]);
		}
	}

	static boolean contains(int[] nodesNowReached, int n) {
		for(int node:nodesNowReached)
			if (node==n)
				return true;
		return false;
	}

	static StringBuffer[] initOutput(int size) {
		StringBuffer[] sba = new StringBuffer[2*size+1];
		StringBuffer header = new StringBuffer();
		
		header.append("+");
		for(int i=0; i<2*size-1; i++) 
			header.append("-");
		header.append("+");
		
		sba[0] = header;
		for(int i=1; i<=size; i++) {
			sba[2*i-1] = new StringBuffer("|");
			for(int j=0; j<size; j++)
				sba[2*i-1].append("N|");
			sba[2*i] = header;  
		}
		return sba;
	}
	
}

///////////////////////

class Reader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(
                     new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            tokenizer = new StringTokenizer(
                   reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
}
