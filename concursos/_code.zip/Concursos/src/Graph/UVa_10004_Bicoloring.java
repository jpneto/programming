package Graph;

import java.io.*;
import java.util.*;

public class UVa_10004_Bicoloring {

	public static void main(String[] args)  throws IOException {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva10004.in.txt" ));
				System.setOut(new     PrintStream("data/uva10004.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);

		while (true) {
			int nNodes = sc.nextInt();
			if (nNodes==0)
				break;
			GraphMatrix g = new GraphMatrix(nNodes, GraphMatrix.UNDIRECT);
			
			int nEdges = sc.nextInt();
			while (nEdges-- > 0) 
				g.add(sc.nextInt(), sc.nextInt());
			
			System.out.println((g.isBipartide() ? "" : "NOT ") + "BICOLORABLE.");
		}
		
		sc.close();
	}

}
