package Graph;

import java.io.*;
import java.util.*;

// Problem: https://uva.onlinejudge.org/external/4/469.pdf
public class UVa_469_Wetlands_Florida {

	public static void main(String[] args)  throws IOException {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva469.in.txt" ));
				System.setOut(new     PrintStream("data/uva469.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);

		int nCases = sc.nextInt();  sc.nextLine(); sc.nextLine();
		
		while (nCases-- > 0) {
			String nextRow;
			
			// read grid
			ArrayList<String> l = new ArrayList<String>(); 
			l.add(sc.nextLine());  // read first row
			while(true) {
				nextRow = sc.nextLine();
				if (nextRow.charAt(0) != 'L' && nextRow.charAt(0) != 'W')
					break;
				l.add(nextRow);
			}
			
			// insert it on graph
			int size = Math.max(l.get(0).length(), l.size());
			GraphMatrix g = new GraphMatrix(size, GraphMatrix.DIRECT); // must be a direct graph
			
			for(int row=0; row<l.size(); row++)
				for(int col=0; col<l.get(0).length(); col++) 
					g.add(row, col, l.get(row).charAt(col)=='L' ? 1 : 2);  // 1=land, 2=water
			
			// read coordinates
			while(true) {
				Scanner scRow = new Scanner(nextRow);
				int r = scRow.nextInt() - 1, 
					c = scRow.nextInt() - 1;
				scRow.close();
				
				System.out.printf("%d\n", g.floodFill(r, c, 2, 3));

				nextRow = sc.hasNextLine() ? sc.nextLine() : "";
				if (nextRow.length()==0)
					break;
				g.floodFill(r, c, 3, 2);  // reset graph state
			}

			if (sc.hasNextLine())
				System.out.println();			
		}
		
		sc.close();
	}
}
