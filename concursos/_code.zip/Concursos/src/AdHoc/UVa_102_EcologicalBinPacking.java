package AdHoc;

import java.io.*;
import java.util.*;

public class UVa_102_EcologicalBinPacking {
	
	public static void main(String[] args) {

		if (1>0)    // if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0102.in.txt" ));
				System.setOut(new     PrintStream("data/uva0102.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		 
		Scanner sc = new Scanner(System.in);

		while (sc.hasNextInt()) {
			
			// solve one problem instance
			String[] lineSplited = sc.nextLine().split(" +");

			int[] bottles = new int[lineSplited.length]; 
			
			int i = 0;
			for(String str : lineSplited)
				bottles[i++] = Integer.parseInt(str);
			
	        // There are only 6 options (by lexicographic order):
			// 1. Bin 1: Brown, Bin 2: Clear, Bin 3: Green (BCG)
			// 2. BGC
			// 3. CBG
			// 4. CGB
			// 5. GBC
			// 6. GCB
			
			// compute total sum, then just subtract those that are not moving
			// the original order is (Code: Color Bin) 
			//        B1 G1 C1 B2 G2 C2 B3 G3 C3
			// index   0  1  2  3  4  5  6  7  8
			long total=0;
			for(int b:bottles)
				total += b;
			
			// assume BCG
			long result = total - bottles[0] - bottles[5] - bottles[7];
			String order = "BCG";
			
			// now let's test the others:
			long test = total - bottles[0] - bottles[4] - bottles[8];  // BGC
			if (test<result) {
				result = test;
				order = "BGC";
			}
		    
			test = total - bottles[2] - bottles[3] - bottles[7];  // CBG
			if (test<result) {
				result = test;
				order = "CBG";
			}

			test = total - bottles[2] - bottles[4] - bottles[6];  // CGB
			if (test<result) {
				result = test;
				order = "CGB";
			}

			test = total - bottles[1] - bottles[3] - bottles[8];  // GBC
			if (test<result) {
				result = test;
				order = "GBC";
			}

			test = total - bottles[1] - bottles[5] - bottles[6];  // GCB
			if (test<result) {
				result = test;
				order = "GCB";
			}

			System.out.println(order + " " + result);			
		}
		
		sc.close();
	}
}
