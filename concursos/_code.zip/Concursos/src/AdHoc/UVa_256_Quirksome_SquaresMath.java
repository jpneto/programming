package AdHoc;

import java.io.*;
import java.util.*;

/* This solution uses brute force search
 * 
 * However we could use a quadratic function to determine solutions.
 * 
 * Eg: for two digits, ie, from 00 to 99 we would have for a number split in 'ab' parts
 * 
 *    (a+b)^2 = a*10+b <=> a^2 + 2ab + b^2 = a*10+b <=> a^2 + (2b-10)*a + (b^2-b) = 0
 *    
 * so, we just need to cycle from b=0 to b=9 and save those with integer solutions at 'a'
 * 
 * The general solution is 
 * 
 * 	  (a+b)^2 = a*10^(d/2)+b <=> a^2 + 2ab + b^2 = a*10^(d/2)+b 
 *                           <=> a^2 + (2b-10^(d/2))*a + (b^2-b) = 0
 * @author jpn
 */

public class UVa_256_Quirksome_SquaresMath {
	
	/**
	 * This method solves ax^2 + bx + c = 0
	 * @return an array with the solutions of the equation
	 * (max 2 solutions; null if there are no solutions)
	 */
	public static double[] solveSecondDegreeEquation(double a, double b, double c) {
		// Result values for x 
		double[] solutions = null;

		double q = b * b - 4 * a * c;
		if (q > 0 && a != 0) {
			// case there are two roots
			solutions = new double[2];
			solutions[0] = (-b + Math.sqrt(q))/ (2 * a); 
			solutions[1] = (-b - Math.sqrt(q))/ (2 * a); 
		}
		else if (q == 0) {
			// case there is one root
			solutions = new double[1];
			solutions[0] = (-b) / (2 * a); 
		}
		else {
			// case there are no roots
		}
		return solutions;
	}

	/////////////////////////////////////////////////////////////
	
	public static void main(String[] args) {

		/// REMOVE BEFORE SUBMITION ///////////////////////////////////
		if (1>0)    // if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0256.in.txt" ));
				System.setOut(new     PrintStream("data/uva0256.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		 
		Scanner sc = new Scanner(System.in);

		// there are only four solutions, 
		// let's compute and save them in case the input repeats itself
		String[] sols = new String[4];    
		
		while (sc.hasNextInt()) {
			
			// solve one problem instance
			int digits = sc.nextInt();			

			if (sols[digits/2-1]==null) {    // if not computed yet...
				
				List<String> foundSols = new LinkedList<String>();;
				int bMax = (int)Math.pow(10, digits/2);

				StringBuffer sb = new StringBuffer();      // for increased performance 
				String format = "%0" + digits + ".0f";     // useful for leading zeros

				for(int b=0; b<bMax; b++) {

					// get quadratic solutions
					double[] aSols = solveSecondDegreeEquation(1,2*b-bMax,b*b-b);
					
					if (aSols!=null)        // if there are solutions...
						for(double a : aSols)	
							// only want integer solutions and with (digits/2) digits 
							if ((int)a == a && a < bMax)
								// compose solution & add it to list
								foundSols.add(String.format(format, a*bMax + b)); 
				}
				
				Collections.sort(foundSols);        // sort solutions for presentation purposes
				for(String sol : foundSols)        // add them into one string
					sb.append(sol+"\n");
				
				sols[digits/2-1] = sb.toString();  // save solution for future use
			}
				
			System.out.print(sols[digits/2-1]);			
		}
		sc.close();
	}
}
