package AdHoc;

import java.io.*;
import java.util.*;

/* This solution uses brute force search
 * 
 * However we could use a quadratic function to determine solutions.
 * 
 * Eg: for two digits, ie, from 00 to 99 we would have for a number split in 'ab' parts
 * 
 *    (a+b)^2 = a*10+b <=> a^2 + 2ab + b^2 = a*10+b <=> a^2 + (2b-10)*a + (b^2-b) = 0
 *    
 * so, we just need to cycle from b=0 to b=9 and save those with integer solutions at 'a'
 * 
 * @author jpn
 */

public class UVa_256_Quirksome_Squares {
	
	public static void main(String[] args) {

		/// REMOVE BEFORE SUBMITION ///////////////////////////////////
		if (1>0)    // if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0256.in.txt" ));
				System.setOut(new     PrintStream("data/uva0256.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);

		// there are only four solutions, 
		// let's compute and save them in case the input repeats itself
		String[] sols = new String[4];    
		
		while (sc.hasNextInt()) {
			
			// solve one problem instance
			int digits = sc.nextInt();			

			if (sols[digits/2-1]==null) {    // if not computed yet...
				
				StringBuffer sb = new StringBuffer();      // for increased performance 
				String format = "%0" + digits + "d";       // useful for leading zeros
				int  maxValue = (int)Math.pow(10, digits);
				int     split = (int)Math.pow(10, digits/2);

				// This cycle is where 99.9% of the computation occurs, 
				// so it must be as light as possible
				for(int i=0; i<maxValue; i++) {
					
					// given that 'i' is evenly split in parts 'ab', 
					// we wish to include only when i == (a+b)^2
					// eg: 3025 == (30+25)^2,  with i=3025, a=30, b=25
					
					int a = i/split,
						b = i%split;
					
					if (i == (a+b)*(a+b))     
						// the condition is met, add to current solutions
						sb.append(String.format(format, i)+"\n");
				}
				
				sols[digits/2-1] = sb.toString();  // save solutions for future use
			}
				
			System.out.print(sols[digits/2-1]);			
		}
		sc.close();
	}
}
