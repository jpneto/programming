package Optim;

import java.util.Arrays;

interface Gradient {
	double[] getGradient(double[] current);
	double   distance(double[] old, double[] current);
}

//////////////////////////////////////////////////////

// info: https://hbfs.wordpress.com/2012/04/24/introduction-to-gradient-descent/
public class GradientDescent {

	private static final double EPSILON = 1e-9;

	public static double[] gradientDescent(Gradient gradient, double[] initial, 
			double alpha, int maxIterations) {

		double[] old = new double[initial.length],
			 current = Arrays.copyOf(initial, initial.length);

		for (int i = 0 ; i < maxIterations; i++) {
			double distance = gradient.distance(old, current);

			if (distance < EPSILON) // it has converged
				break;

			old = Arrays.copyOf(current, current.length);

			double[] delta = gradient.getGradient(current);     // get deltas thru gradient

			//            System.out.println("current " + Arrays.toString(current));
			//            System.out.println("delta "   + Arrays.toString(delta));

			for(int theta=0; theta<current.length; theta++)  // update position with deltas
				current[theta] -= alpha * delta[theta];

			if (gradient.distance(current, old) > distance) {
				alpha *= 0.95;                        // reduce step if alpha seems too big
//				System.out.println("alpha "+ alpha);            	
			}
		}
		return current;
	}

	public static void main(String[] args) {

		int    maxIterations = 100_000;
		double alpha = 1e-5;

		Gradient g = new CubicRootGradient(729);

		double[] result = gradientDescent(g, new double[] {10}, alpha, maxIterations);

		System.out.println(Arrays.toString(result));
	}
}

//////////////////////////////////////////////////////

abstract class Gradient1D implements Gradient {
	protected double x;
	public Gradient1D(double x) { this.x = x; }

	public double distance(double[] old, double[] current) {
		return Math.abs(old[0] - current[0]);
	}
}

class SquareRootGradient extends Gradient1D implements Gradient {
	public SquareRootGradient(double x) { super(x); }

	// given x, minimize f(x;theta) = (theta^2-x)^2
	// so we need to compute df/d(theta) = 4.theta^3 - 4.x.theta
	public double[] getGradient(double[] current) {
		return new double[] {4*Math.pow(current[0],3) - 4*x*current[0]};
	}

}

class CubicRootGradient extends Gradient1D implements Gradient {
	public CubicRootGradient(double x) { super(x); }

	// given x, minimize f(x;theta) = (theta^3-x)^2
	// so we need to compute df/d(theta) = 6.theta^5 - 6.x.theta^2
	public double[] getGradient(double[] current) {
		return new double[] {6*Math.pow(current[0],5) - 6*x*current[0]*current[0]};
	}
}

