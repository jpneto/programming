package Optim;

import java.util.Arrays;
import java.util.function.BiFunction;

// https://sites.google.com/site/indy256/algo/hill_climbing
public class HillClimbing {

    public static int ROTATION_STEPS = 16;

    public static double INIT_STEPS = 1e6,
                         END_STEPS  = 1e-10;

    // first element is the minimum value, then the argument's values
    public static double[] findMinimum(BiFunction<Double, Double, Double> f) {
        double curX = 0;
        double curY = 0;
        double curF = f.apply(curX, curY);

        for (double step = INIT_STEPS; step > END_STEPS; ) {
            double bestF = curF,
                   bestX = curX,
                   bestY = curY;

            boolean find = false;

            for (int i = 0; i < ROTATION_STEPS; i++) {
                double a = 2 * Math.PI * i / ROTATION_STEPS;
                double nextX = curX + step * Math.cos(a);
                double nextY = curY + step * Math.sin(a);
                double nextF = f.apply(nextX, nextY);
                if (bestF > nextF) {
                    bestF = nextF;
                    bestX = nextX;
                    bestY = nextY;
                    find = true;
                }
            }
            if (!find) {
                step /= 2;
            } else {
                curX = bestX;
                curY = bestY;
                curF = bestF;
            }
        }
        return new double[] { curF, curX, curY };
    }

    public static void main(String[] args) {
        System.out.println(Arrays.toString(findMinimum((x, y) -> (x - 2) * (x - 2) + (y - 3) * (y - 3))));
    }
}
