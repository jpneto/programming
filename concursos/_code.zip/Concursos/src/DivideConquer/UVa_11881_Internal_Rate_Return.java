package DivideConquer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.Scanner;

public class UVa_11881_Internal_Rate_Return {
	
	private static DecimalFormat df = new DecimalFormat("0.00");
	 
    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva11881.in.txt"));
                System.setOut(new PrintStream("data/uva11881.out.txt"));
            } catch (Exception e) { }
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        while (true) {
        	int T = sc.nextInt();
        	if (T==0) break;
        	
        	int[] CF  = new int[T+1];
        	for(int i=0; i<=T; i++)
        		CF[i] = sc.nextInt();
        	
            System.out.println(solution(T, CF));
        }

        sc.close();
    }

	private static String solution(int T, int[] CF) {
		
        double Epsilon = 1e-6;
        double lo = -0.99, hi = 100.0, mid = 0.0;
        double IRR = 0.0, npv = 0.0;
        while (lo < hi + Epsilon) { // when the answer is not found yet
           mid = (lo + hi) / 2.0; // try the middle value
           npv = npv(T, CF, mid);
           if (Math.abs(npv) < Epsilon) { 
        	   IRR = mid; 
        	   break; 
           } 
           if (npv > Epsilon)
        	   lo = mid;
           else 
        	   hi = mid;
        }
        
        if(Math.abs(IRR+1.0)<Epsilon)
        	return "No";
        else
        	return df.format(IRR);
		
	}
	
	private static double npv(int T, int[] CF, double IRR) {
	    double npv = CF[0];
	    for (int i = 1; i <= T; i++)
	        npv += CF[i] / Math.pow(1.0 + IRR, i);
	    
	    return npv;
	}
}
