package DivideConquer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class UVa_12190_ElectricBill {
    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva12190.in.txt"));
                System.setOut(new PrintStream("data/uva12190.out.txt"));
            } catch (Exception e) { }
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);
        while (true) {
        	long total = sc.nextInt();
        	long diff  = sc.nextInt();
        	if (total==0 && diff==0)
        	   break;
            System.out.println(solution(total, diff));
        }
        sc.close();
    }

    // the cost of using watts
    private static long bill(long watts) {
    	long result = 0;
    	
    	if (watts <= 100)
    		return 2*watts;
    	else
    	    result += 2*100;
    	
    	if (watts <= 10_000)
    		return result + 3*(watts-100);
    	else
    		result += 3*(10_000 - 100);
    	
    	if (watts <= 1_000_000)
    		return result + 5*(watts-10_000);
    	else
    		result += 5*(1_000_000 - 10_000);
    	
    	return result + 7*(watts-1_000_000);
    	
    }
    
	private static long solution(long total, long diff) {
		long result=0;
		// first, find the total amount of energy used by both
		long lo = 0, hi = total, mid = 0, ans = 0;
        while (lo<=hi) {        // when the answer is not found yet
           mid = (lo + hi) / 2; // try the middle value
           long cost = bill(mid); 
           if (cost==total) {   // found the answer!
        	   ans = mid;
        	   break;
           }
          
           if (cost>total) 
        	   hi = mid-1; 
           else 
        	   lo = mid+1;
        }	
        
        // second, find my cost (cost1) compatible with 'diff'
        lo = 0; hi = ans;
        while (lo<=hi) {        // when the answer is not found yet
           mid = (lo + hi) / 2; // try the middle value
           long cost1 = bill(mid);      // your cost (must be the smaller value)
           long cost2 = bill(ans-mid);  // your neighbour's cost
           if (cost2 - cost1 == diff) {   // found the answer!
        	   result = cost1;
        	   break;
           }
           
           if (cost1>cost2 || cost2-cost1<diff) 
        	   hi = mid-1; 
           else 
        	   lo = mid+1;
        }	        

		return result;
	}
}
