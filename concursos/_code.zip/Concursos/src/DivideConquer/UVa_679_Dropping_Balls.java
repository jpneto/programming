package DivideConquer;

import java.io.*;
import java.util.*;

public class UVa_679_Dropping_Balls {

    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva0679.in.txt"));
                System.setOut(new PrintStream("data/uva0679.out.txt"));
            } catch (Exception e) { }
        ///////////////////////////////////////////////////////////////
        
        Scanner sc = new Scanner(System.in);
        
        int nTests = sc.nextInt();
        
		while (nTests-- > 0) {
			
			int depth = sc.nextInt();
			int ball  = sc.nextInt();
			
			System.out.println(solve(depth, ball));
		}
		
		sc.close();
    }

    /* this was done noticing the patterns of the sequence of balls, from the first to last
     * Eg, for depth 4, the balls fall in the sequence 8 12 10 14 9 13 11 15
     * if we model a left fall as a 0 and a right fall as a 1, the sequence of falls are
     * 000 100 010 110 001 101 011 111 which is binary for the counting 
     * from 0 to 7 (if we read the bits from right to left). If we add an extra left bit:   
     * 1000 1100 1010 1110 1001 1101 1011 1111 we get all the answers in binary!
     * Not sure why it works, thou...
     */
	private static int solve(int depth, int ball) {
		int[] bits = new int[depth];
		
		ball--;          // first ball counts as zero, second ball as one, etc.
		int idx = 1;
		while(ball>0) {  // convert integer ball to its binary expression
			bits[idx++] = ball % 2;
			ball = ball/2;
		}
		bits[0] = 1;     // the extra left bit
		
		int result=0;
		for(int i=bits.length-1, power=1; i>=0; i--, power*=2)
			result += bits[i] * power;
		return result;
	}
}
