package DivideConquer;

import java.util.function.*;

// ref: https://sites.google.com/site/indy256/algo/binary_search
public class BinarySearch {

    public static int binSearch(IntPredicate p, int[] v, int fromInclusive, int toExclusive) {
        int lo = fromInclusive;
        int hi = toExclusive;
        while (lo < hi) {
            int mid = (lo & hi) + ((lo ^ hi) >> 1);
            if (!p.test(v[mid]))
                lo = mid + 1;
            else
                hi = mid;
        }
        return hi; // returns index where is the element satisfying the predicate
    }

    public static void main(String[] args) {
        int[] test = new int[] {13,16,54,100,897,1024};

        System.out.println(binSearch(x -> x==100,  test, 0, 6));
        System.out.println(binSearch(x -> x*x>400, test, 0, 6)); // returns the 1st one that satisfy the predicate
    }
}

