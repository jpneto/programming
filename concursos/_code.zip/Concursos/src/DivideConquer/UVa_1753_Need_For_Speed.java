package DivideConquer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.Scanner;

public class UVa_1753_Need_For_Speed {
	
	static DecimalFormat df = new DecimalFormat("0.000000000");
	
	static double Epsilon = 1e-12;
	
    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva1753.in.txt"));
                System.setOut(new PrintStream("data/uva1753.out.txt"));
            } catch (Exception e) { }
        ///////////////////////////////////////////////////////////////
        
        Scanner sc = new Scanner(System.in);
        
		while (sc.hasNext()) {
			int n = sc.nextInt();
			int t = sc.nextInt();
			int[] s = new int[n];
			int[] d = new int[n];
			double min = Integer.MAX_VALUE, max = Integer.MAX_VALUE;
			for (int i = 0; i < n; i++) {
				d[i] = sc.nextInt();
				s[i] = sc.nextInt();
				if (s[i] < min)
					min = s[i];
			}
			System.out.println(df.format(solution(s, d, -min, max, t)));
		}
		
		sc.close();
    }
    
    static double solution(int s[], int d[], double min, double max, double t) {
		double pre = -1;  // will keep previous mid value
		
		while (max >= min) {
			double mid = min + (max - min) / 2;
			
			if (pre == mid) // mid didn't change, so return answer
				return mid;
			pre = mid;
			
			// simulate the run with speed s+mid and check total time
			double res = 0;
			for (int i = 0; i < s.length; i++)
				res += d[i] / (s[i] + mid);

			// check if solution is close enough
			if (Math.abs(res - t) <= Epsilon)
				return mid;

			if (res < t)
				max = mid;
			else
				min = mid;
		}
		
		return -1; // unreachable code
	}

}
