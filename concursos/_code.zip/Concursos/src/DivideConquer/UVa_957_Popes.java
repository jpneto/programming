package DivideConquer;

import java.io.*;
import java.util.*;

public class UVa_957_Popes {
	public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0957.in.txt" ));
				System.setOut(new     PrintStream("data/uva0957.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		Reader.init( System.in );
		
		boolean stop = false;
		do  {
			
			int period=0;
			
			try {
				period = Reader.nextInt();
			} catch (Exception e) {
				stop=true;
			}
			
			if (stop) break;
			
			int nPopes  = Reader.nextInt();
			int[] elections = new int[nPopes];
			for(int i=0; i<nPopes; i++)
				elections[i] = Reader.nextInt();
			
			solve(period, elections);
			
		} while (true);
	}

	/* Complete search for all popes in set (with size N)
	 * then binary search each pope to find last date
	 * @complexity O(N log N)
	 */
	private static void solve(int period, int[] elections) {
		int maxStart=0, maxEnd=0, maxPopes=0;
		
		for(int i=0; i<elections.length; i++) {
			int start = elections[i];
			int end   = start + period - 1;
			
			int index = Arrays.binarySearch(elections, end);
			
			// if elements are repeated (several popes in the same year)
			// binary search will give any one of those indexes, 
			// so we must go to the last  
			while (index >= 0 
				&& index < elections.length-1 
				&& elections[index+1] == elections[index])
				index++;
			
			// binary search will output negative if not found (check its javadoc)
			int interval = index > 0 ? index - i + 1 : -index - i - 1;
			
			if(interval > maxPopes) {
				maxPopes = interval;
				maxStart = elections[i];
				maxEnd   = elections[i+interval-1]; 
			}
		}
		System.out.println(maxPopes + " " + maxStart + " " + maxEnd);
	}
}



/** Class for buffered reading int and double values
 *  Ref: https://www.cpe.ku.ac.th/~jim/java-io.html 
 */
class Reader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer( reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
    
    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
  
}