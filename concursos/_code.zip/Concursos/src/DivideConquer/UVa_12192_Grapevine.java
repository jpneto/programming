package DivideConquer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class UVa_12192_Grapevine {
    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva12192.in.txt"));
                System.setOut(new PrintStream("data/uva12192.out.txt"));
            } catch (Exception e) { }
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);
        
        while (true) {
            int N = sc.nextInt();
            int M = sc.nextInt();
            
            if(N==0 && M==0)
            	break;
            
            int[][] grid = new int[N][M];
            for(int i=0; i<N; i++)
            	for(int j=0; j<M; j++)
            		grid[i][j] = sc.nextInt(); 
            
            int nCases = sc.nextInt();
            		
            while (nCases-- > 0) {
            	int L = sc.nextInt();
            	int U = sc.nextInt();
            	System.out.println(solution(grid, N, M, L, U));
            }
            
            System.out.println("-");        	
        }

        sc.close();
    }

	private static int solution(int[][] grid, int N, int M, int L, int U) {
		int result=0;
		
		for(int row = 0; row < N; row++) {
			// at this row, find the upper-left corner which is >= L
			int col = -1, lo = 0, hi = M-1, cur = -1;
			while (lo <= hi)	{
				int mid = (lo+hi) / 2 ;
				if (grid[row][mid] >= L)	{
					col = mid;
					hi = mid-1;
				} else
					lo = mid+1;
			}
			
			// if some corner was found, find the largest possible square
			// where the bottom-right corner is <= U
			// this bissection method is wrt the size of the result square
			if(col != -1) {
				lo = 1; hi = Math.min(N-row, M-col);
				while (lo <= hi)	{
					int mid = (lo+hi) / 2;
					if (grid[row+mid-1][col+mid-1] <= U) {
						cur = mid;
						lo = mid+1;
					} else
						hi = mid-1;
				}
				// the problem asks for the side of the square
				result = Math.max(result, cur);
			}
		}

		return result;
	}
}
