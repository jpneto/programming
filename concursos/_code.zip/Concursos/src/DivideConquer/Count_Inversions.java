package DivideConquer;

// measure of how far (or close) the array is from being sorted

// useful also for comparing two different ranks
// eg: comparing five produts {A,B,C,D,E} 
//   rank1 = {D,E,A,C,B}
//   rank2 = {A,D,E,B,C}
// we would consider the rank1 as the indexes of a vector, and place
// the rank2 values on those indexes:
//   vector = {2,3,1,5,4} , eg, A is 1st ranked on rank2 was placed on index 3
// the difference measure is the the number of inversions, here, 3 
public class Count_Inversions {

	public static int countInversions(int[] a) {
      return mergeSort(a, 0, a.length);
  }

  private static int mergeSort (int[] a, int low, int high) {
    if (low == high-1) 
		  return 0;

    int mid = (low + high)/2;

    return mergeSort (a, low, mid) + mergeSort (a, mid, high) + 
       	   merge (a, low, mid, high);
  }

  private static int merge (int[] a, int low, int mid, int high) {
      int count = 0;
      int[] temp = new int[a.length];

     for (int i = low, lb = low, hb = mid; i < high; i++)

          if (hb >= high || lb < mid && a[lb] <= a[hb]) {
              temp[i]  = a[lb++];
          } else {
              count = count + (mid - lb);  
              temp[i]  = a[hb++];          
          } 

     System.arraycopy(temp, low, a, low, high - low);
     return count;
  }
    
	public static void main(String[] args) {
		System.out.println(countInversions(new int[] {1,3,5,2,4,6}));
	}

}
