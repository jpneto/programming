package DivideConquer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

// TODO: not solved

public class UVa_11935_Through_Desert {
	
	private static enum Events {FUEL, GOAL, LEAK, GAS, MECHANIC};
	private static Events[] event = new Events[50];
	private static int[] distance  = new int[50];
	private static int[] consumption = new int[50];
	private static int nOrders;
	
	public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {
        }.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva11935.in.txt"));
                System.setOut(new PrintStream("data/uva11935.out.txt"));
            } catch (Exception e) {
            }
        ///////////////////////////////////////////////////////////////


        Scanner sc = new Scanner(System.in);

        int i=0;
        while(sc.hasNextLine()) {
           
        	distance[i] = sc.nextInt();
        	String[] order = sc.nextLine().split(" ");
        	
        	switch (order[1]) {
        	case "Fuel" : 
        		consumption[i] = Integer.parseInt(order[3]);
        		event[i++] = Events.FUEL;
        		break;
        	case "Leak" : 
        		event[i++] = Events.LEAK;
        		break;
        	case "Gas" : 
        		event[i++] = Events.GAS;
        		break;
        	case "Mechanic" : 
        		event[i++] = Events.MECHANIC;
        		break;
        	case "Goal" : 
        		event[i++] = Events.GOAL;
        		nOrders = i;
        		System.out.printf("#.3f", computeSolution());
        		i=0;
        		break;
        	}       	
        }
        

        sc.close();
        

    }

	private static double computeSolution() {
        double Epsilon = 1e-6;
        double lo = 0.0, hi = 10000.0, mid = 0.0, ans = 0.0;
        while (Math.abs(hi - lo) > Epsilon) { // when the answer is not found yet
           mid = (lo + hi) / 2.0; // try the middle value
           if (simulate(mid)) { 
        	   ans = mid; 
        	   hi = mid; 
           } 
           else lo = mid;
        }
        return ans;
	}

	private static boolean simulate(double tank) {
		
		return false;
	}
}
