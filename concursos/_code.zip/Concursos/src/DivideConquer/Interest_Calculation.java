package DivideConquer;

import java.io.FileNotFoundException;

public class Interest_Calculation {

	public static void main(String[] args) throws FileNotFoundException {

    System.out.printf("%4.2f\n", leftDebt(555, 20, 10000.0, 1.01));
		
		System.out.printf("%4.2f\n", findMonthlyPayment(20, 1000.0, 1.01));
		System.out.printf("%4.2f\n", findMonthlyPaymentExact(20, 1000.0, 1.01));

	}

	private static double leftDebt(double monthlyPayment, 
							       int months, 
								   double total, 
								   double monthlyInterest) {
		double debt = total;

		for(int i=0; i<months; i++)
			debt = debt*monthlyInterest - monthlyPayment;

		return debt;
	}
	
	// ref: https://www.vertex42.com/ExcelArticles/amortization-calculation.html
	private static double findMonthlyPaymentExact(int months, 
												  double total, 
												  double monthlyInterest) {
		double r = monthlyInterest-1;
		double n = months;
		return total * (r*Math.pow(1+r,n) / (Math.pow(1+r,n)-1));
	}

	private static double findMonthlyPayment(int months, 
											 double total, 
											 double monthlyInterest) {
    double Epsilon = 1e-6;
		double lo = 0.0, hi = total, mid = 0.0, ans = 0.0;
		
		while (lo < hi + Epsilon) { // when the answer is not found yet
			mid = (lo + hi) / 2.0;    // try the middle value
			double debt = leftDebt(mid, months, total, monthlyInterest); 
			if (Math.abs(debt) < Epsilon) { 
				ans = mid; 
				break;
		  }
			if (debt > 0) 
				lo = mid;
			else 
				hi = mid;
		}
		return ans;
	}
}
