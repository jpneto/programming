package DivideConquer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.Scanner;

//TODO: not solved

public class UVa_10369_Arctic_Network {

	private static DecimalFormat df = new DecimalFormat("0.00");
	
	public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva10369.in.txt"));
                System.setOut(new PrintStream("data/uva10369.out.txt"));
            } catch (Exception e) { }
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        int nCases = sc.nextInt();
        
        while(nCases-- > 0) {
        	
        	int nSats  = sc.nextInt();
        	int nPosts = sc.nextInt();
        	
        	int[] xPosts = new int[nPosts];
        	int[] yPosts = new int[nPosts];
        	
        	for(int i=0; i<nPosts; i++) {
        		xPosts[i] = sc.nextInt();
        		yPosts[i] = sc.nextInt();
        	}
        	
        	System.out.println(df.format(solution(nSats, xPosts, yPosts, 0, 10_000)));
        	
        }

        sc.close();
    }

	private static double solution(int nSats, int[] xPosts, int[] yPosts, int lo, int hi) {
		double result= 0.0; 
		
		

		return result;
	}

}
