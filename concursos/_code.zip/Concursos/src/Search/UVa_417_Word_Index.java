package Search;

import java.io.*;
import java.util.*;

public class UVa_417_Word_Index {
	
	private static Map<String, Integer> words = new HashMap<>();
	private static int id = 1;
	
	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0417.in.txt" ));
				System.setOut(new     PrintStream("data/uva0417.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		 
		for(int len=1; len<=5; len++)  // do it once for all words
		  listValidWords("", len);
		
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {  
			String word = sc.next();
 		    System.out.printf("%d\n", words.containsKey(word) ? words.get(word) : 0);
		}
		sc.close();
	}

	private static void listValidWords(String word, int len) {
		if(word.length()==len)  // the word is complete, keep it
			words.put(word, id++);
   	    else			
			for(char c=startLetter(word); c<='z'; c=nextLetter(c))
				listValidWords(word+c, len);
	}
	
	private static char startLetter(String word) {
		return word.isEmpty() ? 'a' : nextLetter(word.charAt(word.length()-1));
	}
	
	private static char nextLetter(char c) {
		return (char)(c+1);
	}	
}