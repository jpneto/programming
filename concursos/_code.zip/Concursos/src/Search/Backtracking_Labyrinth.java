package Search;

import java.util.LinkedList;

/**
 * Created by jpn on 10-02-2017.
 */
public class Backtracking_Labyrinth {

    static final int[]  row = {  0,  0, +1, -1};
    static final int[]  col = { +1, -1,  0,  0};
    static final char[] dir = {'E','W','S','N'};

    static final char EXIT = '!';
    static final char WALL = '*';

    static boolean isExit(int l, int c) {
        return labyrinth[l].charAt(c) == EXIT;
    }
    static boolean isWall(int l, int c) {
        return labyrinth[l].charAt(c) == WALL;
    }

    static String[] labyrinth  = {
            "********",
            "*      *",
            "*** ** *",
            "*    ***",
            "* **** *",
            "* *    *",
            "*     !*",
            "********"};

    static boolean[][] crossed;
    static LinkedList<Character> solution;

    static boolean backtrack(int l, int c) {

        if (isWall(l,c) || crossed[l][c])
            return false;

        crossed[l][c] = true;    // visiting this cell, don't want to go here twice

        for(int i=0; i<dir.length; i++)      // for each direction
            if (backtrack(l+row[i], c+col[i])) {
                solution.addFirst(dir[i]);   // found a way!
                return true;
            }

        if (isExit(l,c)) {
            solution.addFirst(EXIT);
            return true;
        }

        return false;
    }

    public static void main(String[] args) {

        crossed = new boolean[labyrinth.length][labyrinth[0].length()];
        solution = new LinkedList<Character>();

        if (backtrack(1,1))
            System.out.println(solution);
        else
            System.out.println("no path exists");
    }
}