package Search;

import java.io.*;
import java.util.*;

public class UVa_10503_Dominoes_Solitaire {
	
	public static class Domino {
		int side1, side2;
		
		public Domino(int a, int b) {
			side1=a; side2=b;
		}
	}
	
	private static boolean found;

	public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva10503.in.txt" ));
				System.setOut(new     PrintStream("data/uva10503.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		Scanner sc = new Scanner(System.in);
		
		while (true) {
			
			int nSpaces = sc.nextInt();
			
			if (nSpaces==0)
				break;
			
			int nPieces = sc.nextInt();
			
			int pieceBegin1 = sc.nextInt();
			int pieceBegin2 = sc.nextInt();
			int pieceEnd1   = sc.nextInt();
			int pieceEnd2   = sc.nextInt();
				
			LinkedList<Domino> dominoes = new LinkedList<>();
			for(int i=0; i<nPieces; i++)
				dominoes.addFirst(new Domino(sc.nextInt(), sc.nextInt()));
			
			// backtrack all four possibilities, if needed
			found=false;
			int[] sequence = new int[nSpaces*2+1];
			
			// the problem is poorly stated: the middle dominoes can rotate
			// but the first and last cannot (!)
			
//			if (!found) {			
//				sequence[0] = pieceBegin1;
//				solve(pieceEnd1, dominoes, sequence, 0);
//			}
//			
//			if (!found) {
//				sequence[0] = pieceBegin1;
//				solve(pieceEnd2, dominoes, sequence, 0);
//			}
			
			if (!found) {
				sequence[0] = pieceBegin2;
				solve(pieceEnd1, dominoes, sequence, 0);
			}

//			if (!found) {
//				sequence[0] = pieceBegin2;			
//				solve(pieceEnd2, dominoes, sequence, 0);
//			}
			
			System.out.println(found ? "YES" : "NO");
		}
		
		sc.close();
	}

	/**
	 * 
	 * @param end the value that the right side of the last domino should have
	 * @param dominoes the remaining dominoes still available
	 * @param sequence the path built so far
	 * @param idxSequence where are we in the path (determines a partial/total solution)
	 */
	private static void solve(int end, LinkedList<Domino> dominoes,
			                  int[] sequence, int idxSequence) {
		
		if (idxSequence == sequence.length-1) {
			if (sequence[idxSequence]==end)
				found = true;
			return;
		}
		
		for(int i=0; i<dominoes.size(); i++) {		
			Domino d = dominoes.get(i);
			if (d.side1 == sequence[idxSequence]) {
				dominoes.remove(i);
				sequence[idxSequence+1] = d.side1;
				sequence[idxSequence+2] = d.side2;
				solve(end, dominoes, sequence, idxSequence+2);
				sequence[idxSequence+1] = 0;
				sequence[idxSequence+2] = 0;
				dominoes.add(i, d);
			} else if (d.side2 == sequence[idxSequence]) {
				dominoes.remove(i);
				sequence[idxSequence+1] = d.side2;
				sequence[idxSequence+2] = d.side1;
				solve(end, dominoes, sequence, idxSequence+2);
				sequence[idxSequence+1] = 0;
				sequence[idxSequence+2] = 0;
				dominoes.add(i, d);
			} 
		}
	}
}
