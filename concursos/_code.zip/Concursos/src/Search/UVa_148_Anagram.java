package Search;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class UVa_148_Anagram {
	
	
	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0148.in.txt" ));
				System.setOut(new     PrintStream("data/uva0148.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		 
		Scanner sc = new Scanner(System.in);
		
		String[] dict = new String[2000];
		int sizeDict = 0;

		while (true) {  // read dictionary
			String line = sc.nextLine();
			
			if (line.equals("#"))
				break;
			
			dict[sizeDict++] = line;
		}
		
		while (true) {  // read each original phrase
			String phrase = sc.nextLine();
			
			if (phrase.equals("#"))
				break;
			
			solve(dict, sizeDict, phrase);
		}
		
		sc.close();
	}

    /////////////////////////////////
	private static void solve(String[] dict, int sizeDict, String phrase) {
		LetterBag bag = new LetterBag();
		bag.add(phrase);
		
		// will keep indexes of the saved dictionary words
		int[] savedWords = new int[20];
		
		findSolutions(dict, sizeDict, 0, bag, savedWords, 0, phrase);
	}

	/**
	 * Backtracking all solutions
	 * @param dict        the dictionary (does not change)
	 * @param sizeDict    the size of the dictionary (does not change)
	 * @param wordIdx     the index of the current dictionary word being considered 
	 * @param bag         a bag with the remaining letters (if empty => got a solution)
	 * @param savedWords  the indexes of the saved words for this backtracking path
	 * @param nSavedWords how many words are saved
	 * @param phrase      the original phrase (does not change)
	 */
	private static void findSolutions(String[] dict, int sizeDict, 
			                          int wordIdx, LetterBag bag, 
			                          int[] savedWords, int nSavedWords,
			                          String phrase) {

		if (bag.isEmpty()) {
			printWords(dict, savedWords, nSavedWords, phrase);
			return;
		}
		
		if (wordIdx == sizeDict) // nothing else to search
			return;
		
		for(int i=wordIdx; i<sizeDict; i++) {
			if (bag.includes(dict[i])) {
				bag.del(dict[i]);
				savedWords[nSavedWords++] = i;
				
				findSolutions(dict, sizeDict, i+1, bag, savedWords, nSavedWords, phrase);
				
				savedWords[nSavedWords--] = 0;
				bag.add(dict[i]);
			} 
		}

	}

	private static void printWords(String[] dict, int[] savedWords, int nSavedWords, String phrase) {
		StringBuilder sb = new StringBuilder();
		
		for(int i=0; i<nSavedWords; i++)
			sb.append(dict[savedWords[i]]).append(" ");
		
		String anagram = sb.toString();
		
		String[] words1 = phrase.split(" ");
		//Arrays.sort(words1);

		String[] words2 = anagram.split(" ");
		//Arrays.sort(words2);

		boolean anyEquals = false;
		for(int i=0; i<words1.length && !anyEquals; i++)
			for(int j=0; j<words2.length && !anyEquals; j++)
				if (words1[i].equals(words2[j]))
					anyEquals = true;
		
		if (!anyEquals) {
			anagram = anagram.substring(0, anagram.length() - 1);
			System.out.println(phrase + " = " + anagram);
		}
	}
}

/////////////////////////////////

class LetterBag {
	
	int[] occurrences;
	
	public LetterBag() {
		// empty bag
		occurrences = new int[26];
	}
	
	public void add(String s) {
		char[] cs = s.toCharArray();
		
		for(int i=0; i<cs.length; i++)
			if (cs[i]!=' ')  // don't add spaces
				occurrences[(int)cs[i]-65]++; //eg, 'A' is ascii of 65
	}
	
	//pre: includes(s)
	public void del(String s) {
		char[] cs = s.toCharArray();
		
		for(int i=0; i<cs.length; i++)
			occurrences[(int)cs[i]-65]--; //eg, 'A' is ascii of 65
	}
	
	public boolean isEmpty() {
		int count = 0;
		
		for(int i=0; i<occurrences.length; i++)
			count += occurrences[i];
		return count == 0;
	}
	
	public boolean includes(String s) {
		char[] cs = s.toCharArray();
		int[] copy = occurrences.clone();
		
		// if we removed 's', would there be any negative numbers?
		for(int i=0; i<cs.length; i++)
			copy[(int)cs[i]-65]--;
		
		for(int i=0; i<copy.length; i++)
			if (copy[i]<0)
				return false;
		return true;
	}
	
}