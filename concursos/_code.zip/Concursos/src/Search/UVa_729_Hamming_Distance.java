package Search;

import java.io.*;
import java.util.*;

public class UVa_729_Hamming_Distance {

	public static final int MAX_SIZE = 16;
	
	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0729.in.txt" ));
				System.setOut(new     PrintStream("data/uva0729.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		Scanner sc = new Scanner(System.in);

		int nDatasets = sc.nextInt();
	
		while (nDatasets-- > 0) {  

			int N = sc.nextInt();
			int H = sc.nextInt();
			
			// backtrack 
			solve(N, H, new int[MAX_SIZE], 0, 0);
			
			if(nDatasets>0) // last dataset should not have an extra newline
				System.out.println();
		}

		sc.close();
	}

	/**
	 * Backtracking all bitstring of size N with hamming distance of H from bit string 0
	 * @param N  The size of the bit string (does not change)
	 * @param H  The required Hamming distance (does not change)
	 * @param bitString The current bitstring used to map the backtrack path
	 * @param nBit  How many bits 'bitString' has
	 * @param nOnes How many ones 'bitString' has
	 */
	private static void solve(int N, int H, int[] bitString, int nBit, int nOnes) {
		
		if (nOnes==H) {
			printSolution(N, bitString);
			return;
		}
		
		if (nBit==N)
			return;
		
		solve(N, H, bitString, nBit+1, nOnes  );
		bitString[nBit] = 1;
		solve(N, H, bitString, nBit+1, nOnes+1);
		bitString[nBit] = 0;		
	}

	private static void printSolution(int N, int[] bitString) {
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<N; i++)
			sb.append(bitString[i]);
		System.out.println(sb);		
	}

}
