package Search;

import java.io.*;
import java.util.*;

public class UVa_574_Sum_It_Up {
	
	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0574.in.txt" ));
				System.setOut(new     PrintStream("data/uva0574.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		 
		Scanner sc = new Scanner(System.in);
		
		while (true) {  
			int t = sc.nextInt();
			int n = sc.nextInt();
			
			if (t==0 && n==0)
				break;
			
			Integer[] xs = new Integer[n];
			for(int i=0; i<n; i++)
				xs[i] = sc.nextInt();

			// sort by decreasing order
			Arrays.sort(xs, Collections.reverseOrder());
			
			// print header
			System.out.println("Sums of " + t + ":");
			
			// the problem states that no solution is to be repeated
			// I chose to keep all solutions found so far, to check for repetitions
			// we will print the solution at the end, after the backtracking ends
			
			// hopefully this next vector (to keep all solutions) is big enough
			// we could have used another data structure, like a linked list
			String[] sols = new String[10_000]; 
					
			// backtrack all possible sums of t (cf method's javadoc for details)
		    solve(t, xs, 0, new int[xs.length], 0, 0, sols);
		    
			if (sols[0] == null)
				System.out.println("NONE");
			else
				for(String s : sols)
					if (s != null)
					   System.out.println(s);
					else
						break;
		}
		
		sc.close();
	}

	/**
	 * Backtracking method
	 * @param t           the total (does not change)
	 * @param xs          all the input options (does not change)
	 * @param currentIdx  what is the index of the current option being considered
	 * @param saved       the numbers we saved so far, for this backtracking path
	 * @param nSaved      how many numbers are saved
	 * @param currentSum  the current sum of the saved numbers (faster to keep this sum)
	 * @param sols        the string of solutions found so far
	 */
	private static void solve(int t, 
			                  Integer[] xs, int currentIdx,
			                  int[] saved, int nSaved, int currentSum, 
			                  String[] sols) {
		if (t == currentSum)
			// found a solution, let's add it to 'sols' (if not repeated)
			saveSolution(saved, nSaved, sols);

		// no more options to consider, backtrack
		if (currentIdx == xs.length)
			return;
		
		for(int i=currentIdx; i<xs.length; i++) {
			// the sum with this number would be bigger than t, skip it
			if (xs[i]+currentSum > t)
				continue;
			
			saved[nSaved++] = xs[i];
			solve(t, xs, i+1, saved, nSaved, currentSum+xs[i], sols);
			saved[--nSaved] = 0;
		}
	}

	private static void saveSolution(int[] saved, int nSaved, String[] sols) {

		// create string
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<nSaved-1; i++)
		  sb.append(saved[i]).append("+");	
		sb.append(saved[nSaved-1]);
		String newSolution = sb.toString();
		
		// check if string already exists; if not, add it
		boolean found = false;
		int count = 0;
		for(String s : sols) {
			if (s != null) {
				count++;
			    if (s.equals(newSolution))
				   found = true;
			} else break;
		}
		
		if (!found)
			sols[count] = newSolution;
	}
}