package Search;

import java.io.*;
import java.util.*;

public class UVa_167_Sultan {
    static final int SIZE = 8;  // board size
    
    static int maxScore; 

    // is it feasible to place the n-th queen there?
    public static boolean isFeasible(int[] queen_positions, int n) {

        for (int i=0; i<n; i++)
            if ((queen_positions[i] == queen_positions[n])           ||  // same row
                (queen_positions[i] - queen_positions[n]) == (n - i) ||  // same major diagonal
                (queen_positions[n] - queen_positions[i]) == (n - i))    // same minor diagonal
              return false;

        return true;
    }

    public static void backtrack(int[][] board, int[] queen_positions, int k) {

        if (k == SIZE) {
            int score = computeResult(board, queen_positions);
            if (score > maxScore)
            	maxScore = score;
            return;
        }

        for (int i=0; i<SIZE; i++) {
            queen_positions[k] = i;
            if (isFeasible(queen_positions, k))
                backtrack(board, queen_positions, k+1);
        }
    }

    public static int computeResult(int[][] board, int[] queen_positions) {
    	int score = 0;
    	for (int i=0; i<SIZE; i++)
    		score += board[i][queen_positions[i]];
    	return score;
    }

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0167.in.txt" ));
				System.setOut(new     PrintStream("data/uva0167.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		 
		Scanner sc = new Scanner(System.in);
		
		int nCases = sc.nextInt();
		int[][] board = new int[SIZE][SIZE];

		while (nCases-- > 0) {  
			maxScore = 0;
			
			for(int i=0; i<SIZE; i++)
				for(int j=0; j<SIZE; j++)
					board[i][j] = sc.nextInt();
			
			backtrack(board, new int[SIZE], 0);
			System.out.printf("%5d\n", maxScore);
		}
		
		sc.close();
	}
}
