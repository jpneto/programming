package Search;

import java.io.*;
import java.util.*;

public class UVa_301_Transportation {
	
	static class Ticket {
		public int start, end, nPassagers; 

		Ticket(int a, int b, int c) {
			start=a; end=b; nPassagers=c;
		}
	}
	
	public static int maxValue;
	
	public static void main(String[] args) throws IOException {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0301.in.txt" ));
				System.setOut(new     PrintStream("data/uva0301.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		Reader.init( System.in );
		
		while (true) {
			
			int capacity  = Reader.nextInt();
			int nStations = Reader.nextInt();
			int nTickets  = Reader.nextInt();
			
			if (capacity+nStations+nTickets==0)
				break;
			
			Ticket[] tickets = new Ticket[nTickets];
			
			for(int i=0; i<nTickets; i++)
				tickets[i] = new Ticket(Reader.nextInt(), Reader.nextInt(), Reader.nextInt());

			// backtrack 
			maxValue = 0;
			solve(capacity, nStations, tickets, new int[2*nStations], 0, 0);
			System.out.println(maxValue);
		}
	}

	/**
	 * The trick here is to represent he train occupation in a way to do a fast check 
	 * if the next ticket is feasible. For that, each middle station is split in two
	 * positions, one arriving and one leaving.
	 * So if a ticket enters a station 1 and leaves at station 3 with 5 persons that
	 * would be represent as  0 0 5 5 5 5 0 0 ... where the zero at index 1 represents
	 * clients leaving at station 1. This way, two tickets one arriving and one
	 * leaving the same station, do not interfere. This makes it much easier to check
	 * for incompatibilities. 
	 * 
	 * @param capacity the train capacity (does not change)
	 * @param nStations the number of stations (does not change)
	 * @param tickets an array with all tickets (does not change)
	 * @param occupation what is the current train occupation
	 * @param currentTicket what is the ticket we are considering?
	 * @param price the price of the current occupation
	 */
	private static void solve(int capacity, int nStations, Ticket[] tickets, 
			                 int[] occupation, int currentTicket, int price) {
		
		if (price > maxValue) // found a better price? keep it!
			maxValue = price;

		if (currentTicket == tickets.length) 
			return;
			
		for(int i=currentTicket; i<tickets.length; i++) {
			if (!isFeasible(capacity, occupation, tickets[i]))
				continue;
			
			// check result if this ticket is included
			addTo(occupation, tickets[i]);
			solve(capacity, nStations, tickets, occupation, i+1, price+getPrice(tickets[i]));
			removeFrom(occupation, tickets[i]);
		}
	}

	private static int getPrice(Ticket ticket) {
		return (ticket.end - ticket.start) * ticket.nPassagers;
	}

	private static void addTo(int[] occupation, Ticket ticket) {
		int size = 2*(ticket.end - ticket.start);
		for(int i=ticket.start*2; i<ticket.start*2+size; i++)
			occupation[i] += ticket.nPassagers;		
	}

	private static void removeFrom(int[] occupation, Ticket ticket) {
		int size = 2*(ticket.end - ticket.start);
		for(int i=ticket.start*2; i<ticket.start*2+size; i++)
			occupation[i] -= ticket.nPassagers;		
	}

	private static boolean isFeasible(int capacity, int[] occupation, Ticket ticket) {
		int size = 2*(ticket.end - ticket.start);
		for(int i=ticket.start*2; i<ticket.start*2+size; i++)
			if(occupation[i] + ticket.nPassagers > capacity)
				return false;
		return true;
	}   
}

/** Class for buffered reading int and double values
 *  Ref: https://www.cpe.ku.ac.th/~jim/java-io.html 
 */
class Reader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader( new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer( reader.readLine() );
        }
        return tokenizer.nextToken();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }
    
    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
  
}