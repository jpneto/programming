package Search;

public class Backtracking_Permutations {

	// Utility function to swap two characters in a character array
	private static void swap(char[] ch, int i, int j) {
		char temp = ch[i];
		ch[i] = ch[j];
		ch[j] = temp;
	}

	// Recursive function to generate all permutations of a String
	private static void permutations(char[] str, int index) {
		
		if (index == str.length - 1)
			System.out.println(String.valueOf(str));

		for (int i = index; i < str.length; i++) {
			swap(str, index, i);
			permutations(str, index + 1);
			swap(str, index, i);
		}
	}

	// generate all permutations of a String in Java
	public static void main(String[] args) 	{
		
		String s = "ABCDE";
		permutations(s.toCharArray(), 0);
	}

}
