package Search;

import java.io.*;
import java.util.*;

public class UVa_628_Passwords {

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva0628.in.txt" ));
				System.setOut(new     PrintStream("data/uva0628.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		Scanner sc = new Scanner(System.in);

		while (sc.hasNextLine()) {  

			System.out.println("--");
			int sizeDictionary = sc.nextInt();
			sc.nextLine();

			String[] dictionary = new String[sizeDictionary];
			for(int i=0; i<sizeDictionary; i++)
				dictionary[i] = sc.nextLine();

			int sizeRules = sc.nextInt();
			sc.nextLine();

			String[] rules = new String[sizeRules];
			for(int i=0; i<sizeRules; i++)
				rules[i] = sc.nextLine();

			// backtrack 
			for(int j=0; j<sizeRules; j++)
				solve(dictionary, "", rules[j], 0, new StringBuilder());
		}

		sc.close();
	}

	/**
	 * Backtrack solutions 
	 * @param words the dictionary (does not change)
	 * @param word the current word (always use the same word in a password)
	 * @param rule the rule we are applying (does not change) 
	 * @param idxRule the current rule instruction, # or 0
	 * @param password the solution so far
	 */
	private static void solve(String[] words, String word, String rule, 
			                  int idxRule, StringBuilder password) {

		if (idxRule == rule.length()) {
			System.out.println(password);
			return;
		}

		char c = rule.charAt(idxRule); // get next rule instruction
		
		if (c=='#') {
			if (word=="") // there's no fixed word yet
				for(String s : words) {
					int size = password.length();
					password.append(s);
					solve(words, s, rule, idxRule+1, password);
					password.setLength(size);
				}
			else
				solve(words, word, rule, idxRule+1, password.append(word));
		} else if (c=='0')
			for(int digit=0; digit<=9; digit++) {
				int size = password.length();
				password.append(digit);
				solve(words, word, rule, idxRule+1, password);
				password.setLength(size);
			}
	}
}
