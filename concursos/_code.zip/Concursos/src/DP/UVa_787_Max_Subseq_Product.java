package DP;

import java.io.*;
import java.math.BigInteger;
import java.util.*;

public class UVa_787_Max_Subseq_Product {
	
	private static final BigInteger UNKNOWN = BigInteger.valueOf(Long.MIN_VALUE);
	
	private static BigInteger max = UNKNOWN;
	
	public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva787.in.txt" ));
                System.setOut(new PrintStream("data/uva787.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);
        
        List<BigInteger> numbers;
        
        while (sc.hasNextInt()) {
        	int n;
        	
        	numbers = new ArrayList<BigInteger>();
        	while ((n=sc.nextInt()) != -999999)   // read data
        		numbers.add(BigInteger.valueOf(n)); 
        	
        	// using memoization
        	// sols[starting with i-th number][length of sequence]
        	// given numbers = {10,11,12,13,14,15}
        	// eg: sols[2][3] = 12*13*14, since 12 is the number at index 2
        	// eg: sols[0][4] = 10*11*12*13
        	// eg: sols[5][1] = 15
        	// we will not use column 0

        	n= numbers.size();
        	
        	if(n==1) {
        		System.out.println(numbers.get(0));
        		continue;
        	}
        	
        	BigInteger[][] sols = new BigInteger[n][n+1];
        	// NB: init with very negative number 
        	// this is an improbable bug, but it can happen!
        	// a better solution would be to create a boolean[][] isComputed
        	for(int i=0; i<n; i++)
        		for(int j=0; j<n+1; j++)
        			sols[i][j] = UNKNOWN;
        	
        	max = UNKNOWN;
        	
        	// base of recursion, at column 1 we have just the number itself
        	for(int i=0; i<n; i++) {
        		sols[i][1] = numbers.get(i);
        		max = max.max(sols[i][1]);
        	}
        	
        	System.out.println(solve(numbers, sols));
        	//printMatrix(sols);

        } // while(true)
        
        sc.close();
    }

	private static BigInteger solve(List<BigInteger> numbers, BigInteger[][] sols) {
		
		int n = numbers.size();
		
		for(int numberIdx=0; numberIdx<n; numberIdx++)
			for(int seqLength=2; seqLength<n+1; seqLength++)
				if (numberIdx+seqLength<=n)
					max = max.max(compute(numbers, sols, numberIdx, seqLength));
		
		return max;
	}

	private static BigInteger compute(List<BigInteger> numbers, 
			                          BigInteger[][] sols, 
			                          int numberIdx, int seqLength) {
		
		if (sols[numberIdx][seqLength].equals(UNKNOWN))
			sols[numberIdx][seqLength] =
			  sols[numberIdx][seqLength-1]
					  .multiply(numbers.get(numberIdx+seqLength-1));
			
		return sols[numberIdx][seqLength];
	}
	
	//////////////////////////
	
	private static void printMatrix(BigInteger[][] matrix) {
	    for (int row = 0; row < matrix.length; row++) {
	        for (int col = 0; col < matrix[row].length; col++) {
	        	if (matrix[row][col].equals(UNKNOWN))
	        		System.out.printf("  ##");
	        	else
	        		System.out.printf("%4d", matrix[row][col]);
	        }
	        System.out.println();
	    }
	}
	
}
