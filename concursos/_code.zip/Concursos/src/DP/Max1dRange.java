package DP;

import java.io.*;
import java.util.*;

public class Max1dRange {
	
	static int[] numbers;

   // From Halim - Competitive Programming 3 (2015), pag. 104
	private static int running_sum(int total) {
	    int running_sum = 0, ans = 0;
	    
	    for (int i = 0; i < total; i++)           // O(n)
	      if (running_sum + numbers[i] >= 0) {  
	        running_sum += numbers[i];
	        ans = Math.max(ans, running_sum);     // keep the largest RSQ overall
	      }
	      else        // the overall running sum is -ve, we greedily restart here
	        running_sum = 0;      // because starting from 0 is better for future
	                              // iterations than starting from a neg.running sum
	    return running_sum;
	}
	
	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {
				System.setIn (new FileInputStream("data/max1drange.in.txt" ));
				System.setOut(new     PrintStream("data/max1drange.out.txt") );
			} catch (Exception e) {}		

		////////////////////////

		Scanner sc = new Scanner(System.in);
		int total     = sc.nextInt();
		numbers = new int[total];  
		for (int i=0; i<total; i++)
			numbers[i] = sc.nextInt();
		sc.close();

		int result = running_sum(total);

		System.out.printf("%d\n", result);
	}
}
