package DP;

import java.io.*;
import java.util.*;

public class Troco {

	static final int UNKNOWN = -1;
	static int[] sols, coins;
	
	///////////////////////////////////////////////////////////
    // BOTTOM-UP solution (Starts at zero and goes to goal)
	///////////////////////////////////////////////////////////

	static int changesBU(int total) {
		checkChanges(0, total);
		return sols[total]; 
	}

	static void checkChanges(int current, int total) {

		if (current==0)
			sols[current] = 0;
		else {
			for (int i=0; i<coins.length; i++)  // check if it's exactly one coin
				if (current == coins[i])
					sols[current] = 1;

			if (sols[current] != 1) {
				int result = Integer.MAX_VALUE;
				
				for (int i=0; i<coins.length; i++) 
					if (current - coins[i] >= 0)
						result = Math.min(result, sols[current-coins[i]]);
				
				sols[current] = 1 + result;
			}
		}
			
		if (current < total)
			checkChanges(current+1, total);
	}

	///////////////////////////////////////////////////////////
    // TOP-DOWN solution (Starts at goal and computes downwards)
	///////////////////////////////////////////////////////////

	static int changesTD(int current) {
	    
		if (sols[current] != UNKNOWN)
			return sols[current];
		
		int result = Integer.MAX_VALUE;
		
		for(int i=0; i<coins.length; i++)
			if (current-coins[i]>=0)
				result = Math.min(result, changesTD(current-coins[i]));
		
		return sols[current] = 1 + result;
	}

	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {
				System.setIn (new FileInputStream("data/troco.in.txt" ));
				System.setOut(new     PrintStream("data/troco.out.txt") );
			} catch (Exception e) {}		
		////////////////////////
		// Read data

		Scanner sc = new Scanner(System.in);

		int total = sc.nextInt();
		sols = new int[total+1];
		for(int i=1; i<sols.length; i++)  // sols[0]=0
			sols[i] = UNKNOWN;

		int sizeCoins = sc.nextInt();
		coins = new int[sizeCoins];
		for (int i=0; i<sizeCoins; i++)
			coins[i] = sc.nextInt();

		sc.close();

		// Compute solution (pick one version)

		//int result = changesBU(total);
		int result = changesTD(total);

		// Write result

		System.out.printf("%d\n", result);

	}
}
