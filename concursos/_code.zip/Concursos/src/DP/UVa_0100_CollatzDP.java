package DP;

import java.io.*;
import java.util.*;

// The 3n+1 Problem
//problem: https://uva.onlinejudge.org/external/1/100.pdf
//info:    http://www.algorithmist.com/index.php/UVa_100s

/**
 * This is a solution for small sizes (up to 10000).
 * It uses a real DP solution with a 2D matrix, where
 *   sols[j][i] = Math.max(sols[j-1][i], sols[j][i+1])
 * However since this is O(n^2) in space, it will run out
 * of it pretty quickly as SIZE increases...
 * It includes a recursive and an iterative solution
 * @author jpn
 *
 */

public class UVa_0100_CollatzDP {
	
	static int cycleLength(int n) {
		int result = 1;
		while (n!=1) {
			n = n%2==0 ? n/2 : 3*n+1;
			result++;
		}
		return result;
	}
	
	//////////////
	
	static final int SIZE = 10000,
			         UNKNOWN = 0;
	
	static int[][] computeMatrix() {
		
		int[][] sols = new int[SIZE+1][];
		
		// make a triangular matrix, since maxCycle[i][j] is valid only for i<=j
		// notice that rows and cols were flipped, since we made a lower triangular matrix
		for(int i=1; i<=SIZE; i++)
			sols[i] = new int[i+1];  // init to zero, ie, UNKNOWN

		// compute max cycle lengths
		//computeMaxCycles(SIZE, 1, sols); // recursive version
		computeMaxCyclesIter(sols);        // iterative version
		
		return sols;
	}

	// nice recursive function: however it gives StackOverflow for SIZE==10000
	static void computeMaxCycles(int j, int i, int[][] sols) {

		if (i==j && sols[j][i] == UNKNOWN)

			sols[j][i] = cycleLength(i);
		
		else {
			if (sols[j-1][i] == UNKNOWN)
				computeMaxCycles(j-1,i,sols);
			
			if (sols[j][i+1] == UNKNOWN)
				computeMaxCycles(j,i+1,sols);
			
			sols[j][i] = Math.max(sols[j-1][i], sols[j][i+1]);
		}
	}

	static void computeMaxCyclesIter(int[][] sols) {

		// compute cycle length from naturals 1 to SIZE
		for(int i=1; i<=SIZE; i++)
			sols[i][i] = cycleLength(i);

		// compute remaining solutions
		for(int j=2; j<=SIZE; j++)   // for each row, starting 2nd:
			for (int i=j-1; i>0; i--)
				sols[j][i] = Math.max(sols[j-1][i], sols[j][i+1]); 
	}
	
	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (1>0)    // if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("bin/uva0100.in.txt" ));
				System.setOut(new     PrintStream("bin/uav0100.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		
		// Read data

		Scanner sc = new Scanner(System.in);

		List<Integer> is = new ArrayList<Integer>();
		List<Integer> js = new ArrayList<Integer>();

		while (sc.hasNextInt()) {
		    is.add(sc.nextInt());
		    js.add(sc.nextInt());
		}
		
		sc.close();

		// Compute solution

		int[][] cycles = computeMatrix();
		
		// Write result

		Iterator<Integer> is_it = is.iterator(),
		                  js_it = js.iterator();
		
		while(is_it.hasNext()) {
			int i = is_it.next(),
			    j = js_it.next();
			
			System.out.println(i + " " + j + " " + cycles[Math.max(i,j)][Math.min(i,j)]);			
		}
	}

}
