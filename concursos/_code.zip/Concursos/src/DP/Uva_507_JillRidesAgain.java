package DP;

import java.io.*;
import java.util.*;

// UVa 507 Jill Rides Again 
// Problem: https://uva.onlinejudge.org/external/5/507.pdf

public class Uva_507_JillRidesAgain {
	
	static int[] stops;
	static int i, j;
	
    // based on Halim - Competitive Programming 3 (2015), pag. 104
	static int running_sum() {
	    int running_sum = 0, answer = 0, i_temp = 0;
	    
	    i = j = i_temp = 1;                    // stop 1 is before the first number
	    for (int k=2; k<stops.length+2; k++) { // stop 2 is after  the first number
	      if (running_sum + stops[k-2] >= 0) {  
	        running_sum += stops[k-2];
	        if (running_sum > answer || (running_sum == answer && (j-i)<(k-i_temp))) {
	        	answer = running_sum;  // keep the largest RSQ overall
	        	i = i_temp;
	        	j = k;
	        }
	      }
	      else {      // the overall running sum is -ve, we greedily restart here
	        running_sum = 0;      // because starting from 0 is better for future
            i_temp = k;           // iterations than starting from a neg.running sum
	      }
	    }
	    return answer;
	}

	public static void main(String[] args) {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {
				System.setIn (new FileInputStream("data/uva507.in.txt" ));
				System.setOut(new     PrintStream("data/uva507.out.txt") );
			} catch (Exception e) {}		
		   
	    ////////////////////////
	    
	    Scanner sc = new Scanner(System.in);
	    
    	int nRoutes = sc.nextInt();
    	
    	for(int k=0; k<nRoutes; k++) {
    		
    		int nStops = sc.nextInt();  
    		stops = new int[nStops-1];
	    	for(int j=0; j<nStops-1; j++)
	    		stops[j] = sc.nextInt();

            if (running_sum()>0)
            	System.out.printf("The nicest part of route %d is between stops %d and %d\n", k+1, i, j);
            else
            	System.out.printf("Route %d has no nice parts\n", k+1);
    	}
	    sc.close();
	}
}
