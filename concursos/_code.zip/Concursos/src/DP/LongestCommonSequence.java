package DP;

import java.io.*;
import java.util.*;

public class LongestCommonSequence {

	final static int UNKNOWN = -1; 

	static int[][] lcsMatrix(String a, String b) {

		int[][] sols = new int[a.length()+1][b.length()+1];

		for(int i=0; i<=a.length(); i++)
			for(int j=0; j<=b.length(); j++)
				sols[i][j] = UNKNOWN;

		lcsAux(sols, a, b, a.length(), b.length());

		return sols;
	}

	static int lcsAux(int[][] sols, String a, String b, int n, int m) {

		if (sols[n][m] == UNKNOWN) {

			if (n==0 || m==0)           // base da recurs�o
				sols[n][m] = 0;

			else if (a.charAt(n-1)==b.charAt(m-1))
				sols[n][m] = 1 + lcsAux(sols,a,b,n-1,m-1);

			else {
				int n1 = lcsAux(sols,a,b,n,m-1),
					m1 = lcsAux(sols,a,b,n-1,m);
				sols[n][m] = n1>m1 ? n1 : m1;
			}
		}

		return sols[n][m];
	}

	static String getLcs(String a, String b) {
		return getLcsAux(a, lcsMatrix(a,b), a.length(), b.length());
	}

	static String getLcsAux(String a, int[][] s, int i, int j) {
		if (i==0 || j==0)
			return "";

		if ((s[i][j] == s[i-1][j-1] + 1) &&
				(s[i][j] >  s[i-1][j]) && 
				(s[i][j] >  s[i][j-1]))
			return getLcsAux(a,s,i-1,j-1)+a.charAt(i-1);
		else
			if (s[i-1][j] >= s[i][j-1])
				return getLcsAux(a,s,i-1,j);
			else
				return getLcsAux(a,s,i,j-1);
	}

	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {
				System.setIn (new FileInputStream("data/lcs.in.txt" ));
				System.setOut(new     PrintStream("data/lcs.out.txt") );
			} catch (Exception e) {}		

		////////////////////////

		Scanner sc = new Scanner(System.in);
		String string1 = sc.nextLine();
		String string2 = sc.nextLine();
		sc.close();

		System.out.printf("%s\n", getLcs(string1, string2));
	}
}