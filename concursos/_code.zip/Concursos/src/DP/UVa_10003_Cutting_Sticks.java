package DP;

import java.io.*;
import java.util.*;

//UVa 10003 Cutting Sticks
//problem: https://uva.onlinejudge.org/external/100/10003.pdf

public class UVa_10003_Cutting_Sticks {

	static final int UNKNOWN = 0; 

	static void computeSols(int left, int right, int[] cuts, int[][] costs) {

		if (costs[left][right] != UNKNOWN)  // already computed!
			return;
		
		if (left+1 == right) {       
			costs[left][right] = 0; 
			return;
		}
		
		int result = Integer.MAX_VALUE;
		for (int i=left+1; i<right; i++) {
			computeSols(left,  i, cuts, costs);
			computeSols(i, right, cuts, costs);
			result = Math.min(result, 
					          costs[left][i] + costs[i][right] + cuts[right] - cuts[left]);
		}
		costs[left][right] = result;
	}

	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva10003.in.txt" ));
				System.setOut(new     PrintStream("data/uva10003.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		// Read data

		Scanner sc = new Scanner(System.in);
		
		while (true) {
		    int L = sc.nextInt();       // stick size: 1 <= L < 1000
		    	
		    if (L==0) 
		    	break;
		    
		    int N = sc.nextInt();       // 1 <= N <= 50
		    
		    int[] cuts = new int[N+2];  // define cutting places array
		    for(int i=1; i<N+1; i++)    // read cutting points
		    	cuts[i] = sc.nextInt();
		    cuts[0] = 0;                // add extremities to compute costs[0][N+1]
		    cuts[N+1] = L;

		    int[][] costs = new int[N+2][N+2];
		    computeSols(0, N+1, cuts, costs);
		    //printMatrix(costs, "Costs");
			System.out.println("The minimum cutting is " + costs[0][N+1] + ".");			
		}
		
		sc.close();
	}
	
	//////////////////////////
	
	private static void printMatrix(int[][] matrix, String label) {
		
		System.out.println("------- " + label + " ---------");
	    for (int row = 0; row < matrix.length; row++) {
	        for (int col = 0; col < matrix[row].length; col++) {
        		System.out.printf("%4d", matrix[row][col]);
	        }
	        System.out.println();
	    }
        System.out.println("--------------------------");
	}

}
