package DP;

import java.io.*;
import java.util.*;

/**
 * Problema: https://uva.onlinejudge.org/external/6/674.pdf
 * @author tl
 */
public class UVA_674_Coins {

    static final int[] coins = {50, 25, 10, 5, 1};

	static final int UNKNOWN = 0; 
    static int[][] solutions = new int[coins.length][7490];

    static int solve(int coinIndice, int value) {
    	
        if (value < 0 || coinIndice >= coins.length)
            return 0;
        
    	if (solutions[coinIndice][value] != UNKNOWN) 
            return solutions[coinIndice][value];
    		
        if (value == 0)
            return 1;
        
        solutions[coinIndice][value] = solve(coinIndice,     value - coins[coinIndice])
                                     + solve(coinIndice + 1, value                    );
                                     
        return solutions[coinIndice][value];
    }

    public static void main(String[] args) throws FileNotFoundException {

		if (!new Object(){}.getClass().getName().contains("Main"))
			// if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva674.in.txt" ));
				System.setOut(new     PrintStream("data/uva674.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////
		
		Scanner sc = new Scanner(System.in);
		
        while (sc.hasNextInt())
            System.out.println(solve(0, sc.nextInt()));

        sc.close();
    }
}
