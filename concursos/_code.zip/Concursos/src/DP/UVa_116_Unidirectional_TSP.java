package DP;

import java.io.*;
import java.util.*;

public class UVa_116_Unidirectional_TSP {
	
	public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva116.in.txt" ));
                System.setOut(new PrintStream("data/uva116.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);
        
        while (sc.hasNextInt()) {
        	
        	int nrows = sc.nextInt();
        	int ncols = sc.nextInt();
        	
        	int[][] table = new int[nrows][ncols];
        	
        	for(int i=0; i<nrows; i++)
        		for(int j=0; j<ncols; j++)
        			table[i][j] = sc.nextInt();
        	
        	solve(table, false);

        } // while(true)
        
        sc.close();
    }

	private static void solve(int[][] table, boolean verbose) {
		
		if(verbose)
			printMatrix(table, "Data");
		
		int nrows = table   .length;
    	int ncols = table[0].length;
    	
		int[][] cost = new int[nrows][ncols];
		int[][] next = new int[nrows][ncols];
		
		// to take into account the lexicographic order, this table
		// is populated backwards
		for(int i=0;i<nrows;i++) 
			cost[i][ncols-1] = table[i][ncols-1];
		
		if(verbose)
			printMatrix(cost, "Costs");
		
		for(int j=ncols-2; j>=0; j--) {
			for(int i=0; i<nrows; i++) {
				int currentMin = Integer.MAX_VALUE;
				
				for(int k=-1;k<=1;k++) { // for all three move options
                    int row = (i+k+nrows) % nrows; // +nrows to prevent negatives
                    
                    if (cost[row][j+1] < currentMin 
                    		|| 
                       (cost[row][j+1] == currentMin && row < next[i][j])) {
                        currentMin = cost[row][j+1];
                        next[i][j] = row;
                    }
                }
				
				cost[i][j] = table[i][j] + currentMin;
				
			}
			if(verbose)
				printMatrix(cost, "Costs");
			if(verbose)
				printMatrix(next, "Path");
		}
		
		if(verbose)
			printMatrix(next, "Path");
		
		// print output
		    
		int minCost = Integer.MAX_VALUE;
        int pathIndex = 0;
        StringBuilder path = new StringBuilder();
        
        // in the first column, find the minimal cost
        for(int i=0; i<nrows; i++)
            if(cost[i][0] < minCost) {
                minCost = cost[i][0];
                pathIndex = i;
            }
        path.append(pathIndex+1);
        
        //System.out.printf("%d", pathIndex+1);
        
        for(int i=0;i<ncols-1;i++){
            pathIndex = next[pathIndex][i];
            path.append(" ").append(pathIndex+1);
        }        
        System.out.println(path);
        
        System.out.println(minCost); 
	}
	
	
	//////////////////////////
	
	private static void printMatrix(int[][] matrix, String label) {
		
		System.out.println("------- " + label + " ---------");
	    for (int row = 0; row < matrix.length; row++) {
	        for (int col = 0; col < matrix[row].length; col++) {
        		System.out.printf("%4d", matrix[row][col]);
	        }
	        System.out.println();
	    }
        System.out.println("--------------------------");
	}
}
