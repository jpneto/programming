package DP;

import java.io.*;
import java.util.*;

/**
 * 
 * @author Nuno Burnay fc46406@alunos.fc.ul.pt
 * 
 * Em relação ao problema a ideia inicial parece-me correta: para cada intervalo (a, b), 
 * experimentar colocar todos os pavilhões i no centro, calculando obrigatoriamente dp(a, i - 1) 
 * e dp(i + 1, b).
 * 
 * A solução da árvore é possível mas resultaria num aumento da complexidade do problema. 
 * Uma solução interessante é pré calcular a soma de todos os pavilhões e assim consegue-se 
 * obter a soma de um intervalo consecutivo de pavilhões em tempo constante. Para cada 
 * iteração de dp(a, b), soma-se sumP(a, b), a soma dos pavilhões no intervalo (a, b). 
 * Para cada i considerado, deve-se retirar sempre esse pavilhão, pois é o pavilhão central.
 * 
 * O algoritmo em geral é O(n^3).
 * 
 * Em anexo está a minha solução aqui descrita, em java. Passou no small input mas 
 * (como esperado) não passou no big input por TLE. Para tal o algoritmo tinha de ser 
 * (penso eu) no máximo O(n^2 . log n).
 *
 */
public class UAC_CP_2016_Universal_Expo {

	static int[][] dp;
	static int[]   p, sumP;

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uac2016_1.in.txt" ));
				System.setOut(new     PrintStream("data/uac2016_1.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		// Read data

		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		
		dp   = new int[n][n];
		p    = new int[n];
		sumP = new int[n];

		for (int i = 0; i < n; i++)
			p[i] = sc.nextInt();
		
		sumP[0] = p[0];
		for (int i = 1; i < n; i++)
			sumP[i] = sumP[i - 1] + p[i];
		
		System.out.println(dp(0, n - 1));
		sc.close();
	}

	static int dp(int l, int u) {
		if (l >= u)
			return 0;
		
		if (dp[l][u] != 0)
			return dp[l][u];
		
		int min = Integer.MAX_VALUE;
		for (int i = l; i <= u; i++)
			min = Math.min(min, dp(l, i - 1) + dp(i + 1, u) - p[i]);
		
		return dp[l][u] = min + sumP(l, u);
	}

	static int sumP(int l, int u) {
		return sumP[u] - (l == 0 ? 0 : sumP[l - 1]);
	}
}
