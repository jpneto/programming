package DP;

import java.io.*;
import java.util.*;

// UVa 10943 How do you Add?
// problem: https://uva.onlinejudge.org/external/109/10943.pdf

public class UVa_10943_How_to_Add {
	
	static final int UNKNOWN = 0; 
	static long[][] sols = new long[101][101]; // we'll not use indexes 0

	static void computeAdds(int N, int K) {
	
		if (sols[N][K] != UNKNOWN)
			return;
		
		if (K==1)
			sols[N][K] = 1;  // using 1 number, the only solution is N itself
		else {
			
			long sum=0;
			for(int i=0;i<=N;i++) {
				computeAdds(N-i, K-1);
				sum += sols[N-i][K-1];
				sum %= 1000000;  // keep it small
			}
			sols[N][K] = sum;				
		}
	}	
	
	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva10943.in.txt" ));
				System.setOut(new     PrintStream("data/uva10943.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		// Read data

		Scanner sc = new Scanner(System.in);
		
		while (true) {
		    int N = sc.nextInt(),  // 1 <= N <= 100
		        K = sc.nextInt();  // 1 <= K <= 100
		    
		    if (N==0 && K==0)
		    	break;
		    
		    computeAdds(N,K);
			System.out.println(sols[N][K]);			
		}
		
		sc.close();
	}
}
