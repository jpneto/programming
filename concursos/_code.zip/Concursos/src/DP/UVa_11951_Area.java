package DP;

import java.io.*;
import java.util.*;

//TODO: NOT WORKING

public class UVa_11951_Area {
	public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva11951.in.txt" ));
                System.setOut(new PrintStream("data/uva11951.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);
        
        int nTests = sc.nextInt();
        
        for(int nCase=1; nCase<=nTests; nCase++) {
        	
        	int rows = sc.nextInt(); 
        	int cols = sc.nextInt();
        	int budget = sc.nextInt();
        	
        	int[][] strips = new int[rows][cols];
        	
        	for(int i=0; i<rows; i++)
        		for(int j=0; j<cols; j++)
        			strips[i][j] = sc.nextInt();
        	
        	solve(nCase, strips, budget);

        } // while(true)
        
        sc.close();
    }

	private static void solve(int nCase, int[][] strips, int budget) {
		int maximalArea = 0;
		int totalCost = 0;
		
		int rows = strips.length;
		int cols = strips[0].length;
		
		int[][] plotRows = new int[rows][cols];
		int[][] plotCols = new int[rows][cols];
		int[][] costs    = new int[rows][cols];
		
		// trivial case: at the corner left 
		plotRows[0][0] = strips[0][0] <= budget ? 1 : 0;
		plotCols[0][0] = strips[0][0] <= budget ? 1 : 0;
		costs[0][0] = strips[0][0];
		
		// build first row and columns
		for(int j=1; j<cols; j++) {
			plotRows[0][j] = 1; // no rows above
			costs[0][j] = strips[0][j];
			if (strips[0][j] <= budget) {
				plotCols[0][j] = 1;   
				if (strips[0][j] + costs[0][j-1] <= budget) {
					// we can add to the previous plot
					plotCols[0][j] += plotCols[0][j-1];   
					costs[0][j] += costs[0][j-1];
				}
			}
		}
		
		for(int i=1; i<rows; i++) {
			plotCols[i][0] = 1; // no cols to the left
			costs[i][0] = strips[i][0];
			if (strips[i][0] <= budget) {
				plotRows[i][0] = 1;   
				if (strips[i][0] + costs[i-1][0] <= budget) {
					// we can add to the previous plot
					plotRows[i][0] += plotRows[i-1][0];   
					costs[i][0] += costs[i-1][0];
				}
			}
		}

		printMatrix(plotRows);
		printMatrix(plotCols);
		printMatrix(costs);
		
		for(int i=1; i<rows; i++) {
    		for(int j=1; j<cols; j++) {
    			if (strips[i][j] > budget)
    				continue;
    			
    			// for cell (i,j) there are two options (if there's budget):
    			// a) sum the plot area of its upper cell C, 
    			//    plus a 1x(n-1) strip from the left, or
    			// b) sum the plot area of its left cell D, 
    			//    plus a 1x(n-1) strip from the top
    			
				//    		    +---------------+      +-----------+ +--+
				//    		    |               |      |           | |  |
				//    		    |               |      |           | |  |
				//    		    |               |      |           | |  |
				//    		    |               |      |           | |  |
				//    		    |               |      |           | |  |
				//    		a)  |               |  b)  |           | |  |
				//    		    |             C |      |           | |  |
				//    		    +---------------+      |           | +--+
				//    		    +----------+ +--+      |           | +--+
				//    		    |          | |  |      |         D | |  |
				//    		    +----------+ +--+      +-----------+ +--+
    			
    			int areaA = 0;
    			
    			int costOptionA = strips[i][j] + costs[i-1][j];
    			for(int k=1; k<plotCols[i-1][j]; k++) 
    				costOptionA += strips[i][j-k];
    			  		
    			if (costOptionA <= budget) {
    				// if within budget, always accept this option
    				costs[i][j] = costOptionA;
    				plotRows[i][j] = plotRows[i-1][j] + 1; 
    				plotCols[i][j] = plotRows[i-1][j];
    				areaA = plotRows[i][j] * plotCols[i][j];
    			}
    			
    			// now let's compute option B, and check if it's better
    			
    			int costOptionB = strips[i][j] + costs[i][j-1];
    			for(int k=1; k<plotRows[i][j-1]; k++) 
    				costOptionB += strips[i-k][j];
    			
    			if (costOptionB > budget) 
    				continue;
    			
    			int areaB = plotRows[i][j-1] * (plotCols[i][j-1]+1);
    			
    			System.out.printf("custo A:%d, custo B:%d, areaA: %d, areaB:%d\n",
    					costOptionA, costOptionB, areaA, areaB);
    			
    		    // if option B is better...
    			if (areaB >  areaA || 
    			   (areaB == areaA && costOptionB < costOptionA)) {
    				costs[i][j] = costOptionB;
    				plotRows[i][j] = plotRows[i-1][j]; 
    				plotCols[i][j] = plotRows[i-1][j]+1;
    			}
    	
    			if (maximalArea < plotRows[i][j] * plotCols[i][j] 
    					          ||
    			      (maximalArea == plotRows[i][j] * plotCols[i][j] 
    				          &&
    				   totalCost > costs[i][j])
    			    ) {
    				maximalArea = plotRows[i][j] * plotCols[i][j];
    				totalCost = costs[i][j];
    			}
    			
    			System.out.println(i+","+j);
    			printMatrix(plotRows);
    			printMatrix(plotCols);
    			printMatrix(costs);
    		}
		}
		
		System.out.printf("Case #%d: %d %d", nCase, maximalArea, totalCost);		
	}
	
	//////////////////////////
	
	private static void printMatrix(int[][] matrix) {
	    for (int row = 0; row < matrix.length; row++) {
	        for (int col = 0; col < matrix[row].length; col++) {
        		System.out.printf("%4d", matrix[row][col]);
	        }
	        System.out.println();
	    }
        System.out.println("--------------------------");
	}
}
