package DP;

import java.io.FileInputStream;
import java.util.Scanner;

public class Euler18_Maximum_Path_Sum_I {

    private static final int SIZE = 25;
    
	public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/euler0018.in.txt" ));
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        int[][] triangle = new int[SIZE][SIZE];
        
        /*
         *   Triangle     1      represented as   1 0 0
         *               2 3                      2 3 0
         *              4 5 6                     4 5 6
         */
        int numsLine = 0;
        while (sc.hasNextInt()) {
        	numsLine++;
        	for(int i=0; i<numsLine; i++)
        		triangle[numsLine-1][i] = sc.nextInt();
        } 

        //////////////
        
        long startTime, endTime;
        int sum=0;
        
		startTime = System.nanoTime();
		sum = solveBruteForce(triangle);
		endTime = System.nanoTime();
		System.out.printf("Brute Force: %d, time: %d ms\n", 
				          sum, (endTime-startTime)/1_000_000);

		startTime = System.nanoTime();
		sum = solveGreed(triangle);
		endTime = System.nanoTime();
		System.out.printf("Greed: %d, time: %d ms\n", 
				          sum, (endTime-startTime)/1_000_000);

		
		startTime = System.nanoTime();
		// side-effect: changes triangle[][]
		sum = solveDPTopDown(triangle);
		endTime = System.nanoTime();
		System.out.printf("DP: %d, time: %d ms\n", 
				          sum, (endTime-startTime)/1_000_000);
        
        sc.close();
    }

	private static int solveGreed(int[][] triangle) {
		int sum=triangle[0][0];
		
		for(int i=1, currentCol=0; i<SIZE; i++) {   // for each row
			if (triangle[i][currentCol] < triangle[i][currentCol+1])
				currentCol++;
			sum += triangle[i][currentCol];
		}
		return sum;
	}

	private static int solveDPTopDown(int[][] triangle) {
		
		for(int i=1; i<SIZE; i++) {   // for each row
			// treat extremities (just one possible sum)
			triangle[i][0] += triangle[i-1][0];
			triangle[i][i] += triangle[i-1][i-1];
			
			for(int j=1; j<i; j++) 
				triangle[i][j] += Math.max(triangle[i-1][j-1], triangle[i-1][j]);
		}
		// browse last line and return the largest sum
		int maxSum=0;
		
		for(int i=0; i<SIZE; i++)
			if (triangle[SIZE-1][i] > maxSum)
				maxSum = triangle[SIZE-1][i];
		return maxSum;
	}

	// ref: https://www.mathblog.dk/project-euler-18/
	// test all paths
	private static int solveBruteForce(int[][] triangle) {
		int maxSum =0;
		int nPaths = 2 << (SIZE-1); // with size 2 has 2 paths, size 3 has 4 paths...
		
		// progress variable i bits code the path, 0 for left, 1 for right  
		// going to the left is staying at the same column
		// going to the right is advancing one column
		for(int i=0; i<nPaths; i++) {
			int sum = triangle[0][0];
		    for (int j=0, index=0; j<SIZE-1; j++) {
		    	index += i >> j & 1;
		        sum   += triangle[j+1][index];
		    }
		    if (sum>maxSum)
		    	maxSum = sum;
		}
		return maxSum;
	}
}
