package DP;

import java.util.*;
import java.io.*;

// UVa 1172 - The Bridges of Kolsberg (Longest Common Subsequence)
// Problem: https://uva.onlinejudge.org/external/11/1172.pdf

public class UVa_1172_Bridges_Kolsberg {

  private static final int UNKNOWN = -1;     // using memoization

  private static Pair lcsMatrix2(City[] a, City[] b) {
    Pair[][] sols = new Pair[a.length + 1][b.length + 1];

    for (int i = 0; i <= a.length; i++) {
      for (int j = 0; j <= b.length; j++) {
        sols[i][j] = new Pair(UNKNOWN, 0);
      }
    }

    lcsMatrix2Aux(sols, a, b, a.length, b.length);

    return sols[a.length][b.length];
  }

  private static Pair lcsMatrix2Aux(Pair[][] sols, City[] a, City[] b, int n,
                                    int m) {

    if (sols[n][m].p1 != UNKNOWN) {
      return sols[n][m];
    }

    if (n == 0 || m == 0) {
      sols[n][m].p1 = 0;
      sols[n][m].p2 = 0;
      return sols[n][m];
    }

    if (a[n - 1].type.equals(b[m - 1].type)) {
      Pair remaining = lcsMatrix2Aux(sols, a, b, n - 1, m - 1);
      sols[n][m].p1 = a[n - 1].value + b[m - 1].value + remaining.p1;
      sols[n][m].p2 = remaining.p2 + 1;
    }

    Pair s1 = lcsMatrix2Aux(sols, a, b, n, m - 1),
         s2 = lcsMatrix2Aux(sols, a, b, n - 1, m);

    // must still test the other possibilities (this is != from the lcs)
    if (s1.p1 > sols[n][m].p1 ||
        s2.p1 > sols[n][m].p1 ||
        (s1.p1 == sols[n][m].p1 && s1.p2 < sols[n][m].p2) ||
        (s2.p1 == sols[n][m].p1 && s2.p2 < sols[n][m].p2) ) {
      // only update in case of better solution found...
      if (s1.p1 == s2.p1) {  //if same value, then choose less bridges
        sols[n][m].p1 = s1.p1;
        sols[n][m].p2 = s1.p2 < s2.p2 ? s1.p2 : s2.p2;
      }
      else {
        sols[n][m].p1 = s1.p1 > s2.p1 ? s1.p1 : s2.p1;
        sols[n][m].p2 = s1.p1 > s2.p1 ? s1.p2 : s2.p2;
      }
    }

    return sols[n][m];
  }

  public static void main(String[] args) throws IOException {

	if (!new Object(){}.getClass().getName().contains("Main"))    
		try {   // redirect System.in and System.out to in/out text files
			System.setIn (new FileInputStream("data/uva1172.in.txt" ));
			System.setOut(new     PrintStream("data/uva1172.out.txt") );
		} catch (Exception e) {}		
	///////////////////////////////////////////////////////////////
	
    Scanner sc = new Scanner(System.in);

    int nCases = sc.nextInt();
    
    while (nCases-- > 0) {

    	int leftCities = sc.nextInt();
        City[] left = new City[leftCities];

        for (int i = 0; i < leftCities; i++) {
          sc.next(); // the name is irrelevant...
          left[i] = new City(sc.next(), sc.nextInt());
        }
    	
    	int rightCities = sc.nextInt();
        City[] right = new City[rightCities];

        for (int i = 0; i < rightCities; i++) {
          sc.next(); // the name is irrelevant...
          right[i] = new City(sc.next(), sc.nextInt());
        }

        System.out.println(lcsMatrix2(left, right).p1 + " " +
                           lcsMatrix2(left, right).p2);
    }

    sc.close();
  }
}

class City {
	  public String type;
	  public int value;
	  public City(String t, int v) {
	    type = t;
	    value = v;
	  }
}

class Pair {
	  public int p1, p2;
	  public Pair(int p1, int p2) {
	    this.p1 = p1;  // trade value
	    this.p2 = p2;  // number of bridges
	  }
}

