package DP;

import java.io.*;
import java.util.*;

public class Knapsack {
	
	static final int UNKNOWN = -1;
	static int[] values, weigths;
	static int[][] sols;
	static int nProducts;
	
	static int compute_sols(int i, int capacity) {
		
		if (i==nProducts || capacity==0)
			return 0;
		
		if (sols[i][capacity] != UNKNOWN)
			return sols[i][capacity];
		
		if (weigths[i] > capacity)
			return sols[i][capacity] = compute_sols(i+1, capacity);
		
		return sols[i][capacity] = 
			Math.max(          compute_sols(i+1, capacity), 
					 values[i]+compute_sols(i+1, capacity - weigths[i]));
	}

	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {
				System.setIn (new FileInputStream("data/knapsack.in.txt" ));
				System.setOut(new     PrintStream("data/knapsack.out.txt"));
			} catch (Exception e) {}		

		////////////////////////



		Scanner sc = new Scanner(System.in);

		int capacity  = sc.nextInt();
		nProducts     = sc.nextInt();
		
		values  = new int[nProducts];
		weigths = new int[nProducts];

		for (int i=0; i<nProducts; i++) {
			values[i]  = sc.nextInt();
			weigths[i] = sc.nextInt();
		}

		sc.close();
		
		sols = new int[nProducts][capacity+1];
		
		for(int i=0; i<nProducts; i++) 
			for(int j=0; j<=capacity; j++)
				sols[i][j] = UNKNOWN;
		
		System.out.printf("%d\n", compute_sols(0, capacity));

		// --- print table of solutions
		
		System.out.print("                ");
		for(int j=0; j<=capacity; j++)
			System.out.printf("%2d ", j);
		System.out.println();

		for(int i=0; i<nProducts; i++) {
			System.out.printf("(val:%2d, wgt:%2d)", values[i], weigths[i]);
			for(int j=0; j<=capacity; j++)
				System.out.printf("%2d ", sols[i][j]);
			System.out.println();
		}
	}
}