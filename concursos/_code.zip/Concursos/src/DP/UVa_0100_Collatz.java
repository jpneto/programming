package DP;

import java.io.*;
import java.util.*;

// The 3n+1 Problem
// problem: https://uva.onlinejudge.org/external/1/100.pdf
// info:    http://www.algorithmist.com/index.php/UVa_100

/**
 * Brute force algorithm with memoization to reduce computations
 * @author jpn
 *
 */

public class UVa_0100_Collatz {
	
	static final int SIZE = 1000000,
			         UNKNOWN = 0;
	
	static int[] sols;
	
	static int computeCycle(int k) {
		
		if (k <= SIZE && sols[k] != UNKNOWN)
			return sols[k];
		
		int result = 1 + (k%2==0 ? computeCycle(k/2) : computeCycle(3*k+1));
		
		if (k <= SIZE) // only keep values <= SIZE
			sols[k] = result;
			
		return result;
	}
	
	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (1>0)    // if true: read from files; else: read from System.in
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("bin/uva0100.in.txt" ));
				System.setOut(new     PrintStream("bin/uva0100.out.txt") );
			} catch (Exception e) {}		
		///////////////////////////////////////////////////////////////

		sols = new int[SIZE+1];
		sols[1] = 1;
		 
		Scanner sc = new Scanner(System.in);

		while (sc.hasNextInt()) {
		    int i = sc.nextInt(),
		        j = sc.nextInt();
		    
		    int from   = Math.min(i, j),
		        to     = Math.max(i, j),
		        result = 0;
		    
		    for(int k=from; k<=to; k++) 
		    	result = Math.max(result, computeCycle(k));
		    
			System.out.println(i + " " + j + " " + result);			
		}
		
		sc.close();
	}
}
