package DP;

import java.io.*;
import java.util.*;

public class UVa_10404_Bachet {
	
	static int[] sols, moves;
	
	// bottom-up interactive solution
	static int bachet(int N) {

        for(int i=1; i<=N; i++) {
        	sols[i] = 2;    // assume victory for 2nd player, unless:
        	for(int move=0; move<moves.length; move++)
        		if (i-moves[move] >= 0 && sols[i-moves[move]] == 2)
        			sols[i] = 1; 
        }
		return sols[N];
	}
	
	// top-down recursive solution (gives StackOverflow)
 	static final int UNKNOWN = 0;

	static int bachetTD(int N) {
	
	  if (sols[N] == UNKNOWN) {

		  sols[N] = 2;      // assume victory for 2nd player, unless:
		  for(int move=0; move<moves.length; move++)
		      if (N>=moves[move] && bachetTD(N-moves[move])==2)
			     sols[N] = 1; 
	  }
	  return sols[N];
	}
	

	public static void main(String[] args) {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {
				System.setIn (new FileInputStream("data/uva10404.in.txt" ));
				System.setOut(new     PrintStream("data/uva10404.out.txt") );
			} catch (Exception e) {}		
		   
	    ////////////////////////
	    
	    Scanner sc = new Scanner(System.in);
	    
	    while (sc.hasNextInt()) {
	    	
	    	// read Line
	    	int      N = sc.nextInt();
	    	int nMoves = sc.nextInt();
	    	
	    	moves = new int[nMoves];
	    	for(int i=0; i<nMoves; i++)
	    		moves[i] = sc.nextInt();
	    	
	  	    sols = new int[N+1];
            sols[0] = 2;
	    	
	    	System.out.printf("%s wins\n", bachet(N) == 1 ? "Stan" : "Ollie");
	    }
	    sc.close();
	}
}
