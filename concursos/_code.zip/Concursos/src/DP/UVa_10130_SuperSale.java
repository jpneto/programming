package DP;

import java.io.*;
import java.util.*;

//SuperSale
//problem:https://uva.onlinejudge.org/external/101/10130.pdf

public class UVa_10130_SuperSale {

	static final int UNKNOWN = -1;
	static int[] values, weigths;
	static int[][] sols;
	static int nProducts;
	
	static int compute_sols(int i, int capacity) {
		
		if (i==nProducts || capacity==0)
			return 0;
		
		if (sols[i][capacity] != UNKNOWN)
			return sols[i][capacity];
		
		if (weigths[i] > capacity)
			return sols[i][capacity] = compute_sols(i+1, capacity);
		
		return sols[i][capacity] = 
			Math.max(          compute_sols(i+1, capacity), 
					 values[i]+compute_sols(i+1, capacity - weigths[i]));
	}

	///////////////////////////////////////////////////////////

	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))    
			// if true: read from files; else: read from System.in
			try {
				System.setIn (new FileInputStream("data/uva10130.in.txt" ));
				System.setOut(new     PrintStream("data/uva10130.out.txt"));
			} catch (Exception e) {}		

		////////////////////////

		final int MAX_CAPACITY = 30;
		
		Scanner sc = new Scanner(System.in);

		int nTests = sc.nextInt();
		
		while(nTests-- > 0) {
			
			nProducts     = sc.nextInt();   // read Products
			values  = new int[nProducts];
			weigths = new int[nProducts];
			for (int i=0; i<nProducts; i++) {
				values[i]  = sc.nextInt();
				weigths[i] = sc.nextInt();
			}

			sols = new int[nProducts][MAX_CAPACITY+1];
			for(int i=0; i<nProducts; i++)  // reset for each set of persons 
				for(int j=0; j<=MAX_CAPACITY; j++)
					sols[i][j] = UNKNOWN;

			int nPersons = sc.nextInt(), 
				   total = 0;
			while (nPersons-- > 0) {
				int capacity  = sc.nextInt();
				total += compute_sols(0, capacity);
			}
			
			System.out.printf("%d\n", total);
		}

		sc.close();
	}
}
