package DP;

import java.io.*;
import java.util.*;

public class Bachet {
	
	static final int UNKNOWN = -1;
	static int[] moves, sols;
	
	static int checkSols(int N) {

	  if (sols[N] == UNKNOWN) {

		  sols[N] = 2;      // assume victory for 2nd player, unless:
		  for(int i=0; i<moves.length; i++)
		      if (N==moves[i] || (N>=moves[i] && checkSols(N-moves[i])==2))
			     sols[N] = 1; 
	  }
	  
	  return sols[N];
	}

	///////////////////////////////////////////////////////////

	public static void main(String[] args) {
		
		if (!new Object(){}.getClass().getName().contains("Main"))    
			try {
				System.setIn (new FileInputStream("data/bachet.in.txt" ));
				System.setOut(new     PrintStream("data/bachet.out.txt") );
			} catch (Exception e) {}		
		   
	    ////////////////////////
	    
	    Scanner sc = new Scanner(System.in);
	    
	    int stones    = sc.nextInt();
	    int sizeMoves = sc.nextInt();
	    
	    moves = new int[sizeMoves];
	    for (int i=0; i<sizeMoves; i++)
	    	moves[i] = sc.nextInt();
	    
	    sc.close();
	    
  	    sols = new int[stones+1];
	    for(int i=0; i<=stones; i++) 
	    	sols[i] = UNKNOWN;
		  
	    System.out.printf("%d\n", checkSols(stones));
	}
}