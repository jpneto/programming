package UnionFind;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.StringTokenizer;

public class UVa_10583_Ubiquitous_Religions {

	public static void main(String[] args) throws IOException {
		if (!new Object() {
		}.getClass().getName().contains("Main"))
			try { // redirect System.in and System.out to in/out text files
				System.setIn(new FileInputStream("data/uva10583.in.txt"));
				System.setOut(new PrintStream("data/uva10583.out.txt"));
			} catch (Exception e) {
			}
		///////////////////////////////////////////////////////////////

		Reader2.init(System.in);
		int iCase = 1;

		while (true) {
			int n = Reader2.nextInt();
			int m = Reader2.nextInt();
			
			if(n==0 && m==0)
				break;
			
			Union_Find uf = new Union_Find(n+1); // 0 is not used
			int result = n;
			
			for(int line=0; line<m; line++) {
				int i = Reader2.nextInt();
				int j = Reader2.nextInt();
				if (uf.findSet(i) != uf.findSet(j)) {
					uf.union(i, j);
					result--;
				}
			}

			System.out.println("Case " + iCase++ + ": " + result);
		}
	}
}

/////////////////////////////////////

class Reader2 {
	static BufferedReader reader;
	static StringTokenizer tokenizer;
	static String next;
	static boolean eof;

	/**
	 * call this method to initialize reader for InputStream
	 * 
	 * @throws IOException
	 */
	static void init(InputStream input) throws IOException {
		reader = new BufferedReader(new InputStreamReader(input));
		tokenizer = new StringTokenizer("");
		next = reader.readLine();
	}

	static boolean hasNext() {
		return tokenizer.hasMoreTokens() || next != null;
	}

	/**
	 * get next word
	 * 
	 * @throws IOException
	 */
	static String next() throws IOException {
		while (!tokenizer.hasMoreTokens()) {
			if (next == null)
				return null;
			tokenizer = new StringTokenizer(next);
			next = reader.readLine();
		}
		return tokenizer.nextToken();
	}

	static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
}
