package Math;

import java.io.*;
import java.util.*;

import static java.lang.Math.*;
/**
 * Created by jpn on 16-11-2018.
 */
public class UVa_294_Divisor {

    private static final int MAX = 1_000_000_000;

    private static int[] primes;

    // compute primes using Sieve of Eratosthenes
    private static void computePrimes() {

        int numPrimes = 0;
        byte[] naturals = new byte[(int)round(sqrt(MAX))+1]; // for MAX=1e9, it's ~32k

        for(int n=2; n*n<=MAX; n++)
            if (naturals[n]==0) {
                numPrimes++; // if still is zero, then n is a prime
                for (int i = 2*n; i < naturals.length; i += n)
                    naturals[i] = 1;  // all its multiples, however, are not
            }

        // if naturals[i]==0, i is a prime number
        primes = new int[numPrimes];
        for(int n=2, p=0; n<naturals.length; n++)
            if (naturals[n]==0)
                primes[p++] = n;
    }

    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object() {
        }.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn(new FileInputStream("data/uva294.in.txt"));
                System.setOut(new PrintStream("data/uva294.out.txt"));
            } catch (Exception e) {
            }
        ///////////////////////////////////////////////////////////////

        computePrimes();

        Scanner sc = new Scanner(System.in);

        int nCases = sc.nextInt();

        while (nCases-- > 0) {
            int L = sc.nextInt(); // lower bound
            int U = sc.nextInt(); // upper bound

            int numMaxDivs=0, maxDivs=0;

            for(int i=L; i<=U; i++) {
                // factor each number i
                int divs=1;
                int num = i;

                for(int p : primes) {  // divide by each prime
                    if (p>i) break; // a prime > i is not a factor of i
                    int div=1;
                    while (num % p == 0) {
                        num /= p;
                        div++;
                    }
                    divs *= div;
                }

                if(divs > maxDivs) {
                    numMaxDivs = i;
                    maxDivs    = divs;
                }

            }

            System.out.printf("Between %d and %d, %d has a maximum of %d divisors.%n",
                    L, U, numMaxDivs, maxDivs);
        }

        sc.close();
    }
}
