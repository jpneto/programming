package Math;

import java.io.*;
import java.util.*;

/**
 * Created by jpn on 16-11-2018.
 */
public class UVa_374_mod_calc {

    // using rule: x*y mod M == (x mod M * y mod M) mod M
    // ref: artofproblemsolving.com/wiki/index.php/Modular_arithmetic/Introduction
    private static int compute(int B, int P, int M) {

        if (P==0) return 1;
        if (P==1) return B%M;

        int halfPower     = compute(B, P/2, M);  // already in mod M
        int oneExtraPower = halfPower;

        if (P%2==1)
            oneExtraPower = (halfPower * (B%M)) % M;

        return (halfPower * oneExtraPower) % M;
    }

    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object(){}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva374.in.txt" ));
                System.setOut(new PrintStream("data/uva374.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        while (sc.hasNext())
            System.out.println(compute(sc.nextInt(), sc.nextInt(), sc.nextInt()));

        sc.close();
    }
}
