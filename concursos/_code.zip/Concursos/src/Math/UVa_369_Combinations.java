package Math;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Created by jpn on 16-11-2018.
 */
public class UVa_369_Combinations {

    private static final int MAX = 100;
    private static long[][] pascalTriangle;

    private static void computePascalTriangle() {
        pascalTriangle = new long[MAX+2][];

        for(int i=1; i<pascalTriangle.length; i++) {
            pascalTriangle[i] = new long[i];
            pascalTriangle[i][0] = pascalTriangle[i][i-1] = 1;
        }

        for(int i=3; i<pascalTriangle.length; i++)
            for(int j=1; j<i-1; j++)
                pascalTriangle[i][j] = pascalTriangle[i-1][j-1] + pascalTriangle[i-1][j];

        //for(int i=1; i<pascalTriangle.length; i++)
        //    System.out.println(i + ": " + Arrays.toString(pascalTriangle[i]));
    }

    public static void main(String[] args) throws FileNotFoundException {

        if (!new Object(){}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva369.in.txt" ));
                System.setOut(new PrintStream("data/uva369.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        computePascalTriangle();

        int N, M;
        Scanner sc = new Scanner(System.in);

        while (true) {
            N = sc.nextInt();
            M = sc.nextInt();
            if (N==0) break;

            System.out.printf("%d things taken %d at a time is %d exactly.%n",
                    N, M, pascalTriangle[N+1][M]);
        }

        sc.close();
    }
}
