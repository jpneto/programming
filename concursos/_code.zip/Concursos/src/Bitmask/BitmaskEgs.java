package Bitmask;

// ref: http://graphics.stanford.edu/~seander/bithacks.html
// ref: Halim's book, chapter 2

import java.util.stream.IntStream;

public class BitmaskEgs {

    public static void main(String[] args) {

        byte  b  = 36;  //  8 bits
        short s  = 36;  // 16 bits
        int   i  = 36;  // 32 bits
        long  lg = 36L; // 64 bits

        // Multiply by a power of 2
        System.out.printf("%d * 4 = %d\n", b, b<<2);

        // Divide by a power of 2
        System.out.printf("%d / 4 = %d\n", s, s>>2);

        // Multiply by 10: 10x = 8x + 2x
        System.out.printf("%d * 10 = %d\n", i, (i<<3) + (i<<1));

        // Multiply by 3.5: 3.5x = (8x-x)/2
        System.out.printf("%d * 3.5 = %d\n", lg, ((lg<<3)-lg)>>1);

        // measure time:
        long startTime = System.currentTimeMillis();
        long total = 0;
        for (int k = 0; k < 5000000; k++)
            total = k*10;
        System.out.println("Time Elapsed: " + (System.currentTimeMillis() - startTime) + "ms");

        // measure time:
        startTime = System.currentTimeMillis();
        total = 0;
        for (int k = 0; k < 5000000; k++)
            total = (k<<3) + (k<<1);
        System.out.println("Time Elapsed: " + (System.currentTimeMillis() - startTime) + "ms");

        //////////////////////////////
        // operators available in Java for bitwise ops

        // ~ -- bitwise NOT
        short s1 = 7;
        System.out.printf("~%d = %d\n", s1, ~s1);  // 00000111 => 11111000 (first bit == sign)

        // & -- bitwise AND
        System.out.printf("%d & %d = %d\n", 7, 3, 7&3);

        // | -- bitwise OR
        System.out.printf("%d | %d = %d\n", 7, 3, 7|3);

        // ^ -- bitwise XOR
        System.out.printf("%d ^ %d = %d\n", 7, 3, 7^3);

        //////////////////////////////

        //turn on a specific bit (starts at index 0)
        int bit=3;
        System.out.printf("%s with %dth bit on is %s\n",
                Integer.toBinaryString(s), bit+1, Integer.toBinaryString(  s|(1<<bit)  ));

        //turn off a specific bit (starts at index 0)
        bit=2;
        System.out.printf("%s with %dth bit off is %s\n",
                Integer.toBinaryString(s), bit+1, Integer.toBinaryString(  s&~(1<<bit)  ));

        //check if a certain bit is on (starts at index 0)
        bit=2;
        System.out.printf("Has %s the %dth bit on? %s\n",
                Integer.toBinaryString(s), bit+1, (s&(1<<bit))!=0  );

        //flip a certain bit (starts at index 0)
        bit=2;
        System.out.printf("%s with the %dth flipped is %s\n",
                Integer.toBinaryString(s), bit+1, Integer.toBinaryString(  s^(1<<bit)  ));

        //get least significant bit == 1 (starts at index 0)
        System.out.printf("least significant bit of %s at bit %s\n",
                Integer.toBinaryString(s), s&-s );

        //////////////////////////////
        // check if integers have opposite signs
        short x=3, y=-3;
        System.out.printf("%d has opposite sign of %d? %s\n", x, y, (x^y)<0 );

        // check if value is 2^x  (includes zero)
        System.out.printf("%d is a power of 2? %s\n", x, (x&(x-1)) == 0 );

        // counting bits
        int c,x1=x; for(c=0; x1!=0; x1>>=1) c += x1 & 1;
        System.out.printf("%d has %d bits 1\n", x, c );

        // get the next power of 2 (for integers, 32 bits)
        int v=1034;
        System.out.printf("next power of 2 of %d is %d\n", v, nextPower(v));

        // compute next lexicographic permutation, maintaining the number of bits 1
        v = 19;
        System.out.printf("next permutation of %s is %s\n",
                Integer.toBinaryString(v),
                Integer.toBinaryString(nextBitPermutation(v)));

        // compute next grey code, ie, a representation where two successive values differ in only one bit
        // eg for 4 bits: 0000->0001->0011->0010->0110->0111 ...
        IntStream.range(1,15)
                 .forEach(n -> System.out.printf("%s -> ", Integer.toBinaryString(grey(n)) ));
        System.out.println("...");


    }

    static int nextPower(int v) {
        v--;  v |= v >> 1;  v |= v >> 2;  v |= v >> 4;  v |= v >> 8;  v |= v >> 16;
        return ++v;
    }
    // number of bits 1 is invariant
    static int nextBitPermutation(int v) {
        int t = (v | (v - 1)) + 1;
        return t | ((((t & -t) / (v & -v)) >> 1) - 1);
    }

    // returns the n-th element on a grey code
    // ref: http://stackoverflow.com/questions/4166106
    static int grey(int n) {
        n--;
        return n ^(n>>1);
    }
}
