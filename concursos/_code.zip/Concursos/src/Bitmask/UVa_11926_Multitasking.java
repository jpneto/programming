package Bitmask;

import java.io.*;
import java.util.*;

public class UVa_11926_Multitasking {

    static final int SIZE = 1_000_000;
    static final int allMask = 0xFFFF_FFFF;

    static int[] calendar;

    static boolean checkBit(int i) {
        if (i>=SIZE) return true;
        int index  = i/32, offset = i%32;
        return (calendar[index] & (1<<offset)) == 0;
    }

    // returns false if there's a conflict
    static boolean setBit(int i) {
        if (i>=SIZE) return true;
        int index  = i/32, offset = i%32;
        if ((calendar[index] & (1<<offset)) != 0)  // already was at 1
            return false;
        calendar[index] |= 1<<offset;
        return true;
    }

    // returns false if there's a conflict
    static boolean setBits(int beginInclusive, int endExclusive) {
        int firstInt = beginInclusive/32 + 1;
        int lastInt  = Math.min(endExclusive/32 - 1, calendar.length-1); // to prevent invalid index access

        for(int i=firstInt; i<=lastInt; i++) { // fast ones
            if (calendar[i] != 0)
                return false;
            calendar[i] = allMask;
        }

        // set the previous bits
        int until = Math.min(firstInt*32, endExclusive);
        for(int i=beginInclusive; i<until; i++)
            if (!setBit(i))
                return false;

        int from = Math.max(endExclusive,(lastInt+1)*32);
        for(int i=from; i<endExclusive; i++)
            if (!setBit(i))
                return false;

        return true;
    }

    public static void main(String[] args) {
        if (!new Object(){}.getClass().getName().contains("Main"))
            // if true: read from files; else: read from System.in
            try {
                System.setIn (new FileInputStream("data/uva11926.in.txt" ));
                System.setOut(new PrintStream("data/uva11926.out.txt") );
            } catch (Exception e) {}
        ///////////////////////

        Scanner sc = new Scanner(System.in);

        while(true) {
            int oneTime   = sc.nextInt(),
                repeating = sc.nextInt();

            if(oneTime==0 && repeating==0) break;

            boolean conflict = false;
            calendar = new int[(SIZE+32)/32];  // a little extra for the integer division

            for(int i=0; i<oneTime; i++) {
                int begin = sc.nextInt(),
                    end   = sc.nextInt();
                if (conflict) continue;  // need to consume all input
                conflict = !setBits(begin, end);
            }

            for(int i=0; i<repeating; i++) {
                int begin = sc.nextInt(),
                    end   = sc.nextInt(),
                    step  = sc.nextInt();
                if (conflict) continue;  // need to consume all input

                while(begin<SIZE && !conflict) {
                    conflict = !setBits(begin, end);
                    begin += step;
                    end += step;
                }
            }

            System.out.println(conflict ? "CONFLICT" : "NO CONFLICT");
        }
    }
}
