package Greedy;

import java.io.FileInputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Scanner;

public class UVa_11389_The_Bus_Driver_Problem {

    public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva11389.in.txt" ));
                System.setOut(new PrintStream("data/uva11389.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        while (true) {
        	int n = sc.nextInt();
        	int d = sc.nextInt();
        	int r = sc.nextInt();
        	
        	if (n+d+r==0)
        		break;

        	int[] mornings   = new int[n];
        	int[] afternoons = new int[n];
        	
        	for(int i=0; i<n; i++)
        		mornings[i] = sc.nextInt(); 
        	
        	for(int i=0; i<n; i++)
        		afternoons[i] = sc.nextInt(); 

        	Arrays.sort(mornings);
        	Arrays.sort(afternoons);
        	
        	int overtimeAmount = 0;
        	
        	// just give the smallest morning job and the largest afternoon job
        	// to the first driver, and so on...
        	for(int i=0; i<n; i++) {
        		int extraTime = mornings[i] + afternoons[n-i-1] - d;
        		if (extraTime>0)
        			overtimeAmount += extraTime*r;
        	}
        	
        	System.out.println(overtimeAmount);
        }
        
        sc.close();

    }
}
