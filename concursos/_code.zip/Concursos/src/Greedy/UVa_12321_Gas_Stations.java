package Greedy;

import java.io.*;
import java.util.*;

// Interval Coverage problem
public class UVa_12321_Gas_Stations {
	
	static class StationCoverage implements Comparable<StationCoverage>{
	    int left, right;
	    StationCoverage(int l, int r) {
	    	left=l; right=r;
	    }
	    public int compareTo(StationCoverage other) {
            return left == other.left ? other.right - right : left - other.left;
        }
	    //public String toString() { return String.format("[%1.3f, %1.3f]", left, right);}
	}

	public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva12321.in.txt" ));
                System.setOut(new PrintStream("data/uva12321.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        while (true) {
            int lengthRoad = sc.nextInt();
            int nStations  = sc.nextInt();

            if (lengthRoad == 0 && nStations == 0)
                break;
            
            StationCoverage[] coverage = new StationCoverage[nStations]; 
            for(int i=0; i<nStations; i++) {
            	int location = sc.nextInt();
            	int radius   = sc.nextInt();
            	coverage[i] = new StationCoverage(location-radius, location+radius);           	
            }
            	
            Arrays.sort(coverage); // stations might not be increasingly ordered
            
            int currentStationIdx = 0 ;
            int necessaryStations = 0;
            int coveredUpTo = 0 ;
            
            while (coveredUpTo < lengthRoad) {
                int bestStationIdx = - 1;

                while (currentStationIdx < coverage.length && 
                	   coverage[currentStationIdx].left <= coveredUpTo) {
                	
                    if ( coverage[currentStationIdx].right >= coveredUpTo && 
                    	 ( bestStationIdx == -1 || 
                    	   coverage[currentStationIdx].right > coverage[bestStationIdx].right
                    	 )
                       )
                        bestStationIdx = currentStationIdx;

                    currentStationIdx++;
                }
                
                if (bestStationIdx == -1) 
                	break;
                
                coveredUpTo = coverage[bestStationIdx].right;
                necessaryStations++;
            }

            if (coveredUpTo < lengthRoad) 
            	System.out.println(-1);
            else 
            	System.out.println(nStations - necessaryStations);
            
        } // while(true)
        
        sc.close();
    }
}
