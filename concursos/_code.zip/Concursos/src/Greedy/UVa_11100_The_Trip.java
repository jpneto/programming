package Greedy;

import java.io.*;
import java.util.*;

public class UVa_11100_The_Trip {
	
	public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva11100.in.txt" ));
                System.setOut(new PrintStream("data/uva11100.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        boolean first = true;
        
        while (true) {
            int nPieces = sc.nextInt();

            if (nPieces==0)
            	break;
            
            if (first)
            	first = false;
            else
                System.out.println();          	
            
            int[] pieces = new int[nPieces];
            for(int i=0; i<nPieces; i++)
            	pieces[i] = sc.nextInt();
            Arrays.sort(pieces);
            
            // the number of bags we need is the maximum number of
            // repetitions the vector have
            
            int maxRepetitions = 1;
            for(int i=0, currentRepetitions=1; i<nPieces-1; i++) {
            	
            	if (pieces[i] == pieces[i+1]) {
            		currentRepetitions++;
            		if(i<nPieces-2)  // since we leave one out in the loop
            			continue;    // we need to count it below, in the case of a repetition
            	}
            	
            	if (currentRepetitions>maxRepetitions)
            		maxRepetitions = currentRepetitions;
            	
            	currentRepetitions=1;
            }
            
            System.out.println(maxRepetitions);
            
            // for each bag, get some non repeated numbers 
            // jump 'maxRepetitions' values to assure not getting a repeated number
            for(int i=0; i<maxRepetitions; i++) {
            	StringBuilder sb = new StringBuilder();
            	for(int j=i; j<nPieces; j+=maxRepetitions)
            		sb.append(pieces[j]+" ");
            	System.out.println(sb.substring(0, sb.length()-1)); // skip last space
            }
        } // while(true)
        
        sc.close();
    }
}
