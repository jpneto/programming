package Greedy;

import java.io.*;
import java.util.*;

class Interval {
    double left, right;
    Interval(double l, double r) {left=l; right=r;}
    //public String toString() { return String.format("[%1.3f, %1.3f]", left, right);}
}

/**
 * Created by jpn on 15-03-2017.
 */
public class UVa_1193_Radar_Installation {

    public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva1193.in.txt" ));
                System.setOut(new PrintStream("data/uva1193.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);
        int sampleCase = 1;

        while (true) {
            int nIslands = sc.nextInt();
            int radius = sc.nextInt();

            if (nIslands == 0 && radius == 0)
                break;

            boolean outOfRange = false;
            Interval[] intervals = new Interval[nIslands];

            for (int i = 0; i < nIslands; i++) {
                int x = sc.nextInt(), y = sc.nextInt();
                if (y>radius)  // island out of range, this means failure!
                    outOfRange = true;
                else {
                    //             . (x,y)
                    //            /|\
                    //           / | \ radius
                    //    ______/__|__\_______
                    //      left   x   right                              prevents point intervals
                    double halfDistance = Math.sqrt(radius * radius - y * y) + 1e-8;
                    intervals[i] = new Interval(x - halfDistance, x + halfDistance);
                }
            }

            if (outOfRange) {
                System.out.printf("Case %d: %d\n", sampleCase++, -1);
                continue;
            }

            Arrays.sort(intervals, (Interval i1, Interval i2) -> {
                if (i1.right > i2.right) return 1;  // sort by increasing right side
                if (i1.right < i2.right) return -1;
                return 0;
            });

            // we need to start from the left farthest interval.
            // do it greedly, the next radar needs only to be at the right
            // of the last included interval (that's why we sorted above)
            int count=0;
            for (int i=0; i<nIslands;) {
                int j;
                for(j=i; j<nIslands; j++) {  // j=0 isn't needed
                    if(intervals[j].left > intervals[i].right)
                        break;
                }
                i = j;
                count++;
            }
            System.out.printf("Case %d: %d\n", sampleCase++, count);
        } // while(true)
    }
}
