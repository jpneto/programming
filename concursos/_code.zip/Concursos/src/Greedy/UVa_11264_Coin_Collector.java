package Greedy;

import java.io.*;
import java.util.*;

public class UVa_11264_Coin_Collector {
    public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva11264.in.txt" ));
                System.setOut(new PrintStream("data/uva11264.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        int nCases = sc.nextInt();
        while (nCases-- > 0) {
        	
        	int nCoins = sc.nextInt();
        	
        	int[] coins = new int[nCoins];
        	for(int i=0; i<nCoins; i++)
        		coins[i] = sc.nextInt();

        	if (nCoins==1) {
        		System.out.println(1);
        		continue;
        	}

        	// it's always possible to get the first and last coins
        	int withdrawnCoins = 2;
        	int amount = coins[0];
        	
        	// for all the others:
        	// we can get the ith coin if (i+1)th > amount + ith
        	// otherwise, the bank would give us the (i+1)th coin 
        	for(int i=1; i<nCoins-1; i++)
        		if (coins[i+1] > amount + coins[i]) {
        			withdrawnCoins++;
        			amount += coins[i];
        		}
        	
        	System.out.println(withdrawnCoins);
        	
        }
        
        sc.close();
    }
}
