package Greedy;

import java.util.*;
import java.io.*;

public class UVa_12405_Scarecrow {

	static final char SCARECROW = '*';
	static final char COVERED = '+';
	
	public static void main(String[] args) {

		if (!new Object(){}.getClass().getName().contains("Main"))
			try {   // redirect System.in and System.out to in/out text files
				System.setIn (new FileInputStream("data/uva12405.in.txt" ));
				System.setOut(new PrintStream("data/uva12405.out.txt") );
			} catch (Exception e) {}
		///////////////////////////////////////////////////////////////

		Scanner sc = new Scanner(System.in);

		int caseNumber = 1;
		int nCases = sc.nextInt();
		while (nCases-- > 0) {
			
			int size = sc.nextInt();

			StringBuilder field = new StringBuilder(sc.next());
			
			if (field.length()==1) {
				System.out.printf("Case %d: %d\n", caseNumber++, 1);
				continue;
			}
			
			int scarecrow = 0;

			int i=0;
			while (i<field.length() && field.charAt(i) == '#') i++;	
			
			for(; i<field.length(); i++) {
				if (i==0 || field.charAt(i-1)==SCARECROW)
					continue;
				
				if (field.charAt(i-1)=='.') {
					field.setCharAt(i,   SCARECROW);
					if (i<field.length()-1) {
						field.setCharAt(i+1, COVERED); // also controlled
						i++;
					}
					scarecrow++;
				}
			}
			
			// there might be a last uncovered land
			if(field.charAt(field.length()-1)=='.')
				scarecrow++;
			
			System.out.printf("Case %d: %d\n", caseNumber++, scarecrow);
		}
		
		sc.close();
	}
}