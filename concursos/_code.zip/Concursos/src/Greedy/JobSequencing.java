package Greedy;

import java.util.*;

// ref: https://www.geeksforgeeks.org/job-sequencing-problem/
public class JobSequencing {

	static char[] scheduling(ArrayList<Job> jobs, int maxTime) { 

		boolean[] isOccupied  = new boolean[maxTime]; 
		char[]    jobSequence = new char[maxTime]; 

		// sort jobs by decreasing order of profit 
		Collections.sort(jobs, (a,b) -> b.profit - a.profit); 

		for (int i=0; i<jobs.size(); i++) { 
			// find free slot (from the lastest possible option) 
			for (int j=Math.min(maxTime, jobs.get(i).deadline)-1; j>=0; j--) { 
				if (!isOccupied[j]) { 
					isOccupied[j]  = true; 
					jobSequence[j] = jobs.get(i).id; 
					break; 
				} 
			} 
		} 
		return jobSequence;
	}   

	public static void main(String[] args) {
		ArrayList<Job> arr = new ArrayList<Job>(); 

		arr.add(new Job('a', 4, 20)); 
		arr.add(new Job('b', 1, 10)); 
		arr.add(new Job('c', 1, 40)); 
		arr.add(new Job('d', 1, 30)); 

		System.out.println(Arrays.toString(scheduling(arr, 3))); 
	} 
}


class Job { 
  char id; 
  int deadline, profit; 

  public Job(char id, int deadline, int profit)  { 
    this.id = id; 
    this.deadline = deadline; 
    this.profit = profit; 
  }
}