package Greedy;

import java.io.*;
import java.util.*;

public class UVa_10026_Shoemaker_Problem {
	
	static class Job implements Comparable<Job> {
		int time, fine, index;
		
		Job(int t, int f, int i) { time=t; fine=f; index=i;}

		// the bigger Job is the one with higher fine/days ratio
		// if fine/time > o.fine/o.time, return 1
		// if equal, the largest is the one appearing later in the input
		public int compareTo(Job o) {
			if (fine*o.time == o.fine*time)
				return index > o.index ? -1 : 1;
			return fine*o.time > o.fine*time ? 1 : -1;
		}
		
//		public String toString() {
//			return String.format("[t=%d, f=%d, %d] ", time, fine, index);
//		}
	}
	
	public static void main(String[] args) {

        if (!new Object(){}.getClass().getName().contains("Main"))
            try {   // redirect System.in and System.out to in/out text files
                System.setIn (new FileInputStream("data/uva10026.in.txt" ));
                System.setOut(new PrintStream("data/uva10026.out.txt") );
            } catch (Exception e) {}
        ///////////////////////////////////////////////////////////////

        Scanner sc = new Scanner(System.in);

        int nCases = sc.nextInt();
        boolean first=true;
        
        while (nCases-- > 0) {
        	if (first)
        		first = false;
        	else
            	System.out.println();
        	
        	int nJobs = sc.nextInt();
        	
        	Job[] jobs = new Job[nJobs];
        	for(int i=0; i<nJobs; i++)
        		jobs[i] = new Job(sc.nextInt(), sc.nextInt(), i+1);
        	Arrays.sort(jobs, Collections.reverseOrder());
        	
        	StringBuilder sb = new StringBuilder();
        	for(Job job : jobs)
        		sb.append(job.index).append(' ');
        	
        	System.out.println(sb.substring(0, sb.length()-1));
        } // while(true)
        
        sc.close();
    }
}
