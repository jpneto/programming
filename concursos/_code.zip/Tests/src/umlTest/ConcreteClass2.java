package umlTest;

public class ConcreteClass2 implements Interface {
   public void method2() {};
   
   public void requiredMethod(int parameter) {};
}
