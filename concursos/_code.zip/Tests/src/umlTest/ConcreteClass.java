package umlTest;

public class ConcreteClass implements Interface {

	ConcreteClass2 c;
	
	@Override
	public void requiredMethod(int parameter) {
		return;
	}

}
