package umlTest;

/**
 * To create a diagram rclick package umlTest and select New | Other | UmlLet Diagram
 * @author jpn3t
 *
 */
public interface Interface {
   void requiredMethod(int parameter);
}
