package umlTest;

public class User {
	private Interface[] data;
}
