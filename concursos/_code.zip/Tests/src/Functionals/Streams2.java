package Functionals;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by jpn on 05-11-2016.
 */
public class Streams2 {

    public static class Person implements Comparable<Person>{
        String name; int age;
        public Person(String n, int a) {name=n; age=a;}
        public String toString() {return name + ":" + age;}

        public int compareTo(Person other) {
            int cmp = name.compareTo(other.name);
            if (cmp==0) return age - other.age;
            return cmp;
        }
    }

    public static void main(String[] args) {

        final String str = "abc3d e5fg";

        str.chars()  // returns a stream of ints
           .filter(Character::isAlphabetic)
           .forEach(c -> System.out.print((char)c+","));

        ///////////////////

        List<Person> persons = new LinkedList<Person>();
        persons.add(new Person("Ana",35));
        persons.add(new Person("Ze" ,50));
        persons.add(new Person("Rui",26));
        persons.add(new Person("Ze" ,20));
        persons.add(new Person("Ana",20));
        System.out.println("\n"+persons.toString());

        // sort list by given criteria:
        List<Person> personsOrd =
            persons.stream()
                   .sorted((person1, person2) -> {
                       int cmp = person1.name.compareTo(person2.name);
                       if (cmp==0) return person1.age - person2.age;
                       return cmp;
                   })
                   .collect(Collectors.toList());
        System.out.println(personsOrd.toString());

        // since Person is Comparable:
        personsOrd =
                persons.stream()
                        .sorted(Person::compareTo)
                        .collect(Collectors.toList());
        System.out.println(personsOrd.toString());

        // another way:
        Comparator<Person> person_asc =
                (person1, person2) -> {
                    int cmp = person1.name.compareTo(person2.name);
                    if (cmp==0) return person1.age - person2.age;
                    return cmp;
                };

        personsOrd =
            persons.stream()
                    .sorted(person_asc)
                    .collect(Collectors.toList());
        System.out.println(personsOrd.toString());

        // até se pode reverter

        personsOrd =
            persons.stream()
                    .sorted(person_asc.reversed())
                    .collect(Collectors.toList());
        System.out.println(personsOrd.toString());

        // yet another way:

        final Function<Person, Integer> byAge = person -> person.age;
        final Function<Person, String> byName = person -> person.name;

        personsOrd =
            persons.stream()
                    .sorted(Comparator.comparing(byName).thenComparing(byAge))
                    .collect(Collectors.toList());
        System.out.println(personsOrd.toString());

        //////////////////////

        List<Person> olderThan20 = new ArrayList<>();
        persons.stream()
               .filter(person -> person.age > 20)
               .forEach(person -> olderThan20.add(person));
        System.out.println("People older than 20: " + olderThan20);

    }
}
