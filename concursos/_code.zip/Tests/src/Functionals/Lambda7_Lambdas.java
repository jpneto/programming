package Functionals;

public class Lambda7_Lambdas {

	public static void main(String[] args) {

		// cf. pg. 51
	}

}
