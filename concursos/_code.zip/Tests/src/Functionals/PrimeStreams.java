package Functionals;

import java.util.List;
import java.util.stream.*;

public class PrimeStreams {

	/**
	 * Now I want you to think carefully about how we solved this problem. 
	 * No if statements. No while loops. Instead we envisioned lists of data 
	 * flowing through filters and mappers. 
     * Instead of imagining a procedural solution, we imagine a data-flow solution.
     * Think hard on this – it is one of the keys to functional programming.
     * @ref: http://blog.cleancoder.com/uncle-bob/2020/04/09/ALittleMoreClojure.html
     * 
	 * @param n 
	 * @return
	 */
	public static boolean isPrime(long n) {
	    return LongStream.rangeClosed(2, (long) Math.sqrt(n))
	                     .allMatch(i -> n % i != 0);
	}
	
	public static List<Long> primeSequence(long begin, long end) {
	    return LongStream.range(begin, end)
	                     .filter(PrimeStreams::isPrime)
	                     .boxed()
	                     .collect(Collectors.toList());
	}
	
	public static void main(String[] args) {
		System.out.println(primeSequence(10, 200));
	}

}
