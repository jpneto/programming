package Functionals;

import java.util.*;
import java.util.function.Function;
import java.util.stream.*;

/** Material from "Java SE 8 for the Really Impatient"
 * 
 * @author jpn
 */
public class Lambda5 {
	
	public static List<Character> string2list(String s) {
		List<Character> result = new LinkedList<Character>();
		
		s.chars().forEach(c -> result.add((char)c));
		
		return result;
	}
	
	/////////////////////////////////////////////////////////////

	public static Function<Integer, Integer> incFactory(int add) {
		return (i) -> add+i;
	}

	/////////////////////////////////////////////////////////////

	public static void main(String[] args) {

		String[] words = {"abc", "w", "ytrwe", "ee"};
		
		// this is an implementation of a Functional Interface, 
		// ie, an interface that has just one abstract method
		Comparator<String> comp = 
				(first, second) -> Integer.compare(first.length(), second.length());
		
		Arrays.sort(words, comp); // sort strings by size
		
		System.out.println(Arrays.toString(words));
		
		/////////////////////////////////////////////////////////////

		// transform the vector of strings into a list of list of chars:
		Stream<String> s = Arrays.stream(words);
		Stream<List<Character>> s1 =s.map(Lambda5::string2list);
		List<List<Character>> s2 = s1.collect(Collectors.toList());

		/////////////////////////////////////////////////////////////

		// use an array of ints to make arrays of those sizes
		int[] sizes = {4, 5, 8, 1};
		
		// x -> new int[x]  is the same as int[]::new
		Stream<int[]> c = Arrays.stream(sizes).mapToObj(int[]::new);
		
		c.forEach(array -> System.out.println(Arrays.toString(array)));

		/////////////////////////////////////////////////////////////

		// sort array and print it
		Arrays.stream(sizes).sorted().forEach(System.out::println);
		
		/////////////////////////////////////////////////////////////

		// closure example:
		
		Function<Integer, Integer> inc1 = incFactory(1);
		System.out.println("1 -> " + inc1.apply(1));
		
		Function<Integer, Integer> inc2 = incFactory(2);
		System.out.println("1 -> " + inc2.apply(1));
		
		/////////////////////////////////////////////////////////////

		
		
		/////////////////////////////////////////////////////////////

		
		
		/////////////////////////////////////////////////////////////

	}

}
