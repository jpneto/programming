package Functionals;

import java.util.*;

/**
 * Created by jpn on 04-11-2016.
 */
public class Optionals {

    public static void main(String[] args) {

        LinkedList<Integer> lst = new LinkedList<Integer>();
        lst.add(1); lst.add(2); lst.add(3); lst.add(5); lst.add(4); lst.add(2);

        // O tipo Optionals serve como Maybe, o resultado pode não existir:
        Optional<Integer> max = lst.stream()
                .reduce(Math::max);  // pode não existir se a lista estiver vazia

        if (max.isPresent())
            System.out.print(max.get());

        max.ifPresent(num -> System.out.print(num));  // or just...
        max.ifPresent(System.out::println);

        // outra forma é usar o orElse para criar um valor default
        max = new LinkedList<Integer>().stream().reduce(Math::max);
        int maxValue = max.orElse(-100);
        maxValue = max.orElseGet(() -> -100);   // pode-se tb passar um supplier
        System.out.println(maxValue);

        ////////////////////////

        Integer i = null;
        Optional<Integer> optInt = Optional.ofNullable(i);  // if i is null, returns an empty Optional
        System.out.println(optInt.orElse(-100));
    }
}
