package Functionals;

import java.util.List;
import java.util.Arrays;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.*;

public class Lambda3 {

	
	public static boolean isPrime(Integer number) {
				
		return number>1 &&
			   IntStream.range(2, number)
			            .noneMatch(index -> number % index == 0);
	}
	
	public static int twice(int number) {
		System.out.println("checking number " + number); // check lazyness
		return number*2;
	}
	
	// sums only those numbre that satisfy the selector
	public static int totalValues(List<Integer> number, Predicate<Integer> selector) {
		// imperative style
		int result = 0;
		for(int e: number)
			if(selector.test(e)) 
				result += e;
		return result;		
	}
	
	public static void main(String[] args) {

		IntStream.range(2, 10).forEach(n -> System.out.println(n+": "+isPrime(n)));
		
		////////////////
		
		List<Integer> values = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
	
		// a predicate definition
		Predicate<Integer> isEven = number -> number % 2 == 0;
		
		// a function than receives an int and returns a predicate over that int
		Function<Integer, Predicate<Integer>> isGreaterThan =
				pivot -> (number -> number > pivot); 
		
		// show the double of the first even number > 3:
		Stream<Integer> myStream = values.stream()   // these streams are lazy
  								         .filter(isGreaterThan.apply(3))
								         .filter(isEven)
								         .map(Lambda3::twice);
		System.out.println(
				myStream.findFirst()  
		); // it returns Optional[8], since it's not certain that values has evens
		
		//////////////////////
		
		System.out.println(  totalValues(values, e->true) );
		System.out.println(  totalValues(values, e->e%2==0) );
	}
}
