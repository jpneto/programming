package Functionals;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

// NOT WORKING

public class Memoizer<T, U> {
    private final Map<T, U> cache = new ConcurrentHashMap<>();

    private Memoizer() {}

    private Function<T, U> doMemoize(final Function<T, U> function) {
        return input -> cache.computeIfAbsent(input, function::apply);
    }

    public static <T, U> Function<T, U> memoize(final Function<T, U> function) {
        return new Memoizer<T, U>().doMemoize(function);
    }

    ////////////

    public static long fib(int n) {
        if (n<2) return 1;
        return fib(n-1) + fib(n-2);
    }

    public static void main(String[] args) {

        Function<Integer, Long> fib_mem = memoize(Memoizer::fib);

        ///////////

        long startTime = System.currentTimeMillis();
        Long result1 = fib(40);
        long time1 = System.currentTimeMillis() - startTime;
        System.out.println(result1);
        System.out.println(time1);

        for (int i=0;i<45;i++)
            System.out.print(fib_mem.apply(i) + ",");

        startTime = System.currentTimeMillis();
        Long result2 = fib_mem.apply(45);
        long time2 = System.currentTimeMillis() - startTime;
        System.out.println(result2);
        System.out.println(time2);
    }
}