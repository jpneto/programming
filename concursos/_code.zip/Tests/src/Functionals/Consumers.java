package Functionals;

import java.util.*;
import java.util.function.*;

/**
 * Created by jpn on 04-11-2016.
 */
public class Consumers {

    private static int currentPower = 1;
    public static int nextPower() {
        int old = currentPower;
        currentPower*=2;
        return old;
    }

    public static class Point{ double x, y; Point() {x=y=0;}}

    public static void main(String[] args) {

        // Um consumidor é uma operação que aceita um argumento e não devolve resultado
        // É assumido que o que interessa são os efeitos secundários
        // Também existe BiConsumer<T,U>.
        Consumer<Integer> csm = n -> System.out.println("consumido " + n + " produzimos: " + n*2);
        csm.accept(4);
        csm.accept(6);

        Consumer<Integer> csm2 = n -> System.out.println("...e ainda produzimos: " + n*3);
        csm.andThen(csm2).accept(4);

        // as collections possuem o método forEach que aceita um consumidor:
        LinkedList<Integer> lst = new LinkedList<Integer>();
        lst.add(1); lst.add(2); lst.add(3); lst.add(5);
        lst.forEach(n -> System.out.print(n+", "));

        ///////////////////

        // Um produtor produz um resultado de um certo tipo. Como tem estado, pode
        // produzir resultados diferentes de cada vez que é invocado.
        Supplier<Integer> sup = Consumers::nextPower;
        System.out.println(sup.get() + ":" + sup.get() + ":" + sup.get() + ":" + sup.get());

        // util para object factory
        Supplier<Point> pointFactory = Point::new;
        Point p = pointFactory.get();

        ////////////////////

        // Supplier -> Consumer
        Supplier<List<Integer>> sup2 = () -> { return Arrays.asList(1,2,3,4,5); };
        sup2.get().forEach(csm);

    }
}
