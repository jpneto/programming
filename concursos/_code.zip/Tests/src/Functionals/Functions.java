package Functionals;

import java.util.*;
import java.util.function.*;
/**
 * Created by jpn on 04-11-2016.
 */
public class Functions {

    public static int m( BiFunction<Integer, Integer, Integer> f, int i, int j ) {
        return f.apply(i,j);
    }

    // testing Functions and Predicates
    public static void main(String[] args) {

        // Predicatos são funções booleanas
        Predicate<Double> isZero = x -> Math.abs(x) < 1e-6;
        Predicate<Double> isPositive = x -> x > 0;
        Predicate<Double> isNegative = isZero.or(isPositive).negate();
        System.out.println( isNegative.test(-5.0) + ":" + isZero.test(0.001) );

        Predicate<Integer> isPrime = n -> {
            boolean prime=true;
            for(int i=2;i<n/2 && prime;i++)
                prime = n%i==0;
            return prime;
        };
        System.out.println("5 é primo? " + isPrime.test(5));

        // Function representa funções unárias
        Function<Integer, String> addExclamation = (x) -> x+"!";
        System.out.println( addExclamation.apply(4) );

        // Função unária que devolve o mesmo tipo
        UnaryOperator<Integer> dobro = n -> 2*n;
        System.out.println("dobro de 5 = " + dobro.apply(5));

        // BiFunction representa funções binárias
        BiFunction<Integer,Integer,Integer> addition = (x,y) -> x + y;
        System.out.println( "2 + 3 = " + addition.apply(2,3) );

        // Função unária com apenas um tipo
        BinaryOperator<Double> hipotenusa = (x,y) -> Math.sqrt(x*x+y*y);
        System.out.println("Hipotenusa: " + hipotenusa.apply(3.0,4.0));

        // A composição de funções é possível com andThen
        BiFunction<Integer, Integer, String> add2String =  addition.andThen( addExclamation );
        System.out.println( "4+5=" + add2String.apply(4,5) );

        // As expressões lambda podem ser passadas como argumento:
        int a = m( (x,y)-> x+y, 10, 20 );
        int b = m( (x,y)-> x*y, 10, 20 );
        System.out.println(a+":"+b);

        // Exemplo de uma closure
        Function<Integer, Integer> inc1 = incFactory(1);
        System.out.println("1 -> " + inc1.apply(1));

        Function<Integer, Integer> inc2 = incFactory(2);
        System.out.println("1 -> " + inc2.apply(1));
    }

    public static Function<Integer, Integer> incFactory(int add) {
        return (i) -> add+i;
    }
}
