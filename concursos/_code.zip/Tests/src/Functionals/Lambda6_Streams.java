package Functionals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Lambda6_Streams {

	public static void np() { System.out.println("-------------------"); }

	public static Stream<Character> characterStream(String s) {
		List<Character> result = new ArrayList<>();
		for (char c : s.toCharArray()) 
			result.add(c);
		return result.stream();
	}

	public static void main(String[] args) {
		
		String text = "There was nothing so very remarkable in that, nor did Alice think it so very much out of the way to hear the Rabbit say to itself, "
				+ "\"Oh dear! Oh dear! I shall be too late!\" But when the Rabbit actually took a watch"
				+ "out of its waistcoat-pocket and looked at it and then hurried on, Alice started "
				+ "to her feet, for it flashed across her mind that she had never before seen "
				+ "a rabbit with either a waistcoat-pocket, or a watch to take "
				+ "out of it, and, burning with curiosity, she ran across the field after "
				+ "it and was just in time to see it pop down a large rabbit-hole, under "
				+ "the hedge. In another moment, down went Alice after it!";

		// get words from text
		List<String> words = Arrays.asList(text.split("[\\s,.!?\"]+"));

		// print words, stream style:
		words.stream().forEach(System.out::println);
		
		np();

		// print only words great than 5 chars:
		words.stream().filter(word -> word.length()>5).forEach(System.out::println);
		
		np();
		
		// a stream does not store its elements like a collection
		// the forEach consume them after it's done
		
		// stream don't mutate their source, they return new streams with
		// new data
		
		// streams are lazy, they don't evaluate until needed
		
		// since we deal with immutable data, they can be easily parallelized:
		words.parallelStream().filter(word -> word.length()>5).forEach(System.out::println);
		
		np();
		
		/*
		 * There are three phases:
		 * 1. stream creation
		 * 2. stream transformation
		 * 3. applying a terminal operation
		 *    that's when the computations are made and the stream consumed 
		 */
		
		// 1. Creation egs:
		
		Stream<String>  s1 = Stream.of(text.split("[\\s,.!?\"]+"));  // deal with arrays
		Stream<Integer> s2 = Stream.of(new Integer[] {1,2,3,4,5});
		
		// parts of an array
		Stream<String> s3 = Arrays.stream((String[])words.toArray(), 3, 7);
		s3.forEach(System.out::println);
		
		np();
		
		// the previous split in stream form
		Stream<String> s4 = Pattern.compile("[\\s,.!?\"]+").splitAsStream(text);
		s4.forEach(System.out::println);
		
		np();
		
		// create infinite lists:
		Stream<String> echos = Stream.generate(() -> "Echo");  // constant values
		echos.limit(5).forEach(System.out::println);
		
		Stream<Double> randoms = Stream.generate(Math::random); // random values
		randoms.limit(5).forEach(System.out::println);
		
		// when the next requires the previous value
		Stream<Integer> integers = Stream.iterate(0, n -> n+1); 
		integers.limit(10).forEach(System.out::println);
		
		// when the next needs multiple previous values:
		Stream<Long> fibs = Stream.iterate(
		        new long[]{1, 1},
		        f -> new long[]{f[1], f[0] + f[1]}
		).map(f -> f[0]);
		fibs.limit(10).forEach(System.out::println);
		
		np();
		
		// 2. Transformation egs:
		
		// filter() selects some elements based on a predicate
		// distinct() removes duplicates
		
		words.stream().filter(word -> word.charAt(0)=='a')
					  .distinct()
		              .forEach(System.out::println);
		np();
		
		// Concatenate two streams (the 1st cannot be infinite)
		Stream.concat(characterStream("Hello"), characterStream("World"))
			  .forEach(System.out::println);  np();
		
		// limit(n) and skip(n) resp. takes and drops the first n elements
		
		words.stream().limit(10).forEach(System.out::println); 		np();
		words.stream().skip(120).forEach(System.out::println);		np();
		
		// flatMap converts a stream of streams into a single strean
		Stream<Character> letters = words.stream()
				                         .flatMap(w -> characterStream(w));
		letters.forEach(System.out::print);  np(); np();
		
		// for debugging purposes, use peek() that does not change the stream
		// but executes a function for each element
		
		s2 = Stream.of(new Integer[] {1,2,3,4,5});
		
		long result = s2.peek(e -> System.out.print("elem before is " + e))
 			 		    .map(e -> 2*e)
 			 		    .peek(e -> System.out.println(" elem after  is " + e))
 			 		    .count();  np();
 			 		    
 	    // 3. Terminal Operations
 			 		    
 		// one option is to reduce the stream into a single result
 			 		    
 		Optional<String> largest = words.stream().max(String::compareToIgnoreCase);
 		// max returns an optional value (it might not exist)
 		if (largest.isPresent())
 			System.out.println("largest: " + largest.get());	
 		
 		// or:
 		largest.ifPresent(v -> System.out.println("largest: " + v));    np();
 		// btw, to create Optionals:
 		// Optional<Double> y = x == 0 ? Optional.empty() : Optional.of(1 / x);
 		
 		// Use of reduce:
 		s2 = Stream.of(new Integer[] {1,2,3,4,5});
 		
 		Optional<Integer> sum = s2.reduce((acc,x)->acc+x);
 		sum.ifPresent(System.out::println);
 		
 		// there is the reduce version with the identity value:
 		int sum2 = Stream.of(new Integer[] {1,2,3,4,5})
 		                 .reduce(0, (acc,x)->acc+x);
 		System.out.println(sum2);   np();
 		
 		// placing results on collections:
 		
 		String[] res1 = Stream.of(new Integer[] {1,2,3,3,5})
  		 				      .map(Object::toString)
		 				      .toArray(String[]::new);
 	 	System.out.println(Arrays.toString(res1));
 	 	
 	 	List<Integer> res2 = Stream.of(new Integer[] {1,2,3,3,5})
 	 			                   .collect(Collectors.toList());
 	 	System.out.println(res2.toString()); 		

 	 	Set<Integer> res3 = Stream.of(new Integer[] {1,2,3,3,5})
                                  .collect(Collectors.toSet());
 	 	System.out.println(res3.toString()); 		
 	 	
 	 	// it's possible to decide which implementation:
 	 	Set<Integer> res4 = Stream.of(new Integer[] {1,2,3,3,5})
                                  .collect(Collectors.toCollection(TreeSet::new)); 	 	
 	 	System.out.println(res4.toString());   np();
 	 	
 	 	// Grouping and Partitioning
 	 	
 	 	// get JVM locales (just to serve as eg)
 	 	Stream<Locale> locales = Stream.of(Locale.getAvailableLocales());
 	 	
 	 	// group by country
 	 	Map<String, List<Locale>> countryToLocales = 
 	 			locales.collect(Collectors.groupingBy(Locale::getCountry));
 	 	System.out.println(countryToLocales.get("CH")); // locales of Switzerland
 	 	
 	 	// partition using a predicate
 	 	locales = Stream.of(Locale.getAvailableLocales());
 	 	Map<Boolean, List<Locale>> byEnglish = 
 	 	   locales.collect(Collectors.partitioningBy(l -> l.getLanguage().equals("en")));
 	 	List<Locale> englishLocales = byEnglish.get(true);
 	 	System.out.println(englishLocales);
 	 	
 	 	// group by country and count
 	 	locales = Stream.of(Locale.getAvailableLocales());
 	 	Map<String, Long> localesCounts = 
 	 		locales.collect(
 	 			Collectors.groupingBy(Locale::getCountry, Collectors.counting()));
 	 	System.out.println(localesCounts);
 	 	

 	 	
	}
}
