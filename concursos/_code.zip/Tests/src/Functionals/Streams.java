package Functionals;

import java.util.*;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * Created by jpn on 04-11-2016.
 */
public class Streams {

    public static void main(String[] args) {

        LinkedList<Integer> lst = new LinkedList<Integer>();
        lst.add(1); lst.add(2); lst.add(3); lst.add(5); lst.add(4); lst.add(2);

        Predicate<Integer> isOdd = (x) -> x%2 != 0;

        // Uma stream recebe uma collection e devolve um java.util.stream.Stream interface
        // Uma stream representa uma sequencia de elementos aos quais vários métodos são encadeados
        int sum = lst.stream()
                      .filter(isOdd)
                      .map(x -> x*x)
                      .reduce((x,y) -> x + y)    // reduce is a fold operation
                      .get();

        System.out.println("Sum = "+sum);      // ^-- these were egs of high-order functions

        ///////////////////////////////////////////////////////////
        // Uma stream é eliminada após o seu uso
        // Os elementos da collection não podem ser alterados pela stream
        // Para guardar os elementos criados pelas operações da stream, ter-se-á de os guardar numa
        //  nova collection
        List<Integer> newLst = lst.stream()
                                  .map(x -> x*x)
                                  .collect(Collectors.toList());
        newLst.forEach(n -> System.out.print(n+", "));

        // use of IntStream:
        IntStream.range(2, 10).forEach(n -> System.out.println(n+": "+isPrime(n)));

        /////////////////////////////
        // A avaliação das streams é lazy:

        List<Integer> values = Arrays.asList(1,2,3,4,5,6,7,8,9,10);

        // a function than receives an int and returns a predicate over that int
        Function<Integer, Predicate<Integer>> isGreaterThan =
                pivot -> (number -> number > pivot);

        // show the double of the first even number > 3:
        Stream<Integer> myStream = values.stream()
                .filter(isGreaterThan.apply(3))
                .filter(number -> number % 2 == 0)
                .map(Streams::twice);

        // it returns Optional[8], since it's not certain that list values has even numbers
        System.out.println( myStream.findFirst() );

        /////////////////////////
        // Como os valores da stream são imutáveis (não mudam a collection que a produziu,
        // elas são facilmente paralelizaveis:

        System.out.println(
                values.stream()         // takes about 3 secs
                      .mapToInt(Streams::takesTime)  // Class::method(), Method Reference
                      .sum()
        );

        System.out.println(
                values.parallelStream() // takes about 1 sec
                      .mapToInt(Streams::takesTime)
                      .sum()
        );
    }

    ///////////////////


    public static boolean isPrime(Integer number) {
        return number>1 &&
                IntStream.range(2, 1+number/2)
                         .noneMatch(index -> number % index == 0);
    }

    public static int twice(int number) {
        System.out.println("checking number " + number); // check lazyness, see what gets printed
        return number*2;
    }

    public static int takesTime(int number) {
        try { Thread.sleep(500); } catch(Exception e) {} // something that takes time
        return number*2;
    }
}
