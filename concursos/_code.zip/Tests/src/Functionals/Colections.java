package Functionals;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by jpn on 04-11-2016.
 */
public class Colections {

    public static void main(String[] args) {

        List<String> names = Arrays.asList( "ana", "ze", "jorge", "luis" );

        /////////////////////

        // A collector acts as a sink object to receive elements passed by collect()
        String res = names.stream()
                          .map(String::toUpperCase)
                          .collect(Collectors.joining(", "));
        System.out.println(res);

        /////////////////////

        // Sort eg:
        Collections.sort( names, (String a, String b) -> b.compareTo(a) );
        names.forEach( System.out::println );

        /////////////////////

        int[] array2 = {2,5,7,9,11,20};
        List<Integer> li2 = new ArrayList<Integer>();
        for (int e:array2)
            li2.add(e);

        // convert ArrayList<Integer> to int[]
        // filter only needed if nulls are possible
        int[] array3 = li2.stream().filter(Objects::nonNull).mapToInt(i -> i).toArray();
        System.out.println(Arrays.toString(array3));

        int index = Collections.binarySearch(li2, 9);
        System.out.println("Element 9 is at index " + index);

        // reverse sort
        Collections.sort(li2, Collections.reverseOrder());
        System.out.println("Reverse sorted" + li2);

        // swap two elements
        Collections.swap(li2, 1, 4);
        System.out.println("Swap two elements" + li2);

        // how many elements 5 are in li?
        System.out.println(""+Collections.frequency(li2, 5));
    }
}
