package Functionals;

import java.util.*;
import java.util.function.*; // docs.oracle.com/javase/8/docs/api/java/util/function/package-summary.html
import java.util.stream.Collectors;

public class Lambda {

	public static void main(String[] args) {
		
		// Predicates are boolean functions
		Predicate<Double> isZero = (x) -> Math.abs(x) < 1e-6;
		System.out.println( isZero.test(0.001) );
		
		Predicate<Double> isPositive = (x) -> x > 0;
		Predicate<Double> isNegative = isZero.or(isPositive).negate();
		System.out.println( isNegative.test(-5.0) );
		
		// Function represents unary functions of type U -> V
		// There's also a subclass UnaryOperator<T> that receives and returns the same type
		Function<Integer, String> addExclamation = (x) -> x+"!";
		System.out.println( addExclamation.apply(4) ); // apply is function application
				
		// Bifunction represents binary functions of type U1 x U2 -> V
		BiFunction<Integer,Integer,Integer> addition = (x,y) -> x + y;
		System.out.println( "2 + 3 = " + addition.apply(2,3) );
		
		// andThen is function composition
		BiFunction<Integer, Integer, String> add2String =  addition.andThen( addExclamation );
		System.out.println( add2String.apply(4,5) );
		
		LinkedList<Integer> lst = new LinkedList<Integer>();
		lst.add(1);
		lst.add(2);
		lst.add(3);
		lst.add(5);
		lst.forEach(n -> System.out.print(n+", "));
		lst.forEach(System.out::print); // operator :: reference methods
		
		System.out.println("\nThere are " + lst.stream().distinct().count() + " distinct values in the list");
		
		Predicate<Integer> isOdd = (x) -> x%2 != 0;
		
		// stream() takes a Collection as input and returns a java.util.stream.Stream interface as the output. 
		// A stream represents a sequence of elements on which various methods can be chained.
		int sum = lst.stream().filter(isOdd).map(x -> x*x).reduce((x,y) -> x + y).get(); // reduce = fold operation
		System.out.println("\nSum = "+sum);      // ^-- these were egs of high-order functions
		
		// A stream is disposed of after its use. Therefore, the elements in a collection cannot be
		// changed or mutated with a stream. To keep elements returned from your chained operations, 
		// save them to a new collection.
		List<Integer> newLst = lst.stream().map((x) -> x*x).collect(Collectors.toList());
		newLst.forEach(n -> System.out.print(n+", "));
		
		// Optional values		
		Optional<Integer> max = lst.stream().reduce(Math::max); // max may not exist (eg: empty list)
		if (max.isPresent())
		  System.out.println("\n"+max.get()); // finds the maximum using fold(max)
	
		// sort eg
		List<String> names = Arrays.asList( "ana", "ze", "jorge", "luis" );
		Collections.sort( names, (String a, String b) -> b.compareTo(a) );
		names.forEach( e -> System.out.println(e) );
		
		//////////////////
		// Represents a supplier of results
		Supplier<Integer> sup = () -> { for (int i=0; i<10; i++) System.out.print(i); return 0; };
		sup.get();
		
		System.out.println("\n---");
		// Represents an operation that accepts a single input argument and returns no result.
		// Side effects are assumed. There's also BiConsumer<T,U>.
		Consumer<Integer> csm = (n) -> { System.out.print(n*2 + ", "); };
		csm.accept(4);
		
		System.out.println("\n---");
		lst.forEach(csm);
	
		System.out.println("\n---");
		// Composition of consumers
		Consumer<Integer> csm2 = (n) -> { System.out.print(n*3 + ", "); };
		csm.andThen(csm2).accept(10);
		
		System.out.println("\n---");
		// Supplier -> Consumer
		Supplier<List<Integer>> sup2 = () -> { return Arrays.asList(1,2,3,4,5); };
		sup2.get().forEach(csm);  // return 2, 4, 6, 8, 10, 
	}

}
