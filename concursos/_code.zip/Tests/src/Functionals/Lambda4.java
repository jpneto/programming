package Functionals;

import java.util.Arrays;
import java.util.List;

public class Lambda4 {

	public static int twice(int number) {
		try { Thread.sleep(500); } catch(Exception e) {} // something that takes time
		return number*2;
	}

	public static void main(String[] args) {

		List<Integer> numbers = Arrays.asList(1,2,3,4,5,6);
		
		System.out.println(
				numbers.stream()         // takes about 3 secs
				       .mapToInt(Lambda4::twice)  // Class::method(), Method Reference
				       .sum()
		);

		System.out.println(
				numbers.parallelStream() // takes about 1 sec
				       .mapToInt(Lambda4::twice)
				       .sum()
		);

	}
}
