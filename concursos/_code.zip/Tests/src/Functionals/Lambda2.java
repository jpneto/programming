package Functionals;

import java.util.function.*;

public class Lambda2 {

	private static Integer doSomethingWith(BiFunction<Integer, Integer, Integer> f, 
			                               Integer i, Integer j) {
		return f.apply(i,j);
	}
	
	public static void main(String[] args) {
		int a = doSomethingWith( (x,y)-> x+y, 10, 20 );
		int b = doSomethingWith( (x,y)-> x*y, 10, 20 );
		System.out.println(a+":"+b);
	}
	
}
