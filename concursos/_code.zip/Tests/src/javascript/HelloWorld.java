package javascript;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class HelloWorld { 

	public static void main(String[] args) throws ScriptException {
		
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("nashorn");
		
		Object result = engine.eval("'Hello, World!'.length");
		System.out.println(result);
		
		// read and run script from file
		// Object result = engine.eval(Files.newBufferedReader(path));
		
		int x = 100;
		
		engine.put("xx", x);  // place Java's 'x' in the javascript engine as 'xx'
		result = engine.eval("xx+10");
		System.out.println(result);

		// javascript can access java libraries
		result = engine.eval("java.lang.Math.sqrt(2.0)"); 
		System.out.println(result);

	}
}
