package friedman;

public class Leaf extends TreeNode {
	
	public Leaf(char c) {
		data = c;
	}
	
	public double eval() {
		return Double.parseDouble(String.valueOf(data));
	}

	public String expression() {
		return data+"";
	}
}
