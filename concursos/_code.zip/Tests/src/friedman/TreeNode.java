package friedman;

public abstract class TreeNode {
	TreeNode left, right;
	public char data;

	public abstract double eval();
	public abstract String expression();
	
	@Override
	public String toString() {
		return "\n"+this.toString(new StringBuilder(), true, new StringBuilder()).toString();
	}
	
	//@ref: https://stackoverflow.com/questions/4965335/
	public StringBuilder toString(StringBuilder prefix, boolean isTail, StringBuilder sb) {
	    if(right!=null)
	        right.toString(new StringBuilder().append(prefix).append(isTail ? "│   " : "    "), false, sb);
	    
	    sb.append(prefix).append(isTail ? "└── " : "┌── ").append((data+"").toString()).append("\n");
	    
	    if(left!=null)
	        left.toString(new StringBuilder().append(prefix).append(isTail ? "    " : "│   "), true, sb);
	    return sb;
	}
}
