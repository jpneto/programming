package friedman;

import java.util.*;

public class Friedman {

	// Utility function to swap two characters in a character array
	private static void swap(char[] ch, int i, int j) {
		char temp = ch[i];
		ch[i] = ch[j];
		ch[j] = temp;
	}

	// Recursive function to generate all permutations of a String
	private static void permutations(char[] str, int index, ArrayList<String> result) {

		if (index == str.length - 1)
			result.add(String.valueOf(str));

		for (int i = index; i < str.length; i++) {
			swap(str, index, i);
			permutations(str, index + 1, result);
			swap(str, index, i);
		}
	}

	private static void arrangements(String str, int len, char[] chars, ArrayList<String> result) {

		if(str.length()==len)  // the word is complete, keep it
			result.add(str);
		else			
			for(int i=0; i<chars.length; i++)
				arrangements(str+chars[i], len, chars, result);
	}

	//	//@ref: https://stackoverflow.com/questions/39001215
	//	private static List<TreeNode> allBinaryTrees(int nLeaves) {
	//	    List<TreeNode> result = new ArrayList<>();
	//	    
	//	    if (nLeaves == 1) {
	//	        result.add(new Leaf('.'));
	//	        return result;
	//	    }
	//	    
	//	    for (int sizeLeftSubtree = 1; sizeLeftSubtree < nLeaves; sizeLeftSubtree++) {
	//	        List<TreeNode> leftSubtrees  = allBinaryTrees(sizeLeftSubtree);
	//	        List<TreeNode> rightSubtrees = allBinaryTrees(nLeaves - sizeLeftSubtree);
	//	        for (TreeNode lt : leftSubtrees) 
	//	            for (TreeNode rt : rightSubtrees) 
	//	                // make a tree of a node with lt and rt as subtrees, and add it to the result
	//	                result.add(new InternalNode(lt, '.', rt));
	//	    }
	//	    return result;
	//	}

	///////////////////////////////////////

	private static List<TreeNode> allBinaryTrees(int nLeaves, 
			String internals, String leaves,
			int internalsId, int leavesId) {
		List<TreeNode> result = new ArrayList<>();

		if (nLeaves == 1) {
			result.add(new Leaf(leaves.charAt(leavesId)));
			return result;
		}

		for (int sizeLeftSubtree = 1; sizeLeftSubtree < nLeaves; sizeLeftSubtree++) {
			List<TreeNode> leftSubtrees  = allBinaryTrees(sizeLeftSubtree, internals, leaves, 
					internalsId+1, leavesId);
			// the internal nodes of leftSubtrees consumed (sizeLeftSubtree-1) operators
			List<TreeNode> rightSubtrees = allBinaryTrees(nLeaves - sizeLeftSubtree, internals, leaves,
					internalsId+sizeLeftSubtree, leavesId + sizeLeftSubtree);
			for (TreeNode lt : leftSubtrees) 
				for (TreeNode rt : rightSubtrees) 
					// make a tree of a node with lt and rt as subtrees, and add it to the result
					result.add(new InternalNode(lt, internals.charAt(internalsId), rt));
		}
		return result;
	}

	///////////////////////////////////////
    // prevent expressions like 90(5 ^ 2) = 9025 and 095 ^ 2 = 9025

	private static boolean rightFormat(String expression) {
		// check paranteses
		for(int i=0; i<expression.length()-1; i++) {
			char c1 = expression.charAt(i);
			char c2 = expression.charAt(i+1);
			
			if ((Character.isDigit(c1) && c2=='(') ||
				(Character.isDigit(c2) && c1==')') 
			   )
				return false;
		}
		
		String[] numbers = expression.split("[+\\-*/^.() ]");
		// check trailing zeros
		for(String number : numbers) {
			if (number.length()>1 && number.charAt(0)=='0') 
				return false; 
		}
		
		return true;
	}
    
	///////////////////////////////////////
    // we will not consider the negative unary operator. 
	// this works up to 5 digits, the number of binary tree with 6 leaves is > 2e8 
    public static void main(String[] args) 	{
    	
    	String ops = "+-*/^.";  // '.' means concatenation, and must be the last operator

		String 
		       digits = "15624"; // 24 * 651
		       digits = "2508";  // 50^2 + 8
		       digits = "9025";  // 95^2 + 0 
		       digits = "6880";  // 8 * 860
		       digits = "98415"; // 5 * (9 ^ (18 / 4))
		       digits = "289";   // 289 = (8+9)^2
		       digits = "3864";  // ((6 ^ 4) - 8) * 3
		       
		// generate all permutations of digits
		ArrayList<String> perms = new ArrayList<>(); 
		permutations(digits.toCharArray(), 0, perms);

		// generate all arrangements of operators (they can be repeated)
		ArrayList<String> arrangs = new ArrayList<>(); 
		arrangements("", digits.length()-1, ops.toCharArray(), arrangs);
		arrangs.remove(arrangs.size()-1); // remove last one: all concatenations is a trivial solution
		
		// generate all full binary trees (ie, with zero or two children per node)
		// with the number of leaves equal to the number of digits
		List<TreeNode> allTrees = new ArrayList<>();
		for(String leaves : perms)
			for(String internals : arrangs) {
				List<TreeNode> trees = allBinaryTrees(digits.length(), internals, leaves, 0, 0);
				allTrees.addAll(trees);
			}

		// for each tree, evaluate it and check if its result == initial number
		ArrayList<String> results = new ArrayList<>();
		
		int initialNumber = Integer.parseInt(digits);
		for(TreeNode tree : allTrees) {
			double treeValue = tree.eval();
			if ((treeValue == Math.floor(treeValue)) && !Double.isInfinite(treeValue)) // if it's an int
				if ((int) treeValue == initialNumber) {
					// System.out.println("-------------------------\n"+tree);
					String result = tree.expression();
					// pretty print: remove external ()'s
					if (result.charAt(0)=='(' && result.charAt(result.length()-1)==')')
						result = result.substring(1, result.length()-1);
					
					// filter out concatenation with ()s and left zeros
					if (rightFormat(result))
						//System.out.println(result + " = " + initialNumber);
						results.add(result);
				}
		}
		
		// use set to remove duplicates
		results = new ArrayList<String>(new LinkedHashSet<String>(results));
		// sort list alphabetically
		java.util.Collections.sort(results);
		
		for(String result : results)
			System.out.println(result + " = " + initialNumber);		
	}

}