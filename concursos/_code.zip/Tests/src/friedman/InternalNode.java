package friedman;

public class InternalNode extends TreeNode {

	public InternalNode(TreeNode lt, char c, TreeNode rt) {
		data  = c;
		left  = lt;
		right = rt;
	}

	public double eval() {
		double leftEval  = left.eval();
		double rightEval = right.eval();
		
		switch (data) {
		case '+' : return leftEval + rightEval;
		case '-' : return leftEval - rightEval;
		case '*' : return leftEval * rightEval;
		case '/' : return leftEval / rightEval;
		case '^' : return Math.pow(leftEval, rightEval);
		case '.' :
			if(rightEval==0)
				return 10 * leftEval;
			int nDigits = (int) (Math.log10(rightEval) + 1);
			return Math.pow(10, nDigits) * leftEval + rightEval;
		}
		return Double.NaN;
	}
	
	public String expression() {
		String leftExpression  = left.expression();
		String rightExpression = right.expression();

		switch (data) {
		case '+' : return String.format("(%s + %s)", leftExpression, rightExpression);
		case '-' : return String.format("(%s - %s)", leftExpression, rightExpression);
		case '*' : return String.format("(%s * %s)", leftExpression, rightExpression);
		case '/' : return String.format("(%s / %s)", leftExpression, rightExpression);
		case '^' : return String.format("(%s ^ %s)", leftExpression, rightExpression);
		case '.' : return String.format(   "%s%s"  , leftExpression, rightExpression);
		}
		return "ERROR";
	}
}
