package scannerStringEgs;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class Egs {
	
	private static void getStringPerLine() throws FileNotFoundException {
		Scanner sc = new Scanner(new File("data/nStringsPerLine.txt"));
		
		while(sc.hasNextLine()) {
			// split using 1+ spaces as delimeters
			String[] tokens = sc.nextLine().split(" +");
			for(String token : tokens)
				System.out.println(token);
			System.out.println("---"); // line ended
		}
		
		sc.close();
	}
	
	private static void getNumbers() throws FileNotFoundException {
		Scanner sc = new Scanner(new File("data/nNumbersPerLine.txt"));
		
		while(sc.hasNext()) {
			// split using 1+ spaces as delimeters
			int number = sc.nextInt();
			System.out.println(number);
		}
		
		sc.close();
	}

	// get all the numbers of a line, convert to a list of integers, then print them
	private static void getNumbersPerLine() throws FileNotFoundException {
		Scanner sc = new Scanner(new File("data/nNumbersPerLine.txt"));
		
		while(sc.hasNext()) {
			// split using 1+ spaces as delimeters
			String[] tokens = sc.nextLine().split(" +");
			List<Integer> numbers = Arrays.asList(tokens)                // String[] --> List<String>
					                      .stream()                      // create stream
					                      .map(Integer::parseInt)        // map each string to number
					                      .collect(Collectors.toList()); // make the final list
					
			for(int number : numbers)
				System.out.println(number);
			System.out.println("---"); // line ended
		}
		
		sc.close();
	}
	
	
	public static void main(String[] args) throws FileNotFoundException {
		
		getStringPerLine();
		System.out.println("---------"); 
		
		getNumbers();
		System.out.println("---------"); 

		getNumbersPerLine();
		System.out.println("---------"); 

		//////////////////////
		
		int[] is = new int[] {1,-12,123};
		List<Integer> li = Arrays.stream(is).boxed().collect(Collectors.toList());
		
		for(int i : li)
			System.out.printf(" %5d%n", i);  // provide left spaces and justify left
		
		System.out.println("---------"); 

		for(int i : li)
			System.out.printf(" %+5d%n", i);  // use a + to indentify positive numbers

		System.out.println("---------"); 

		double[] ds = new double[] {1.666,12.77,123.1234};
		List<Double> ld = Arrays.stream(ds).boxed().collect(Collectors.toList());
		
		for(double i : ld)
			System.out.printf(" %.3f%n", i);  // give 3 positions after decimal point
		
		System.out.println("---------"); 

		for(double i : ld)
			System.out.printf(" %7.3f%n", i);  // also, provide 7+ spaces to the entire number
		
		
	}

}
