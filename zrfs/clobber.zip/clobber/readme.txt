
Clobber

-------------------------------------------------------------------
Invented by Michael Albert, J.P. Grossman, and Richard J. Nowakowski in 2001
Implemented by Joao Pedro Neto for Zillions of Games 
-------------------------------------------------------------------
You should have extracted this zip file preserving path names,
(Check "Use Folder Names" box in Win-Zip Extract Files Dialog Box);
and you should extract to your Zillions Rules folder.This will
create an Clobber folder within the Rules folder.
-------------------------------------------------------------------

Description [From http://www.sciencenews.org/20020427/mathtrek.asp]

Clobber is a new two-person game that's easy to learn and fun to play and, for the mathematically inclined, rife with analytical possibility. 

The "standard" game is played on a rectangular grid of squares�say, a portion of a checkerboard. One player governs the movement of white pieces, or stones, and the other player moves black stones. Initially, each square is occupied by a white or black stone, arranged so that the colors alternate. 

Each player moves in turn, picking up one of his or her own stones and "clobbering" an opponent's stone on a vertically or horizontally adjacent square. (Diagonal moves are not allowed.) The clobbered stone is removed from the board and replaced by the stone that was moved. 

White starts. The game ends when a player can't move because none of his or her remaining stones is adjacent to a stone of the opposite color and, hence, can't clobber an opponent's stone. That player loses. 

-------------------------------------------------------------------
To play:

1. Run "Zillions of Games"
2. Choose "Open Game Rules..." from the File menu
3. Select "Clobber" folder in the Open dialog and click "Open"
4. Select "Clobber.zrf" in the Open dialog and click "Open"
-------------------------------------------------------------------
Clobber.zrf is a rules file used by the Windows program
"Zillions of Games".  Zillions of Games allows you to play any
number of games against the computer or over the Internet.
Zillions of Games can be purchased online.  For more information
please visit the Zillions of Games website
              <http://www.zillions-of-games.com> 
-------------------------------------------------------------------
