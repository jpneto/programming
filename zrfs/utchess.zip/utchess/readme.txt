This is a collection of three Zillions of Games rules files
for UT Chess.  These chess variants were invented by
Joao Pedro Neto, inspired by the first-person-shooter
computer game Unreal Tournament.  His concept can be found
on the Chess Variant Pages at www.chessvariants.com.

The following is a list of known bugs and other changes from
the original concept (these appear in commentary in the rules
files, but I thought I'd repeat them out here):

Domination Chess:

   * Players are Red and Blue (in the other variants too), as in
     UT, instead of White and Black.

   * Domination ends after a specified number of domination points
     are scored (61 or 122), instead of after a specific number of
     moves.

Assault Chess:

   * The win-condition is capture of a defending King, not checkmate.

   * When Red captures the defending King, he wins immediately, 
     even if Blue would capture the other defending King on the
     very next move (which should be a draw.)

   * En Passant capture does not work correctly -- only defending
     pawns can do it.


Capture-the-Flag Chess:

   (I'm not proud of my implementation of this game; I only did it
    because I had to finish the suite.)

   * Bases are fixed at e1 and e8 instead of being selected by the
     players.

   * There are no Kings.

   * Pieces may not drop the flag.

   * Bishops with the flag may step one space orthogonally into the
     friendly base to win (otherwise a Bishop on the wrong color with
     the flag could not win, since I didn't implement flag dropping.)

   * The friendly flag does not need to be present when you bring in
     the enemy flag, as it does in UT.


